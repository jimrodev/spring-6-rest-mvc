package com.santander.scib.creame.excesses.application.validation;

import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

public class ValidationHandler<T, U extends Validator> {

    private final Class<T> validationClass;

    private final U validator;

    public ValidationHandler(Class<T> clazz, U validator) {
        this.validationClass = clazz;
        this.validator = validator;
    }

    public T validate(final T body) {

        Errors errors = new BeanPropertyBindingResult(
                body,
                this.validationClass.getName());
        this.validator.validate(body, errors);

        if (errors.getAllErrors().isEmpty()) {
            return processBody(body);
        } else {
            return onValidationErrors(errors, body);
        }
    }

    public Errors getAllErrors(final T body)
    {
        Errors errors = new BeanPropertyBindingResult(
                body,
                this.validationClass.getName());

        this.validator.validate(body, errors);

        return  errors;
    }

    protected T onValidationErrors(
            Errors errors,
            T body) {

            if(errors.getAllErrors().isEmpty()){
                return body;
            }
            else {
                Map<String, List<String>> errorList = errors.getFieldErrors().stream()
                        .map(fieldError -> {
                            // #1
                            //Map<String, String> errorMap = new HashMap<>();
                            //errorMap.put(fieldError.getField(), fieldError.getDefaultMessage());

                            // #2
                            return Pair.of(fieldError.getField(), Objects.requireNonNull(fieldError.getDefaultMessage()));
                            // #1
                            //}).collect(Collectors.toList());
                            // #2
                        }).collect(Collectors.groupingBy(Pair::getFirst, Collectors.mapping(Pair::getSecond, Collectors.toList())));

                throw new ResponseStatusException(
                        HttpStatus.BAD_REQUEST,
                        errorList.toString());
            }
    }

    protected T processBody(T body)
    {
        return body;
    }
}