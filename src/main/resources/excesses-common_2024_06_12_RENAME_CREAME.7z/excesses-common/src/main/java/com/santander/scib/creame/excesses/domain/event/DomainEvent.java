package com.santander.scib.creame.excesses.domain.event;
public interface DomainEvent<T> {
    void fire();
}
