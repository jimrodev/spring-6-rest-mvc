package com.santander.scib.creame.excesses.application.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    @ResponseBody
    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorDTO handleException(Exception exception) {
        log.error(exception.getMessage(), exception);
        return ErrorDTO.builder()
                .code(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
                .message("Unexpected error!")
                .build();
    }

    //@ResponseBody
    @ExceptionHandler(value = {ValidationException.class})
    //@ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity handleException(ValidationException exception) {

       if (exception instanceof ConstraintViolationException) {
           Map errorList = ((ConstraintViolationException) exception).getConstraintViolations().stream()
                   .map(fieldError -> {
                       Pair<String, String> errorMap = Pair.of(((PathImpl) fieldError.getPropertyPath()).getLeafNode().toString(), fieldError.getMessage());
                       return errorMap;
                   }).collect(Collectors.groupingBy(Pair::getFirst, Collectors.mapping(Pair::getSecond, Collectors.toList())));

           return ResponseEntity.badRequest().body(errorList.entrySet().stream().sorted(Map.Entry.comparingByKey()));

       } else {
           String exceptionMessage = exception.getMessage();
           log.error(exceptionMessage, exception);

           return ResponseEntity.badRequest().body(exceptionMessage);

       }
    }

    private String extractViolationsFromException(ConstraintViolationException validationException) {
        return validationException.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining("--"));
    }

}
