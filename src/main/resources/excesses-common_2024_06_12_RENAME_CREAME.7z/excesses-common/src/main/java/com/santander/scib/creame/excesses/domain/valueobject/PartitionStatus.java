package com.santander.scib.creame.excesses.domain.valueobject;

public enum PartitionStatus {
    PENDING(0), COMPLETED(1), FAILED(2);

    private final Integer partitionStatus;
    PartitionStatus(Integer partitionStatus){
        this.partitionStatus = partitionStatus;
    }
    public Integer getPartitionStatus(){
        return partitionStatus;
    }
}
