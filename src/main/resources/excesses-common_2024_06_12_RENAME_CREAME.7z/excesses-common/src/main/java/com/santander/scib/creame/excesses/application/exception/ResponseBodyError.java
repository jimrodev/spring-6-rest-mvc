package com.santander.scib.creame.excesses.application.exception;

import java.time.LocalDateTime;
public record ResponseBodyError(LocalDateTime timestamp,
                           Integer status,
                           String error,
                           String message,
                           String path)
{};
