package com.santander.scib.creame.excesses.domain.valueobject;

public enum ExcessType {
    REAL(0), NOT_REAL(1);

    private final Integer excessType;
    ExcessType(Integer excessType){
        this.excessType = excessType;
    }
    public Integer getExcessType(){
        return excessType;
    }
}
