package com.santander.scib.creame.excesses.file.watcher.config;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "file-watcher-config")
public record FileWatcherProperties (
        @NotEmpty String path,
        @NotEmpty Integer retryCount,
        @NotEmpty Integer retryInterval
){}
