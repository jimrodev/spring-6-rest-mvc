package com.santander.scib.creame.workflow.service.adapters.dataaccess.repository;

import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WorkflowJpaRepository extends JpaRepository<WorkflowEntity, String> {

}
