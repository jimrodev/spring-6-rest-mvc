package com.santander.scib.creame.workflow.service.domain.application.outbox.scheduler;

import com.santander.scib.creame.excesses.application.outbox.CoordinatorScheduler;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.workflow.service.domain.application.outbox.ExcessOutboxHelper;
import com.santander.scib.creame.workflow.service.domain.application.ports.output.message.publisher.ExcessMessagePublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class ExcessOutBoxScheduler extends CoordinatorScheduler<ExcessOutboxHelper, ExcessMessagePublisher> {
    public ExcessOutBoxScheduler(@Value("#{Spools['excesses']}") final SpoolConfigData spoolConfigData,
                                 ExcessOutboxHelper coordinatorHelper,
                                 ExcessMessagePublisher outboxMessagePublisher) {
        super(spoolConfigData,
              coordinatorHelper,
              outboxMessagePublisher);
    }

    @Override
    @Transactional
    @Async
    @Scheduled(fixedDelayString = "#{Schedulers['excesses'].fixedDelay}" ,
             initialDelayString = "#{Schedulers['excesses'].initialDelay}" )
    public void process() {

        super.process();
    }

    @Override
    @Transactional
    //@Scheduled(cron = "@midnight")
    public void clear(){

        super.clear();
    }

    @Override
    @Transactional
    @Async
    @Scheduled(fixedDelayString = "#{Schedulers['healthcheck'].fixedDelay}" ,
            initialDelayString = "#{Schedulers['healthcheck'].initialDelay}" )
    public void healthcheck(){

        super.healthcheck();
    }
}
