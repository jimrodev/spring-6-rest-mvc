package com.santander.scib.creame.workflow.service.domain.application.outbox;

import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.helper.CoordinatorHelper;
import com.santander.scib.creame.workflow.service.domain.application.ports.output.repository.ExcessOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ExcessOutboxHelper extends CoordinatorHelper<ExcessOutboxRepository> {
    public ExcessOutboxHelper(@Value(Stakeholders.WORKFLOW) final String eventSource,
                              @Value(Stakeholders.EXCESS) final String eventTarget,
                              @Value("#{Spools['excesses']}") final SpoolConfigData spoolConfigData,
                              ExcessOutboxRepository excessOutboxRepository) {
        super(eventSource,
              eventTarget,
              spoolConfigData,
              excessOutboxRepository);
    }
}
