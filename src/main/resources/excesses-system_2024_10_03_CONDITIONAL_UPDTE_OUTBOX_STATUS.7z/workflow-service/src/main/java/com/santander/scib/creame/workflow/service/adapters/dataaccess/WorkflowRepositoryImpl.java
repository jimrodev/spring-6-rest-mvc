package com.santander.scib.creame.workflow.service.adapters.dataaccess;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntity;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.mapper.WorkflowDataAccessMapper;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.repository.WorkflowJpaRepository;
import com.santander.scib.creame.workflow.service.domain.application.ports.output.repository.WorkflowRepository;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class WorkflowRepositoryImpl implements WorkflowRepository {

    private final WorkflowJpaRepository workflowJpaRepository;
    private final WorkflowDataAccessMapper workflowDataAccessMapper;

    public WorkflowRepositoryImpl(WorkflowJpaRepository workflowJpaRepository,
                                  WorkflowDataAccessMapper workflowDataAccessMapper) {
        this.workflowJpaRepository = workflowJpaRepository;
        this.workflowDataAccessMapper = workflowDataAccessMapper;
    }

    @Override
    public Workflow save(Workflow workflow) {

        WorkflowEntity workflowEntity = workflowDataAccessMapper.workflowToWorkflowEntity(workflow);
        workflowEntity.setNew(true);
        return workflowDataAccessMapper.workflowEntityToWorkflow(workflowJpaRepository
                .save(workflowEntity));
    }

    @Override
    public Workflow update(Workflow workflow) {

        WorkflowEntity workflowEntity = workflowDataAccessMapper.workflowToWorkflowEntity(workflow);
        workflowEntity.setNew(false);
        return workflowDataAccessMapper.workflowEntityToWorkflow(workflowJpaRepository
                .save(workflowEntity));
    }

    @Override
    public Optional<Workflow> findById(ExcessId excessId) {

        return workflowJpaRepository.findById(excessId.getValue())
                .map(workflowDataAccessMapper::workflowEntityToWorkflow);
    }
}
