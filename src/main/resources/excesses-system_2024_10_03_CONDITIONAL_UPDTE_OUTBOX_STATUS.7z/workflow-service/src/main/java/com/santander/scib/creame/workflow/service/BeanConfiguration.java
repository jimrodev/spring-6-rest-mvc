package com.santander.scib.creame.workflow.service;

import com.santander.scib.creame.workflow.service.domain.core.WorkflowDomainService;
import com.santander.scib.creame.workflow.service.domain.core.WorkflowDomainServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public WorkflowDomainService workflowDomainService() {return new WorkflowDomainServiceImpl();}
 }
