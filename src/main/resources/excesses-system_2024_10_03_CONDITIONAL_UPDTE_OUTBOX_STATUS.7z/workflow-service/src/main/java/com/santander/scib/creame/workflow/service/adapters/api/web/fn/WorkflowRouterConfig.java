package com.santander.scib.creame.workflow.service.adapters.api.web.fn;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

@Configuration
@RequiredArgsConstructor
public class WorkflowRouterConfig {

    public static final String WORKFLOW_PATH = "/api/v3/workflow";
    public static final String WORKFLOW_PATH_ID = WORKFLOW_PATH + "/{id}";

    private final WorkflowHandler handler;

    @Bean
    public RouterFunction<ServerResponse> workflowRoutes(){
        return route()
                .POST(WORKFLOW_PATH, accept(APPLICATION_JSON), handler::assign)
                .build();
    }
}
