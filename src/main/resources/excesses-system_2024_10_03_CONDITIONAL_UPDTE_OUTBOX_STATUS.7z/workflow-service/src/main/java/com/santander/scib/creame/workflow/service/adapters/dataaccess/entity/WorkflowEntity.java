package com.santander.scib.creame.workflow.service.adapters.dataaccess.entity;

import com.santander.scib.creame.excesses.application.converter.ListConverter;
import com.santander.scib.creame.excesses.domain.valueobject.*;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.util.Objects;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "workflow")
@Entity
public class WorkflowEntity implements Persistable<String> {

    @Id
    private String excessId;
    private String processTimestamp;
    @Enumerated(EnumType.STRING)
    private WorkflowStatus workflowStatus;
    @Enumerated(EnumType.STRING)
    private WorkflowGroup assignedGroup;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorkflowEntity that = (WorkflowEntity) o;
        return excessId.equals(that.excessId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(excessId);
    }

    @Override
    public String getId() {return this.excessId;}

    @Override
    public boolean isNew() {return this.isNew;}
}
