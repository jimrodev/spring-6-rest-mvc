package com.santander.scib.creame.workflow.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.BaseEntity;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessDetailId;

import java.math.BigDecimal;
import java.util.Map;

public class ExcessDetail extends BaseEntity<ExcessDetailId> {

    private final String processDate;

    private final String limitOrigin;

    private final String limitShortName;
    private final String period;

    private final String limitCurrency;

    private final BigDecimal limitAmount;

    private final BigDecimal used;

    private final String excessReason;

    private final Map<String, Object> metadata;

    private ExcessDetail(Builder builder) {
        super.setId(builder.excessDetailId);
        processDate = builder.processDate;
        limitOrigin = builder.limitOrigin;
        limitShortName = builder.limitShortName;
        period = builder.period;
        limitCurrency = builder.limitCurrency;
        limitAmount = builder.limitAmount;
        used = builder.used;
        excessReason = builder.excessReason;
        metadata = builder.metadata;
    }

    public String getProcessDate() {return processDate;}

    public String getLimitOrigin() {return limitOrigin;}
    public String getLimitShortName() {
        return limitShortName;
    }

    public String getPeriod() {
        return period;
    }

    public String getLimitCurrency() {
        return limitCurrency;
    }

    public BigDecimal getLimitAmount() {
        return limitAmount;
    }

    public BigDecimal getUsed() {
        return used;
    }

    public String getExcessReason() {
        return excessReason;
    }

    public Map<String, Object> getMetadata() {
        return metadata;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private ExcessDetailId excessDetailId;
        private String processDate;

        private String limitOrigin;
        private String limitShortName;
        private String period;
        private String limitCurrency;
        private BigDecimal limitAmount;
        private BigDecimal used;
        private String excessReason;
        private Map<String, Object> metadata;

        private Builder() {
        }

        public Builder excessDetailId(ExcessDetailId val) {
            excessDetailId = val;
            return this;
        }

        public Builder processDate(String val) {
            processDate = val;
            return this;
        }

        public Builder limitOrigin(String val) {
            limitOrigin = val;
            return this;
        }

        public Builder limitShortName(String val) {
            limitShortName = val;
            return this;
        }

        public Builder period(String val) {
            period = val;
            return this;
        }

        public Builder limitCurrency(String val) {
            limitCurrency = val;
            return this;
        }

        public Builder limitAmount(BigDecimal val) {
            limitAmount = val;
            return this;
        }

        public Builder used(BigDecimal val) {
            used = val;
            return this;
        }

        public Builder excessReason(String val) {
            excessReason = val;
            return this;
        }

        public Builder metadata(Map<String, Object> val) {
            metadata = val;
            return this;
        }

        public ExcessDetail build() {
            return new ExcessDetail( this);
        }
    }
}
