package com.santander.scib.creame.workflow.service.domain.core.event;

import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;

import java.time.ZonedDateTime;

public abstract class WorkflowEvent implements DomainEvent<Workflow> {
    private final Workflow workflow;
    private final ZonedDateTime createdAt;

    public WorkflowEvent(Workflow workflow, ZonedDateTime createdAt) {
        this.workflow = workflow;
        this.createdAt = createdAt;
    }

    @Override
    public Workflow getEntity() {
        return this.workflow;
    }

    @Override
    public ZonedDateTime getCreatedAt() {
        return this.createdAt;
    }

    @Override
    public String getId(){
        return this.workflow.getId().getValue().toString();
    }
}

