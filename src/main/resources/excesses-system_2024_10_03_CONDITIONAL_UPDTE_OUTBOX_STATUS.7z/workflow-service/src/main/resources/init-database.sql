DROP TYPE IF EXISTS workflow_status;
CREATE TYPE workflow_status AS ENUM ('PENDING', 'ASSIGNED', 'FAILED');

DROP TYPE IF EXISTS workflow_group;
CREATE TYPE workflow_group AS ENUM ('GLOBAL_CONTROL', 'IT_ADMINISTRATOR', 'ADMISSION', 'FRONT_OFFICE', 'BANKER');

DROP TABLE IF EXISTS excesses.workflow;
CREATE TABLE excesses.workflow
(
    excess_id VARCHAR NOT NULL,
    process_timestamp VARCHAR NOT NULL,
    workflow_status workflow_status NOT NULL,
    assigned_group workflow_group NOT NULL,
    CONSTRAINT workflow_pkey PRIMARY KEY (excess_id)
);
