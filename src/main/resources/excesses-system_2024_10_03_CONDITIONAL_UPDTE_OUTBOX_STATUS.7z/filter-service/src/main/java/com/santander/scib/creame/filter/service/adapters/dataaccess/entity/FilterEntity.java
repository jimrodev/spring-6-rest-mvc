package com.santander.scib.creame.filter.service.adapters.dataaccess.entity;

import com.santander.scib.creame.excesses.application.converter.ListConverter;
import com.santander.scib.creame.excesses.domain.valueobject.*;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "filters")
@Entity
public class FilterEntity implements Persistable<String> {

    @Id
    private UUID filterId;
    private String excessId;
    private String processTimestamp;
    @Enumerated(EnumType.STRING)
    private FilterStatus filterStatus;
    @Convert(converter = ListConverter.class)
    private List<String> filtersMatching;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FilterEntity that = (FilterEntity) o;
        return filterId.equals(that.filterId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(filterId);
    }

    @Override
    public String getId() {return this.excessId;}

    @Override
    public boolean isNew() {return this.isNew;}
}
