package com.santander.scib.creame.filter.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.application.ports.input.service.FilterApplicationService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Component;

@Component
public class FilterApplicationServiceImpl implements FilterApplicationService {

    private final FilterApplyHandler filterApplyHandler;

    public FilterApplicationServiceImpl(FilterApplyHandler filterApplyHandler) {
        this.filterApplyHandler = filterApplyHandler;
    }

    @Override
    public FilterResponse apply(FilterRequest filterRequest, @Valid ContextMessage context) {
        return filterApplyHandler.apply(filterRequest, context);
    }
}
