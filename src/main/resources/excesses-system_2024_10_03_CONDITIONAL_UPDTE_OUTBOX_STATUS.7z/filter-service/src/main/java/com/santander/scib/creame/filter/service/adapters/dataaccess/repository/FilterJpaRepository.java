package com.santander.scib.creame.filter.service.adapters.dataaccess.repository;

import com.santander.scib.creame.filter.service.adapters.dataaccess.entity.FilterEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FilterJpaRepository extends JpaRepository<FilterEntity, UUID> {

    Optional<List<FilterEntity>> findByExcessId(String excessId);
    Optional<FilterEntity> findByExcessIdAndProcessTimestamp(String excessId, String processTimestamp);
}
