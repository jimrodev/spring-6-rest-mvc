package com.santander.scib.creame.filter.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class FilterResponse {
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String filterId;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String excessId;
    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String processTimestamp;
    @NotNull(message = "{not.null}")
    @JsonProperty
    private FilterStatus filterStatus;
    @JsonProperty
    private List<String> filtersMatching;
}
