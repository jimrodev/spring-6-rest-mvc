package com.santander.scib.creame.filter.service.adapters.api.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.exception.GlobalExceptionHandler;
import com.santander.scib.creame.excesses.application.exception.ResponseBodyError;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.filter.service.domain.core.exception.FilterDomainException;
import com.santander.scib.creame.filter.service.domain.core.exception.FilterNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
@ControllerAdvice
public class FilterGlobalExceptionHandler extends GlobalExceptionHandler {

    public FilterGlobalExceptionHandler(ObjectMapper objectMapper) {
        super(objectMapper);
    }

    @ResponseBody
    @ExceptionHandler(value = {FilterDomainException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ResponseBodyError> handleException(FilterDomainException filterDomainException) {
        log.error(filterDomainException.getMessage(), filterDomainException);
        return ResponseEntity
                .badRequest()
                .body(
                        ResponseBodyError.builder()
                            .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                            .status(HttpStatus.BAD_REQUEST.value())
                            .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                            .message(filterDomainException.getMessage())
                            .build());
    }

    @ResponseBody
    @ExceptionHandler(value = {FilterNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ResponseBodyError> handleException(FilterNotFoundException filterNotFoundException) {
        log.error(filterNotFoundException.getMessage(), filterNotFoundException);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(
                        ResponseBodyError.builder()
                                .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                                .status(HttpStatus.NOT_FOUND.value())
                                .error(HttpStatus.NOT_FOUND.getReasonPhrase())
                                .message(filterNotFoundException.getMessage())
                                .build());
    }
}
