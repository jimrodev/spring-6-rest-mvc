# Cream Spring Boot Excesses Infrastructure

[![Quality Gate Status](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=alert_status&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Security Rating](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=security_rating&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Maintainability Rating](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=sqale_rating&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Bugs](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=bugs&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Vulnerabilities](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=vulnerabilities&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Code Smells](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=code_smells&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)
[![Coverage](https://sonar-com.sgtech.gs.corp/api/project_badges/measure?project=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure&metric=coverage&token=sqb_b340f386370a6a63e9c405fb665baae35e8a94a0)](https://sonar-com.sgtech.gs.corp/dashboard?id=cib%3Acib%3Acream-excesses-mngt%3Aexcesses-infrastructure)

## Synopsis

This document describes the process, and the configurations of this project.

### Table of Contents

1. [Motivation](#motivation)
2. [Configuration Service](#configuration-service)
3. [Kafka](#kafka)
4. [Database](#database)
5. [S3](#s3)
6. [Cors](#cors)
7. [All Configuration](#all-configuration)
8. [Testing](#testing)
9. [Installation](#installation)
10. [API Reference](#api-reference)

## Motivation

This project is a common library for Spring Boot applications. It contains the following features:
- Configuration Service
- Kafka
- S3
- Cors

**[Back to top](#table-of-contents)**

## Configuration Service
The configuration service is a service that allows you to configure the application through a configuration file.
The minimum configuration for use this library is the following:

```yaml
app:
  infrastructure:
    ...
```

## Kafka

The Kafka is a service that allows you to configure the kafka in the application.

The minimum configuration for use this library is the following:

```yaml
app:
  infrastructure:
    kafka:
      enabled: true # true or false, default true
      topics: # Map of topics with a list of topic names
        topic-tag1:
          - topic-name
        topic-tag2:
          - topic-name1
          - topic-name2
      consumers: # Map of consumers with a list of consumer names
        consumer-tag1:
          poll-timeout: 1000
          concurrency: 1
          configurations:
            key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
            value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
            ...
        ...
       producers: # Map of producers with a list of producer names
          producer-tag1:
            configurations:
                key-serializer: org.apache.kafka.common.serialization.StringSerializer
                value-serializer: org.apache.kafka.common.serialization.StringSerializer
                ...
          ...
```

## Database

The Database is a service that allows you to configure the database(jdbc) in the application.

The minimum configuration for use this library is the following:

```yaml
app:
  infrastructure:
    database:
      enabled: true # true or false, default true
      data-sources: # Map of data sources with a list of data source names
        test:
          test-datasource:
            jdbc-url: jdbc:h2:mem:testdb
            username: sa
            password: password
            driver-class-name: org.h2.Driver
          ...
        ...
```

## S3

The S3 is a service that allows you to configure the s3 in the application.

The minimum configuration for use this library is the following:

```yaml
app:
  infrastructure:
    s3:
      enabled: true # true or false, default true
      buckets:
        test:
          test-bucket:
            name: test-bucket
            locations:
              root-folder: test/
          ...
        ...
      profiles:
        test:
          test-profile:
            service-endpoint: http://localhost:4566
            region: region-test
            credentials:
              access-key-id: access-key-test
              secret-access-key: secret-key-test
          ...
        ...
```

## Cors

The Cors is a service that allows you to configure the cors in the application.

The minimum configuration for use this library is the following:

```yaml
app:
  infrastructure:
    endpoints:
      mode: local # local to disable cors in local development, remove in remote
    cors: # CORS configuration, if not present when mode local, the default values are used
      allowed-origins: "http://localhost:5173"
      allowed-methods: "*"
      allowed-headers: "*"
      allow-credentials: true
      max-age: 3600
```

**[Back to top](#table-of-contents)**

## All Configuration

The all configuration for use this library is the following:

```yaml
app:
  infrastructure:
    kafka:
      enabled: true # true or false, default true
      topics: # Map of topics with a list of topic names
        topic-tag1:
          - topic-name
        topic-tag2:
          - topic-name1
          - topic-name2
      consumers: # Map of consumers with a list of consumer names
        consumer-tag1:
          poll-timeout: 1000
          concurrency: 1
          configurations:
            key-deserializer: org.apache.kafka.common.serialization.StringDeserializer
            value-deserializer: org.apache.kafka.common.serialization.StringDeserializer
            ...
        ...
       producers: # Map of producers with a list of producer names
          producer-tag1:
            configurations:
                key-serializer: org.apache.kafka.common.serialization.StringSerializer
                value-serializer: org.apache.kafka.common.serialization.StringSerializer
                ...
          ...
    s3:
      enabled: true # true or false, default true
      buckets:
        test: # Reference to the profile, Map of buckets with a list of bucket names
          test-bucket:
            name: test-bucket
            locations:
              root-folder: test/
          ...
        ...
      profiles:
        test: # Map of profiles with a list of profile names
          test-profile:
            service-endpoint: http://localhost:4566
            region: region-test
            credentials:
              access-key-id: access-key-test
              secret-access-key: secret-key-test
          ...
        ...
    database:
      enabled: true # true or false, default true
      data-sources: # Map of data sources with a list of data source names
        test:
          test-datasource:
            jdbc-url: jdbc:h2:mem:testdb
            username: sa
            password: password
            driver-class-name: org.h2.Driver
          ...
        ...
    endpoints:
      mode: local # local to disable cors in local development, remove in remote
    cors: # CORS configuration, if not present when mode local, the default values are used
      allowed-origins: "http://localhost:5173"
      allowed-methods: "*"
      allowed-headers: "*"
      allow-credentials: true
      max-age: 3600
```

**[Back to top](#table-of-contents)**

## Testing

This library creates a test-jar with the following test classes:
- HazelcastMemberConfig  # This class tests helps to test the hazelcast service
- LoggerAppender # This class tests helps to test the logger traces in the application

**[Back to top](#table-of-contents)**

## Installation

To install this library, you need to add the following dependency in your pom.xml:

```xml
<dependency>
  <groupId>com.santander.scib.creame</groupId>
  <artifactId>excesses-infrastructure</artifactId>
  <version>1.0.0-SNAPSHOT</version>
</dependency>
```

To install this library test-jar, you need to add the following dependency in your pom.xml:

```xml
<dependency>
  <groupId>com.santander.scib.creame</groupId>
  <artifactId>excesses-infrastructure</artifactId>
  <version>1.0.0-SNAPSHOT</version>
  <classifier>tests</classifier>
  <type>test-jar</type>
  <scope>test</scope>
</dependency>
```

**[Back to top](#table-of-contents)**

## API Reference

Spring boot API [here](https://docs.spring.io/spring-boot/docs/3.2.x/api/).

**[Back to top](#table-of-contents)**
