package com.santander.scib.creame.excesses.infrastructure.kafka;

import org.springframework.messaging.Message;

import java.util.List;

/**
 * Interface for Kafka consumers.
 * This interface provides methods for receiving single and batch messages from Kafka.
 *
 * @param <T> the type of the message
 */
public interface KafkaConsumer<T> {

    /**
     * Handles a single received message from Kafka.
     *
     * @param message the received message
     */
    default void receivedRecord(Message<T> message) {
        // Do nothing by default
    }

    /**
     * Handles a batch of received messages from Kafka.
     *
     * @param messages the list of received messages
     */
    default void receivedBatch(List<Message<T>> messages) {
        // Do nothing by default
    }

}
