package com.santander.scib.creame.excesses.infrastructure.kafka.config;

import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducerAvroImpl;
import lombok.Getter;
import lombok.Setter;
import org.apache.avro.generic.GenericRecord;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Configuration class for Kafka producers.
 * This class creates beans for ProducerFactory objects and KafkaTemplate objects.
 *
 * @param <K> the type of the Kafka message key
 * @param <V> the type of the Kafka message value
 */
@Configuration
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app.infrastructure.kafka', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0 and '${app.infrastructure.kafka.enabled:true}' == 'true'"
)
@ConfigurationProperties(prefix = "app.infrastructure.kafka")
@Getter
@Setter
public class KafkaProducerConfig<K extends Serializable, V extends GenericRecord> {

    private Map<String, KafkaProducerConfigData> producers;

    /**
     * Creates a map of ProducerFactory objects based on the application's Kafka producers.
     *
     * @return a map of producer names to ProducerFactory objects
     */
    @Bean
    public Map<String, ProducerFactory<K, V>> producerFactories() {
        Map<String, ProducerFactory<K, V>> producerFactories = new HashMap<>();
        producers.forEach(
            (key, value) -> {
                Map<String, Object> configurations = value.getConfigurations().entrySet().stream().collect(
                    HashMap::new,
                    (m, v) -> m.put(String.valueOf(v.getKey()), v.getValue()),
                    HashMap::putAll
                );
                producerFactories.put(key, new DefaultKafkaProducerFactory<>(configurations));
            }
        );
        return producerFactories;
    }

    /**
     * Creates a map of KafkaTemplate objects based on the application's ProducerFactory objects.
     *
     * @return a map of producer names to KafkaTemplate objects
     */
    @Bean
    public Map<String, KafkaTemplate<K, V>> kafkaTemplates() {
        Map<String, KafkaTemplate<K, V>> kafkaTemplates = new HashMap<>();
        producerFactories().forEach(
            (key, value) -> kafkaTemplates.put(key, new KafkaTemplate<>(value))
        );
        return kafkaTemplates;
    }

    @Bean
    public Map<String, KafkaProducer<K, V>> KafkaProducers(){

        Map<String, KafkaProducer<K, V>> kafkaProducers = new HashMap<>();
        kafkaTemplates().forEach(
                (key, value) -> kafkaProducers.put(key, new KafkaProducerAvroImpl<>(value))
        );
        return kafkaProducers;
    }
}
