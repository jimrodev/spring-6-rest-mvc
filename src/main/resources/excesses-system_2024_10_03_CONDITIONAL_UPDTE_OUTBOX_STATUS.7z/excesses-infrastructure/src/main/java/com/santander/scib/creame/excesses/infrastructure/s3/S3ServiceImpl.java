package com.santander.scib.creame.excesses.infrastructure.s3;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;

import java.io.InputStream;

/**
 * Service implementation for interacting with S3.
 * This class is conditionally loaded based on the application's configuration.
 * It uses an S3Client to download files from S3.
 */
@Slf4j
@Service
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app.infrastructure.s3', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0 and '${app.infrastructure.s3.enabled:true}' == 'true'"
)
public class S3ServiceImpl implements S3Service {

    /**
     * Downloads a file from an S3 bucket.
     *
     * @param s3Client the S3Client to use for downloading the file
     * @param bucketName the name of the S3 bucket
     * @param keyName the key of the file in the S3 bucket
     * @return an InputStream of the downloaded file
     * @throws SdkException if an error occurs while downloading the file
     */
    @Override
    public InputStream downloadFile(S3Client s3Client, String bucketName, String keyName) throws SdkException {
        final GetObjectRequest getObjectRequest = GetObjectRequest.builder()
            .bucket(bucketName)
            .key(keyName)
            .build();

        final ResponseBytes<GetObjectResponse> responseBytes = s3Client.getObjectAsBytes(getObjectRequest);
        return responseBytes.asInputStream();
    }

}
