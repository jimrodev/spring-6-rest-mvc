package com.santander.scib.creame.excesses.service.domain.application;

public enum ExcessOperation {
    NEW, UPDATE, SOLVED, ALERT
}
