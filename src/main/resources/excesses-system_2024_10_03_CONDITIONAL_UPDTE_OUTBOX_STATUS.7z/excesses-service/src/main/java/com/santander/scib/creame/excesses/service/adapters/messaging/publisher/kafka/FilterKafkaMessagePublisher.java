package com.santander.scib.creame.excesses.service.adapters.messaging.publisher.kafka;

import com.santander.scib.creame.avro.models.FilterRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;

import com.santander.scib.creame.excesses.application.outbox.helper.OutboxCommonHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaOutboxMessagePublisher;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducerHelper;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.FilterMessagingDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.excesses.service.domain.application.outbox.FilterOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher.FilterMessagePublisher;


import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;

@Slf4j
@Component
public class FilterKafkaMessagePublisher extends KafkaOutboxMessagePublisher<ExcessRequest, FilterRequestAvroModel, CoordinatorMessage>
                                         implements FilterMessagePublisher {

    private final FilterMessagingDataMapper filterMessagingDataMapper;
    private final String topicName;

    public FilterKafkaMessagePublisher(FilterMessagingDataMapper filterMessagingDataMapper,
                                       FilterOutboxHelper filterOutboxHelper,
                                       @Value("#{@KafkaProducers['filter']}") KafkaProducer<String, FilterRequestAvroModel> kafkaProducer,
                                       KafkaProducerHelper kafkaProducerHelper,
                                       @Value("#{@kafkaTopics['filter-request']}") String topicName){
        super(kafkaProducer, kafkaProducerHelper);
        this.filterMessagingDataMapper = filterMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    public void publish(CoordinatorMessage coordinatorMessage, BiConsumer<CoordinatorMessage, OutboxStatus> outboxCallback) {
        // Set output context properties
        ContextMessage context = OutboxCommonHelper.deserializePayload(coordinatorMessage.getContext(),
                                                                        ContextMessage.class);
        // Message Type
        context.setMessageType(FilterRequest.class.getTypeName());
        // Outbound transport properties
        context.setOutboundTransportType("Kafka://");
        context.setOutboundTransportLocation(topicName);

        coordinatorMessage.setContext(OutboxCommonHelper.serializeContext(coordinatorMessage.getOutboxId(),
                                                                          context));
        // Publish message (Event bus)
        publish(coordinatorMessage,
                outboxCallback,
                filterMessagingDataMapper::excessRequestToFilterRequestAvroModel,
                topicName);
    }
}
