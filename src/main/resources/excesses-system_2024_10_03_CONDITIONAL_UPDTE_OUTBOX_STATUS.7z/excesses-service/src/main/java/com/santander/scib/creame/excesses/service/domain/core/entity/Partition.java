package com.santander.scib.creame.excesses.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.BaseEntity;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionStatus;

public class Partition extends BaseEntity<PartitionId> {
    private PartitionStatus partitionStatus;

    private Partition(Builder builder) {
        super.setId(builder.partitionId);
        partitionStatus = builder.partitionStatus;
    }

    public PartitionStatus getPartitionStatus() {
        return partitionStatus;
    }
    public void initialize(){
        partitionStatus = PartitionStatus.PENDING;
    }

    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void process(){
        initialize();
        // HERE All FUNCTIONALITY OF PROCESS OPERATION
        partitionStatus = PartitionStatus.PROCESSED;
    }

    public void reprocess(){
        validate();
        // HERE All FUNCTIONALITY OF REPROCESS OPERATION
        partitionStatus = PartitionStatus.REPROCESSED;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private PartitionId partitionId;
        private PartitionStatus partitionStatus;

        private Builder() {
        }
        public Builder partitionId(PartitionId val) {
            partitionId = val;
            return this;
        }

        public Builder partitionStatus(PartitionStatus val) {
            partitionStatus = val;
            return this;
        }

        public Partition build() {
            return new Partition(this);
        }
    }
}
