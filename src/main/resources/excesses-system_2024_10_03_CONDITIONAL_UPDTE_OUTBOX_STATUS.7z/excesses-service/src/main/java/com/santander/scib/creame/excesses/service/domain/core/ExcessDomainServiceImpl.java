package com.santander.scib.creame.excesses.service.domain.core;

import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowStatus;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.event.*;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
public class ExcessDomainServiceImpl implements ExcessDomainService {

    @Override
    public ExcessCreatedEvent create(Excess excess) {
        excess.create();
        log.info("Excess with id: {} is created", excess.getId().getValue());
        return new ExcessCreatedEvent(excess,
                                    ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
    }

    @Override
    public ExcessUpdatedEvent update(Excess excess) {
        excess.update();
        log.info("Excess with id: {} is updated", excess.getId().getValue());
        return new ExcessUpdatedEvent(excess,
                                    ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
    }

    @Override
    public ExcessResolvedEvent solve(Excess excess) {
        excess.solve();
        log.info("Excess with id: {} is resolved", excess.getId().getValue());
        return new ExcessResolvedEvent(excess,
                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
    }

    @Override
    public ExcessFilteredEvent filter(Excess excess, FilterStatus filterStatus) {

        excess.filter(filterStatus);
        log.info("Excess with id: {} is filtered with status: {}", excess.getId().getValue(), excess.getExcessStatus());
        return new ExcessFilteredEvent(excess,
                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
    }

    @Override
    public ExcessAssignedEvent assign(Excess excess, WorkflowStatus workflowStatus) {
        excess.assign(workflowStatus);
        log.info("Excess with id: {} is assigned with status: {}", excess.getId().getValue(), excess.getExcessStatus());
        return new ExcessAssignedEvent(excess,
                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));

    }
}
