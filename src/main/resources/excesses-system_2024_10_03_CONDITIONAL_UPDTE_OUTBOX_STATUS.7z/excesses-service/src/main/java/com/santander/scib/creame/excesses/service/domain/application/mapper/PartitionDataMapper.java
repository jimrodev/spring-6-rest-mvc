package com.santander.scib.creame.excesses.service.domain.application.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionStatus;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;

import org.springframework.stereotype.Component;

@Component
public class PartitionDataMapper {

    public Partition PartitionRequestToPartition(PartitionRequest partitionRequest) {

        return Partition.builder()
                .partitionId(new PartitionId(partitionRequest.getPartitionId()))
                .build();
    }

    public PartitionResponse PartitionToPartitionResponse(Partition partition) {

        return PartitionResponse.builder()
                .partitionId(partition.getId().getValue())
                .partitionStatus(partition.getPartitionStatus())
                .build();
    }
}
