package com.santander.scib.creame.excesses.service.adapters.dataaccess;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper.ExcessDataAccessMapper;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper.PartitionDataAccesMapper;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.repository.PartitionJpaRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.PartitionRepository;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class PartitionRepositoryImpl implements PartitionRepository {

    private final PartitionJpaRepository partitionJpaRepository;
    private final PartitionDataAccesMapper partitionDataAccesMapper;

    public PartitionRepositoryImpl(PartitionJpaRepository partitionJpaRepository,
                                   PartitionDataAccesMapper partitionDataAccesMapper) {
        this.partitionJpaRepository = partitionJpaRepository;
        this.partitionDataAccesMapper = partitionDataAccesMapper;
    }

    @Override
    public Partition save(Partition partition) {
        return partitionDataAccesMapper.partitionEntityToPartition(partitionJpaRepository
                .save(partitionDataAccesMapper.partitionToPartitionEntity(partition)));
    }

    @Override
    public Optional<Partition> findByPartitionId(PartitionId partitionId) {
        Optional<PartitionEntity> foundPartition = partitionJpaRepository
                                                    .findById(partitionId.getValue());

        return foundPartition.map(partitionDataAccesMapper::partitionEntityToPartition);
    }

    @Override
    public void flush() {
        partitionJpaRepository.flush();
    }
}
