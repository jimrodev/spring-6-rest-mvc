package com.santander.scib.creame.excesses.service.domain.core.exception;

import com.santander.scib.creame.excesses.domain.exception.DomainException;

public class ExcessNotFoundException extends DomainException {

    public ExcessNotFoundException(String message) {
        super(message);
    }

    public ExcessNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
