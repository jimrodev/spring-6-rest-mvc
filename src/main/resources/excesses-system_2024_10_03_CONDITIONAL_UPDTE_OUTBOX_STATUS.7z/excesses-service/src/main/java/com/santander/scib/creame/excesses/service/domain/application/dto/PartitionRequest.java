package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.Nullable;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class PartitionRequest {
    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String partitionId;
    @JsonProperty
    private Boolean force;
}
