package com.santander.scib.creame.excesses.service.domain.application.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.helper.CoordinatorHelper;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.WorkflowOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class WorkflowOutboxHelper extends CoordinatorHelper<WorkflowOutboxRepository> {
    public WorkflowOutboxHelper(@Value(Stakeholders.EXCESS) final String eventSource,
                                @Value(Stakeholders.WORKFLOW) final String eventTarget,
                                @Value("#{Spools['workflow']}") final SpoolConfigData spoolConfigData,
                                WorkflowOutboxRepository workflowOutboxRepository) {
        super(eventSource,
              eventTarget,
              spoolConfigData,
              workflowOutboxRepository);
    }
}
