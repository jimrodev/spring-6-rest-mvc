package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.WorkflowResponseMessageListener;
import com.santander.scib.creame.excesses.service.domain.application.saga.FilterSagaHandler;
import com.santander.scib.creame.excesses.service.domain.application.saga.WorkflowSagaHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class WorkflowResponseMessageListenerImpl implements WorkflowResponseMessageListener {

    private final WorkflowSagaHandler workflowSagaHandler;
    public WorkflowResponseMessageListenerImpl(WorkflowSagaHandler workflowSagaHandler) {
        this.workflowSagaHandler = workflowSagaHandler;
    }

    @Override
    public void assigned(WorkflowResponse workflowResponse, ContextMessage context) {
        workflowSagaHandler.process(workflowResponse, context);
        log.info("Workflow Saga operation is completed for excess id: {}", workflowResponse.getExcessId());

    }

    @Override
    public void failed(WorkflowResponse workflowResponse, ContextMessage context) {
        // DEJAMOS EL SAGA EN FAILED? -> RELANZADO AUTOMÁTICO - RETRY (DELAY, COUNT, INTERVAL)
        // LANZAMOS ALERTA?
        workflowSagaHandler.compensation(workflowResponse, context);
    }
}
