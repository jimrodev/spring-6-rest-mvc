package com.santander.scib.creame.excesses.service.domain.application.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessDetailId;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessDetailDto;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import org.springframework.stereotype.Component;

@Component
public class ExcessDataMapper {

    public Excess ExcessRequestToExcess(ExcessRequest excessRequest)
    {
        return Excess.builder()
                .excessId(new ExcessId(excessRequest.getExcessId()))
                .metricType(excessRequest.getMetricType())
                .excessMetric(excessRequest.getExcessMetric())
                .excessBeginDate(excessRequest.getExcessBeginDate())
                .excessBeginTimestamp(excessRequest.getExcessBeginTimestamp())
                .excessEndDate(excessRequest.getExcessEndDate())
                .excessEndTimestamp(excessRequest.getExcessEndTimestamp())
                .limitInternalKey(excessRequest.getLimitInternalKey())
                .excessType(excessRequest.getExcessType())
                .excessStatus(excessRequest.getExcessStatus())
                .excessDetail(ExcessDetail.builder()
                        .excessDetailId(new ExcessDetailId(excessRequest.getExcessId(), excessRequest.getExcessDetail().getProcessTimestamp()))
                        .processDate(excessRequest.getExcessDetail().getProcessDate())
                        .limitOrigin(excessRequest.getExcessDetail().getLimitOrigin())
                        .limitShortName(excessRequest.getExcessDetail().getLimitShortName())
                        .period(excessRequest.getExcessDetail().getPeriod())
                        .limitCurrency(excessRequest.getExcessDetail().getLimitCurrency())
                        .limitAmount(excessRequest.getExcessDetail().getLimitAmount())
                        .used(excessRequest.getExcessDetail().getUsed())
                        .excessReason(excessRequest.getExcessDetail().getExcessReason())
                        .metadata(excessRequest.getExcessDetail().getMetadata())
                        .build())
                .build();
    }

    public ExcessRequest ExcessToExcessRequest(Excess excess)
    {
        return ExcessRequest.builder()
                .excessId(excess.getId().getValue())
                .metricType(excess.getMetricType())
                .excessMetric(excess.getExcessMetric())
                .excessBeginDate(excess.getExcessBeginDate())
                .excessBeginTimestamp(excess.getExcessBeginTimestamp())
                .excessEndDate(excess.getExcessEndDate())
                .excessEndTimestamp(excess.getExcessEndTimestamp())
                .limitInternalKey(excess.getLimitInternalKey())
                .excessType(excess.getExcessType())
                .excessStatus(excess.getExcessStatus())
                .excessDetail(ExcessDetailDto.builder()
                        .processDate(excess.getExcessDetail().getProcessDate())
                        .processTimestamp(excess.getExcessDetail().getId().getKey(1)) // PROCESS TIMESTAMP
                        .limitOrigin(excess.getExcessDetail().getLimitOrigin())
                        .limitShortName(excess.getExcessDetail().getLimitShortName())
                        .period(excess.getExcessDetail().getPeriod())
                        .limitCurrency(excess.getExcessDetail().getLimitCurrency())
                        .limitAmount(excess.getExcessDetail().getLimitAmount())
                        .used(excess.getExcessDetail().getUsed())
                        .excessReason(excess.getExcessDetail().getExcessReason())
                        .metadata(excess.getExcessDetail().getMetadata())
                        .build())
                .build();
    }

    public ExcessDetail ExcessRequestToExcessDetail(ExcessRequest excessRequest){
        return ExcessDetail.builder()
                .excessDetailId(new ExcessDetailId(excessRequest.getExcessId(), excessRequest.getExcessDetail().getProcessTimestamp()))
                .processDate(excessRequest.getExcessDetail().getProcessDate())
                .limitShortName(excessRequest.getExcessDetail().getLimitShortName())
                .period(excessRequest.getExcessDetail().getPeriod())
                .limitCurrency(excessRequest.getExcessDetail().getLimitCurrency())
                .limitAmount(excessRequest.getExcessDetail().getLimitAmount())
                .used(excessRequest.getExcessDetail().getUsed())
                .excessReason(excessRequest.getExcessDetail().getExcessReason())
                .metadata(excessRequest.getExcessDetail().getMetadata())
                .build();
    }

    public ExcessResponse ExcessToExcessResponse(Excess excess){
        return ExcessResponse.builder()
                .excessId(excess.getId().getValue())
                .metricType(excess.getMetricType())
                .excessMetric(excess.getExcessMetric())
                .excessBeginDate(excess.getExcessBeginDate())
                .excessBeginTimestamp(excess.getExcessBeginTimestamp())
                .excessEndDate(excess.getExcessEndDate())
                .excessEndTimestamp(excess.getExcessEndTimestamp())
                .limitInternalKey(excess.getLimitInternalKey())
                .excessType(excess.getExcessType())
                .excessStatus(excess.getExcessStatus())
                .excessDetail(ExcessDetailDto.builder()
                        .processDate(excess.getExcessDetail().getProcessDate())
                        .processTimestamp(excess.getExcessDetail().getId().getKey(1)) // ProcessTimestamp
                        .limitOrigin(excess.getExcessDetail().getLimitOrigin())
                        .limitShortName(excess.getExcessDetail().getLimitShortName())
                        .period(excess.getExcessDetail().getPeriod())
                        .limitCurrency(excess.getExcessDetail().getLimitCurrency())
                        .limitAmount(excess.getExcessDetail().getLimitAmount())
                        .used(excess.getExcessDetail().getUsed())
                        .excessReason(excess.getExcessDetail().getExcessReason())
                        .metadata(excess.getExcessDetail().getMetadata())
                        .build())
                .build();
    }
}
