package com.santander.scib.creame.excesses.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.ExcessDetailRecord;
import com.santander.scib.creame.avro.models.ExcessRequestAvroModel;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessDetailDto;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class ExcessMessagingDataMapper {

    // Ver con Byron el enviar el sagaId/interchangeId en el contexto del mensaje (Cabeceras Kafka)
    public ExcessRequestAvroModel excessRequestToExcessRequestAvroModel(ExcessRequest excessRequest) {

        return ExcessRequestAvroModel.newBuilder()
                .setExcessId(excessRequest.getExcessId())
                .setMetricType(excessRequest.getMetricType().toString())
                .setExcessMetric(excessRequest.getExcessMetric().toString())
                .setExcessBeginDate(excessRequest.getExcessBeginDate())
                .setExcessBeginTimestamp(excessRequest.getExcessBeginTimestamp())
                .setExcessEndDate(excessRequest.getExcessEndDate())
                .setExcessEndTimestamp(excessRequest.getExcessEndTimestamp())
                .setLimitInternalKey(excessRequest.getLimitInternalKey())
                .setExcessType(excessRequest.getExcessType().toString())
                .setExcessStatus(excessRequest.getExcessStatus().toString())
                .setExcessDetail(ExcessDetailRecord.newBuilder()
                        .setProcessDate(excessRequest.getExcessDetail().getProcessDate())
                        .setProcessTimestamp(excessRequest.getExcessDetail().getProcessTimestamp()) // PROCESS TIMESTAMP
                        .setLimitOrigin(excessRequest.getExcessDetail().getLimitOrigin())
                        .setLimitShortName(excessRequest.getExcessDetail().getLimitShortName())
                        .setPeriod(excessRequest.getExcessDetail().getPeriod())
                        .setLimitCurrency(excessRequest.getExcessDetail().getLimitCurrency())
                        .setLimitAmount(excessRequest.getExcessDetail().getLimitAmount().toString())
                        .setUsed(excessRequest.getExcessDetail().getUsed().toString())
                        .setExcessReason(excessRequest.getExcessDetail().getExcessReason())
                        .setMetadata(excessRequest.getExcessDetail().getMetadata())
                        .build())
                .build();
    }

    public ExcessRequest excessRequestAvroModelToExcessRequest(ExcessRequestAvroModel excessRequestAvroModel) {

        return ExcessRequest.builder()
                .excessId(excessRequestAvroModel.getExcessId())
                .metricType(MetricType.valueOf(excessRequestAvroModel.getMetricType()))
                .excessMetric(ExcessMetric.valueOf(excessRequestAvroModel.getExcessMetric()))
                .excessBeginDate(excessRequestAvroModel.getExcessBeginDate())
                .excessBeginTimestamp(excessRequestAvroModel.getExcessBeginTimestamp())
                .excessEndDate(excessRequestAvroModel.getExcessEndDate())
                .excessEndTimestamp(excessRequestAvroModel.getExcessEndTimestamp())
                .limitInternalKey(excessRequestAvroModel.getLimitInternalKey())
                .excessType(ExcessType.valueOf(excessRequestAvroModel.getExcessType()))
                .excessStatus(ExcessStatus.valueOf(excessRequestAvroModel.getExcessStatus()))
                .excessDetail(ExcessDetailDto.builder()
                        .processDate(excessRequestAvroModel.getExcessDetail().getProcessDate())
                        .processTimestamp(excessRequestAvroModel.getExcessDetail().getProcessTimestamp())
                        .limitOrigin(excessRequestAvroModel.getExcessDetail().getLimitOrigin())
                        .limitShortName(excessRequestAvroModel.getExcessDetail().getLimitShortName())
                        .period(excessRequestAvroModel.getExcessDetail().getPeriod())
                        .limitCurrency(excessRequestAvroModel.getExcessDetail().getLimitCurrency())
                        .limitAmount(new BigDecimal(excessRequestAvroModel.getExcessDetail().getLimitAmount().toString()))
                        .used(new BigDecimal(excessRequestAvroModel.getExcessDetail().getUsed().toString()))
                        .excessReason(excessRequestAvroModel.getExcessDetail().getExcessReason())
                        .metadata(excessRequestAvroModel.getExcessDetail().getMetadata())
                        .build())
                .build();
    }
}