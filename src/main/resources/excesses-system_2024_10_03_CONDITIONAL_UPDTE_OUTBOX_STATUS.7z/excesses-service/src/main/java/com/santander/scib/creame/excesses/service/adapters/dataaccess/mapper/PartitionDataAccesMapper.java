package com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import org.springframework.stereotype.Component;

@Component
public class PartitionDataAccesMapper {

    public PartitionEntity partitionToPartitionEntity(Partition partition) {
        return PartitionEntity.builder()
                .partitionId(partition.getId().getValue())
                .partitionStatus(partition.getPartitionStatus())
                .build();
    }

    public Partition partitionEntityToPartition(PartitionEntity partitionEntity) {
        return Partition.builder()
                .partitionId(new PartitionId(partitionEntity.getPartitionId()))
                .partitionStatus(partitionEntity.getPartitionStatus())
                .build();
    }
}
