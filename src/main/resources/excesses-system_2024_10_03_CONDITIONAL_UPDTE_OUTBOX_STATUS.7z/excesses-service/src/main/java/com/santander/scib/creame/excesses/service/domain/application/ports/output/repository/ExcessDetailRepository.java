package com.santander.scib.creame.excesses.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;

import java.util.List;
import java.util.Optional;

public interface ExcessDetailRepository {
    Optional<ExcessDetail> getByExcessIdAndProcessTimestamp(ExcessId excessId, String processTimestamp);
    ExcessDetail save(ExcessDetail excessDetail);
    ExcessDetail update(ExcessDetail excessDetail);
    void flush();
}
