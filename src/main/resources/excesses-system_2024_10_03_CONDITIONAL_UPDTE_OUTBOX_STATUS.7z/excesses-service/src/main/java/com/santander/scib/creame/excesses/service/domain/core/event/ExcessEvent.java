package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;

import java.time.ZonedDateTime;

public abstract class ExcessEvent implements DomainEvent<Excess> {
    private final Excess excess;
    private final ZonedDateTime createdAt;

    public ExcessEvent(Excess excess, ZonedDateTime createdAt) {
        this.excess = excess;
        this.createdAt = createdAt;
    }

    @Override
    public Excess getEntity() {
        return this.excess;
    }

    @Override
    public ZonedDateTime getCreatedAt() {
        return this.createdAt;
    }

    @Override
    public String getId(){
        return this.excess.getId().getValue();
    }
}

