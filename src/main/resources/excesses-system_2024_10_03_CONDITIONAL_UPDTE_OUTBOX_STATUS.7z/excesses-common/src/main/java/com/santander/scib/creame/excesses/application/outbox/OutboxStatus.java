package com.santander.scib.creame.excesses.application.outbox;
public enum OutboxStatus {
    STARTED(0), COMPLETED(1), RETRY(2), FAILED(3);

    private final Integer outboxStatus;
    OutboxStatus(Integer outboxStatus){
        this.outboxStatus = outboxStatus;
    }
    public Integer getOutboxStatus(){
        return outboxStatus;
    }
}
