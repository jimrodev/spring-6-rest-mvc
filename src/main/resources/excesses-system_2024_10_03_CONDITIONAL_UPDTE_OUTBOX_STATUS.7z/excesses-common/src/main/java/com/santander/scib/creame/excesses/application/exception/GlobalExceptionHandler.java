package com.santander.scib.creame.excesses.application.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.server.ServerWebInputException;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@ControllerAdvice
public class GlobalExceptionHandler {

    private final ObjectMapper objectMapper;

    public GlobalExceptionHandler(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @ResponseBody
    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<ResponseBodyError> handleException(Exception exception) {
        log.error(exception.getMessage(), exception);
        return ResponseEntity
                .internalServerError()
                .body(
                        ResponseBodyError.builder()
                                .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                .error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
                                .message("Unexpected error!")
                                .build());
    }

    @ResponseBody
    @ExceptionHandler(value = {ServerWebInputException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ResponseBodyError> handleException(ServerWebInputException exception) {
        if (exception.getRootCause() instanceof InvalidFormatException) {

            String errorMessage = exception.getRootCause().getMessage();
            String responseMessage = errorMessage.substring(errorMessage.indexOf("valueobject.") + 12, errorMessage.indexOf("]")+1);

            return ResponseEntity
                    .badRequest()
                    .body(
                        ResponseBodyError.builder()
                                .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                                .status(HttpStatus.BAD_REQUEST.value())
                                .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                                .message(exception.getBody().getDetail() + ". " + responseMessage)
                                .build());
        } else {
            return ResponseEntity
                    .badRequest()
                    .body(
                        ResponseBodyError.builder()
                                .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                                .status(HttpStatus.BAD_REQUEST.value())
                                .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                                .message(exception.getBody().getDetail())
                                .build());
        }
    }

    @ResponseBody
    @ExceptionHandler(value = {ValidationException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ResponseBodyError> handleException(ValidationException exception) throws JsonProcessingException {

       if (exception instanceof ConstraintViolationException) {
           Map errorList = ((ConstraintViolationException) exception).getConstraintViolations().stream()
                   .map(fieldError -> {
                       Pair<String, String> errorMap = Pair.of(((PathImpl) fieldError.getPropertyPath()).getLeafNode().toString(), fieldError.getMessage());
                       return errorMap;
                   }).collect(Collectors.groupingBy(Pair::getFirst, Collectors.mapping(Pair::getSecond, Collectors.toList())));

           return ResponseEntity
                   .badRequest()
                   .body(
                       ResponseBodyError.builder()
                               .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                               .status(HttpStatus.BAD_REQUEST.value())
                               .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                               .message(objectMapper.writeValueAsString(errorList.entrySet().stream().sorted(Map.Entry.comparingByKey())))
                               .build()
                               );

       } else {
           String exceptionMessage = exception.getMessage();
           log.error(exceptionMessage, exception);

           return ResponseEntity
                   .badRequest()
                   .body(
                       ResponseBodyError.builder()
                               .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                               .status(HttpStatus.BAD_REQUEST.value())
                               .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                               .message(exceptionMessage)
                               .build());

       }
    }

    private String extractViolationsFromException(ConstraintViolationException validationException) {
        return validationException.getConstraintViolations()
                .stream()
                .map(ConstraintViolation::getMessage)
                .collect(Collectors.joining("--"));
    }

}
