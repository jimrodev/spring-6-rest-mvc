package com.santander.scib.creame.excesses.domain.valueobject;

public enum WorkflowGroup {
    GLOBAL_CONTROL(0), IT_ADMINISTRATOR(1), ADMISSION(2), FRONT_OFFICE(3), BANKER(4);

    private final Integer workflowGroup;
    WorkflowGroup(Integer workflowGroup){
        this.workflowGroup = workflowGroup;
    }
    public Integer getWorkflowGroup(){
        return workflowGroup;
    }
}
