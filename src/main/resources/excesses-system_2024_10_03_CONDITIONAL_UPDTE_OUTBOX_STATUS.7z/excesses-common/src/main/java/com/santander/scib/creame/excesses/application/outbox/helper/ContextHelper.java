package com.santander.scib.creame.excesses.application.outbox.helper;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;

import java.util.HashMap;
import java.util.Map;

public class ContextHelper {

    public enum ContextSection {MESSAGE,TRANSPORT, BATCH}

    public static Map<String, String> getMessageHeaders(ContextMessage context){
        Map<String, String> headers = new HashMap<>();
        // EME - Excess Message Engine Properties

        // EME.messageId: Is the unique identifier of the message in the system (Excess primary Key)
        if(context.getMessageId()!=null){
            headers.put("messageId", context.getMessageId());
        }
        // EME.interchangeId: Defines the unique ID that is used to group the messages that resulted from the same interchange among async services.
        if(context.getInterchangeId()!=null){
            headers.put("interchangeId", context.getInterchangeId().toString());
        }
        // EME.messageType: Specifies the type of the message.
        if(context.getMessageType()!=null){
            headers.put("messageType", context.getMessageType());
        }
        // EME.eventSource: The source of the event.
        if(context.getEventSource()!=null){
            headers.put("eventSource", context.getEventSource());
        }
        // EME.InboundTransportType: Specifies the type of adapter that received this message and submitted it into the system. s3://, https://, file://, kafka://
        if(context.getInboundTransportType()!=null){
            headers.put("inboundTransportType", context.getInboundTransportType());
        }
        // EME.InboundTransportLocation: Specifies the location (URI) on which the message was received by the handler.
        if(context.getInboundTransportLocation()!=null){
            headers.put("inboundTransportLocation", context.getInboundTransportLocation());
        }
        // EME.OutboundTransportType: Specifies the type of adapter used to send the message. The available adapter types are s3://, https://, file://, kafka://
        if(context.getOutboundTransportType()!=null){
            headers.put("outboundTransportType", context.getOutboundTransportType());
        }
        // EME.OutboundTransportLocation: Specifies the destination location URI where the message is sent. The URI may contain the adapter prefix, such as http://.
        //                                The adapter prefix is used by the Messaging Engine to determine the type of adapter to use when sending the message.
        if(context.getOutboundTransportLocation()!=null){
            headers.put("outboundTransportLocation", context.getOutboundTransportLocation());
        }
        // EME.ReceivePortID: Identifies the receive port on which the message was received.
        if(context.getReceivePortID()!=null){
            headers.put("receivePortID", context.getReceivePortID());
        }
        // EME.SendPortID: Specifies the ID of the send port.
        if(context.getSendPortID()!=null){
            headers.put("sendPortID", context.getSendPortID());
        }
        // EME.FailureCode: Error code associated to the current message
        if(context.getFailureCode()!=null){
            headers.put("failureCode", context.getFailureCode());
        }
        // EME.FailureMessages: Array with the error description
        if(context.getFailureMessages()!=null){
            headers.put("failureMessages", context.getFailureMessages());
        }
        // EME.BatchId: Identifies the current Batch of messages
        if(context.getBatchId()!=null){
            headers.put("batchId", context.getBatchId());
        }
        // EME.BatchTotalNumber: Specifies the messages total number in the current batch.
        if(context.getBatchTotalNumber()!=null){
            headers.put("batchTotalNumber", context.getBatchTotalNumber());
        }
        // EME.BatchSequenceNumber: Specifies the position of the current message in the batch.
        if(context.getBatchSequenceNumber()!=null){
            headers.put("batchSequenceNumber", context.getBatchSequenceNumber());
        }

        // S3 - S3 Adapter Properties

        // S3.BucketName: The name of the S3 bucket
        if(context.getS3BucketName()!=null){
            headers.put("s3BucketName", context.getS3BucketName());
        }
        // S3.s3keyName: The key of the file in the S3 bucket
        if(context.getS3keyName()!=null){
            headers.put("s3keyName", context.getS3keyName());
        }
        return headers;
    }

    public static ContextMessage clone(ContextMessage context){
        return ContextMessage.builder()
                .messageId(context.getMessageId())
                .interchangeId(context.getInterchangeId())
                .messageType(context.getMessageType())
                .eventSource(context.getEventSource())
                .inboundTransportType(context.getInboundTransportType())
                .inboundTransportLocation(context.getInboundTransportLocation())
                .outboundTransportType(context.getOutboundTransportType())
                .outboundTransportLocation(context.getOutboundTransportLocation())
                .receivePortID(context.getReceivePortID())
                .sendPortID(context.getSendPortID())
                .failureCode(context.getFailureCode())
                .failureMessages(context.getFailureMessages())
                .batchId(context.getBatchId())
                .batchTotalNumber(context.getBatchTotalNumber())
                .batchSequenceNumber(context.getBatchSequenceNumber())
                .s3BucketName(context.getS3BucketName())
                .s3keyName(context.getS3keyName())
                .build();
        }

        public static ContextMessage clean(ContextMessage context, ContextSection section){
            switch (section){
                case MESSAGE -> {
                    context.setMessageId(null);
                    context.setMessageType(null);
                    context.setInterchangeId(null);
                    context.setEventSource(null);
                    return context;
                }
                case TRANSPORT -> {
                    context.setInboundTransportType(null);
                    context.setInboundTransportLocation(null);
                    context.setOutboundTransportType(null);
                    context.setOutboundTransportLocation(null);
                    context.setReceivePortID(null);
                    context.setSendPortID(null);
                    // s3
                    context.setS3BucketName(null);
                    context.setS3keyName(null);
                    return context;
                }
                case BATCH -> {
                    context.setBatchId(null);
                    context.setBatchTotalNumber(null);
                    context.setBatchSequenceNumber(null);
                    return context;
                }
                default ->{
                    return context;
                }
            }

        }
}
