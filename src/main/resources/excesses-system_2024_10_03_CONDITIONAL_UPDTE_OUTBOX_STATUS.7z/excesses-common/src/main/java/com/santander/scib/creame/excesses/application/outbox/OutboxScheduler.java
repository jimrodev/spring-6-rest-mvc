package com.santander.scib.creame.excesses.application.outbox;

import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.OutboxMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.OutboxHelper;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementation of the SpoolScheduler interface for Outbox messages.
 *
 * @param <T> the type of the Helper. This type must extend OutboxHelper interface
 * OutboxHelper contains the common behavior when dealing with OutboxRepository output ports
 *
 * @param <U> the type of the MessagePublisher. This type must extend OutboxMessagePublisher interface
 * OutboxMessagePublisher contains the common behavior when dealing with OutboxMessagePublisher output ports
 */
@Slf4j
@Configuration
@EnableScheduling
public abstract class OutboxScheduler<T extends OutboxHelper<?>, U extends OutboxMessagePublisher<OutboxMessage>>
            implements SpoolScheduler{

    private final T outboxHelper;
    private final U outboxMessagePublisher;
    private ZonedDateTime currentCreateAt;

    /**
     * Constructs a OutboxScheduler with the given OutboxHelper and OutboxMessagePublisher.
     *
     * @param outboxHelper, OutboxHelper implementation that contains the OutboxRepository output port implementations to interact with the database
     * @param outboxMessagePublisher, OutboxMessagePublisher output port implementation to interact with the event bus
     */
    public OutboxScheduler(T outboxHelper, U outboxMessagePublisher) {
        this.outboxHelper = outboxHelper;
        this.outboxMessagePublisher = outboxMessagePublisher;
        this.currentCreateAt = null;
    }

    /**
     * Processes a batch of messages from the Spool table.
     */
    public void process() {
        Optional<List<OutboxMessage>> outboxMessages = Optional.empty();

        // PROCESS SPOOL TABLE
        // FIRST SLIDE (SpoolBatchSize)
        if (currentCreateAt == null){
            outboxMessages = outboxHelper.getOutboxMessageByOutboxStatus(
                            OutboxStatus.STARTED);      // (RETRY - FAILED) - IMPLEMENTAR RETRY (DELAY-COUNT-INTERVAL)
        }else {
            // Go through the table until the end
            // NEXT SLIDE (SpoolBatchSize)
            outboxMessages = outboxHelper.getOutboxMessageByCreatedAtAndOutboxStatus(
                            this.currentCreateAt,
                            OutboxStatus.STARTED);      // (RETRY - FAILED) - IMPLEMENTAR RETRY (DELAY-COUNT-INTERVAL)
        }
        log.info("Outbox scheduler found {} OutboxMessages ", outboxMessages.get().isEmpty()?0:outboxMessages.get().size());

        if (outboxMessages.isPresent() && !outboxMessages.get().isEmpty()) {
            List<OutboxMessage> outboxMessagesList = outboxMessages.get();
            /*log.info("Received {} OutboxMessages with ids: {}, sending to message bus!",
                    outboxMessagesList.size(),
                    outboxMessagesList.stream().map(outboxMessage ->
                            outboxMessage.getOutboxId().toString()).collect(Collectors.joining(",")));*/
            outboxMessagesList
                    .parallelStream()
                    .forEach(outboxMessage -> outboxMessagePublisher.publish(outboxMessage,
                                                                             outboxHelper::updateOutboxStatus));
        }
    }

    /**
     * Clear the Spool table.
     */
    public void clear() {
        Optional<List<OutboxMessage>> outboxMessages =
                outboxHelper.getOutboxMessageByOutboxStatus(
                        OutboxStatus.COMPLETED);
                        // ** OutboxStatus.FAILED
                        // QUE HACEMOS CON LAS FAILED
                        // PONER UN RETRY COUNT Y RETRY INTERVAL
                        // ESTE CASO HAY QUE ANALIZARLO

        // EN PRODUCCIÓN PODEMOS EJECUTARLO SIN LA CONSULTA PREVIA
        if (outboxMessages.isPresent() && (!outboxMessages.get().isEmpty())) {
            List<OutboxMessage> outboxMessagesList = outboxMessages.get();
            log.info("Received {} OutboxMessages for clean-up. ids: {}",
                    outboxMessagesList.size(),
                    outboxMessagesList.stream().map(outboxMessage ->
                            outboxMessage.getOutboxId().toString()).collect(Collectors.joining(",")));
            int rowsAffected = outboxHelper.deleteOutboxMessageByOutboxStatus(OutboxStatus.COMPLETED);

            log.info("{} OrderPaymentOutboxMessage deleted!", rowsAffected);
        }
    }
}
