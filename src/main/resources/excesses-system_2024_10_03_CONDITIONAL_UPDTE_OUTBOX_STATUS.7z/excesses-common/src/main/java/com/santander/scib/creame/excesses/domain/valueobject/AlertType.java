package com.santander.scib.creame.excesses.domain.valueobject;

public enum AlertType {
    A, B, C, D, E
}
