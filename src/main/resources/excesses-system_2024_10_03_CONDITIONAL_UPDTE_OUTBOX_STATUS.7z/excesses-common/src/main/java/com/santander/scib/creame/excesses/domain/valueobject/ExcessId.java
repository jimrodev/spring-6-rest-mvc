package com.santander.scib.creame.excesses.domain.valueobject;

public class ExcessId extends BaseId<String>{

    public ExcessId(String value) {
        super(value);
    }
}
