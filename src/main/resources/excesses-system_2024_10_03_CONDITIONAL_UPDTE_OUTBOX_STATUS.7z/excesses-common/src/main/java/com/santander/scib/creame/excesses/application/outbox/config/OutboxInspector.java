package com.santander.scib.creame.excesses.application.outbox.config;

import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component
public class OutboxInspector implements StatementInspector {

    private final String OutboxEntity = "OutboxEntity";
    private final String CoordinatorEntity = "CoordinatorEntity";

    @Value("#{@OutboxTables['outbox-table-name']}")
    String OutboxTableName;
    @Value("#{@OutboxTables['coordinator-table-name']}")
    String CoordinatorTableName;

    @Override
    public String inspect(String sql) {
        if(sql.contains(OutboxEntity))
            return sql.replace(OutboxEntity, OutboxTableName);
        if(sql.contains(CoordinatorEntity))
            return sql.replace(CoordinatorEntity, CoordinatorTableName);
        return sql;
    }
}
