package com.santander.scib.creame.excesses.domain.valueobject;

public enum WorkflowStatus {

    PENDING(0), ASSIGNED(1), FAILED(2);

    private final Integer workflowStatus;
    WorkflowStatus(Integer excessStatus){
        this.workflowStatus = excessStatus;
    }
    public Integer getExcessStatus(){
        return workflowStatus;
    }
}
