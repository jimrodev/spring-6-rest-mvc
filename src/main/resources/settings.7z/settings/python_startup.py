# Script de inicialización para Python
# Este archivo se ejecuta automáticamente al iniciar Python

print("=" * 50)
print("🐍 Interactive Python Console")
print("=" * 50)

# Configurar IPython para usar prompt clásico >>>
try:
    from IPython import get_ipython
    from IPython.terminal.prompts import ClassicPrompts

    ip = get_ipython()
    if ip:
        # Configurar prompts clásicos
        ip.prompts = ClassicPrompts(ip)

except ImportError:
    print("⚠️  No se pudo configurar el prompt clásico")

# print("ℹ️  Para cambiar colores usa:")
# print("   %colors Linux    (colores brillantes)")
# print("   %colors LightBG  (fondo claro)")
# print("   %colors Neutral  (colores suaves)")
# print("   %colors NoColor  (sin colores)")
