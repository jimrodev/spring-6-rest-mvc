package com.santander.scib.excesses.domain.event;
public interface DomainEvent<T> {
    void fire();
}
