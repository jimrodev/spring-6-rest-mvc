package com.santander.scib.excesses.domain.entity;

public abstract class AggregateRoot<ID> extends BaseEntity<ID> {
}
