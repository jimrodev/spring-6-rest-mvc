package com.santander.scib.excesses.domain.valueobject;

public enum AlertType {
    A, B, C, D, E
}
