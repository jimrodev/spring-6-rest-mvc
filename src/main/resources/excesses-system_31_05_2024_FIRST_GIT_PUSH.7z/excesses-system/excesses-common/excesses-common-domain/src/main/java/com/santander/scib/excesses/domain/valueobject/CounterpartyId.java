package com.santander.scib.excesses.domain.valueobject;

import java.util.UUID;

public class CounterpartyId extends BaseId<String>{

    public CounterpartyId(String value) {
        super(value);
    }
}
