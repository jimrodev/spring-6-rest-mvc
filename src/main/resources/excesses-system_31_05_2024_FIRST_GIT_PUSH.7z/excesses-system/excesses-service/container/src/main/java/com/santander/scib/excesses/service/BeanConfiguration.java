package com.santander.scib.excesses.service;

import com.santander.scib.excesses.service.domain.ExcessDomainService;
import com.santander.scib.excesses.service.domain.ExcessDomainServiceImpl;
import com.santander.scib.excesses.service.domain.PartitionDomainService;
import com.santander.scib.excesses.service.domain.PartitionDomainServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public ExcessDomainService excessDomainService() {
        return new ExcessDomainServiceImpl();
    }
    @Bean
    public PartitionDomainService partitionDomainService(){return new PartitionDomainServiceImpl();}
}
