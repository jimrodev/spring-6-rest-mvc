package com.santander.scib.excesses.service.domain.ports.input.service;

import com.santander.scib.excesses.service.domain.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.dto.ExcessResponse;
import com.santander.scib.excesses.service.domain.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.dto.PartitionResponse;
import jakarta.validation.Valid;

public interface ExcessApplicationService {

    ExcessResponse processExcess(@Valid ExcessRequest excessRequest);

    PartitionResponse processPartition(@Valid PartitionRequest partitionRequest);

}
