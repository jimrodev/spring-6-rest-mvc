package com.santander.scib.excesses.service.domain.ports.input.message.listener;

import com.santander.scib.excesses.service.domain.entity.Partition;

public interface PartitionRequestMessageListener {
    void process(Partition partition);
}
