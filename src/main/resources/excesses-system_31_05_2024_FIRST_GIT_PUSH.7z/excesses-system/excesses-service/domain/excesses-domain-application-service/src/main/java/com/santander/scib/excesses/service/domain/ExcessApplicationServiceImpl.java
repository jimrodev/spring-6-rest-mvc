package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.service.domain.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.dto.ExcessResponse;
import com.santander.scib.excesses.service.domain.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.dto.PartitionResponse;
import com.santander.scib.excesses.service.domain.ports.input.service.ExcessApplicationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class ExcessApplicationServiceImpl implements ExcessApplicationService {
    private final ExcessCreateHandler excessCreateHandler;
    private final PartitionProcessHandler partitionProcessHandler;
    public ExcessApplicationServiceImpl(ExcessCreateHandler excessCreateHandler, PartitionProcessHandler partitionProcessHandler) {
        this.excessCreateHandler = excessCreateHandler;
        this.partitionProcessHandler = partitionProcessHandler;
    }

    @Override
    public ExcessResponse processExcess(ExcessRequest excessRequest) {

        // AHORA SOLO HAY UN HANDLER PARA LA CREACIÓN PORQUE ES LA ÚNICA FUNCIONALIDAD QUE CONOCEMOS
        // HAY QUE CREAR UN HANDLER PARA CADA OPERACIÓN DONDE VA TODA LA LOGICA DE DICHA OPERACIÓN
        // SOLID - RESPONSABILIDAD MINIMA
        return excessCreateHandler.create(excessRequest);
    }

    @Override
    public PartitionResponse processPartition(PartitionRequest partitionRequest) {

        return partitionProcessHandler.process(partitionRequest);
    }
}
