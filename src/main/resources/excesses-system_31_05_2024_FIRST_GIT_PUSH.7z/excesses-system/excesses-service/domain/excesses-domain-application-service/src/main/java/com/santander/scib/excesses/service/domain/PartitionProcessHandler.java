package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.service.domain.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.dto.PartitionResponse;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.event.PartitionEvent;
import com.santander.scib.excesses.service.domain.mapper.PartitionMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PartitionProcessHandler {

    private final PartitionProcessHelper partitionProcessHelper;
    private final PartitionMapper partitionMapper;

    public PartitionProcessHandler(PartitionProcessHelper partitionProcessHelper, PartitionMapper partitionMapper) {
        this.partitionProcessHelper = partitionProcessHelper;
        this.partitionMapper = partitionMapper;
    }

    PartitionResponse process(PartitionRequest partitionRequest){

        PartitionEvent partitionEvent = partitionProcessHelper.process(partitionRequest);
        log.info("Partition is processed with id: {}", partitionEvent.getPartition().getId().getValue());
        partitionEvent.fire();
        return partitionMapper.PartitionToPartitionResponse(partitionEvent.getPartition());
    }
}
