package com.santander.scib.excesses.service.domain.ports.output.repository;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.domain.entity.Partition;

import java.util.Optional;

public interface PartitionRepository {

    Partition save(Partition partition);
    Optional<Partition> findByPartitionId(PartitionId partitionId);
}
