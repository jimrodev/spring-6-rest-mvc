package com.santander.scib.excesses.service.domain.ports.output.repository;

import com.santander.scib.excesses.service.domain.entity.Excess;

public interface ExcessRepository {

    Excess save(Excess excess);
    Excess update(Excess excess);
}
