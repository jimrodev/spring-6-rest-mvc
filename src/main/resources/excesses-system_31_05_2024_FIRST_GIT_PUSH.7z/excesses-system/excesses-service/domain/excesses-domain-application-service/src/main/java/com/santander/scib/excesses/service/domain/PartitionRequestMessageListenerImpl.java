package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.ports.input.message.listener.PartitionRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class PartitionRequestMessageListenerImpl implements PartitionRequestMessageListener {
    @Override
    public void process(Partition partition) {

    }
}
