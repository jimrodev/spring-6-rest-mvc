package com.santander.scib.excesses.service.domain.mapper;

import com.santander.scib.excesses.domain.valueobject.*;
import com.santander.scib.excesses.service.domain.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.dto.ExcessResponse;
import com.santander.scib.excesses.service.domain.entity.Excess;
import org.springframework.stereotype.Component;

@Component
public class ExcessMapper {
    public Excess ExcessRequestToExcess(ExcessRequest excessRequest)
    {
        return Excess.builder()
                .excessId(new ExcessId(excessRequest.getExcessId()))
                .limitOrigin(excessRequest.getLimitOrigin())
                .limitShortName(excessRequest.getLimitShortName())
                .metricType(excessRequest.getMetricType())
                .excessMetric(excessRequest.getExcessMetric())
                .period(excessRequest.getPeriod())
                .limitCurrency(excessRequest.getLimitCurrency())
                .limitAmount(excessRequest.getLimitAmount())
                .used(excessRequest.getUsed())
                .excessReason(excessRequest.getExcessReason())
                .excessBeginDate(excessRequest.getExcessBeginDate())
                .excessBeginTimestamp(excessRequest.getExcessBeginTimestamp())
                .excessEndDate(excessRequest.getExcessEndDate())
                .excessEndTimestamp(excessRequest.getExcessEndTimestamp())
                .limitInternalKey(excessRequest.getLimitInternalKey())
                .excessType(excessRequest.getExcessType())
                .excessStatus(excessRequest.getExcessStatus())
                .build();
    }

    public ExcessResponse ExcessToExcessResponse(Excess excess){
        return ExcessResponse.builder()
                .excessId(excess.getId().getValue())
                .limitOrigin(excess.getLimitOrigin())
                .limitShortName(excess.getLimitShortName())
                .metricType(excess.getMetricType())
                .excessMetric(excess.getExcessMetric())
                .period(excess.getPeriod())
                .limitCurrency(excess.getLimitCurrency())
                .limitAmount(excess.getLimitAmount())
                .used(excess.getUsed())
                .excessReason(excess.getExcessReason())
                .excessBeginDate(excess.getExcessBeginDate())
                .excessBeginTimestamp(excess.getExcessBeginTimestamp())
                .excessEndDate(excess.getExcessEndDate())
                .excessEndTimestamp(excess.getExcessEndTimestamp())
                .limitInternalKey(excess.getLimitInternalKey())
                .excessType(excess.getExcessType())
                .excessStatus(excess.getExcessStatus())
                .build();
    }
}
