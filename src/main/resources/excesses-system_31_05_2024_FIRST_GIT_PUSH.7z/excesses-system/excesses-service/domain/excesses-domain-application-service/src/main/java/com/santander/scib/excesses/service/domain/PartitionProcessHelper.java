package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.domain.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.event.PartitionEvent;
import com.santander.scib.excesses.service.domain.event.PartitionProcessEvent;
import com.santander.scib.excesses.service.domain.mapper.PartitionMapper;
import com.santander.scib.excesses.service.domain.ports.output.message.publisher.PartitionProcessMessagePublisher;
import com.santander.scib.excesses.service.domain.ports.output.repository.PartitionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Component
public class PartitionProcessHelper {

    private final PartitionDomainService partitionDomainService;
    private final PartitionRepository partitionRepository;
    private final PartitionMapper partitionMapper;
    private final PartitionProcessMessagePublisher partitionProcessMessagePublisher;

    public PartitionProcessHelper(PartitionDomainService partitionDomainService,
                                  PartitionRepository partitionRepository,
                                  PartitionMapper partitionMapper,
                                  PartitionProcessMessagePublisher partitionProcessMessagePublisher) {
        this.partitionDomainService = partitionDomainService;
        this.partitionRepository = partitionRepository;
        this.partitionMapper = partitionMapper;
        this.partitionProcessMessagePublisher = partitionProcessMessagePublisher;
    }

    @Transactional
    public PartitionEvent process(PartitionRequest partitionRequest){
        Optional<Partition> foundPartition = partitionRepository.findByPartitionId(new PartitionId(partitionRequest.getPartitionId()));
        Partition partition = foundPartition.orElseGet(() -> partitionMapper.PartitionRequestToPartition(partitionRequest));

        PartitionEvent partitionEvent = partitionDomainService.process(partition,
                                                                partitionProcessMessagePublisher);

        // PROCESAR EL FICHERO DESDE S3
        partitionRepository.save(partition);

        return partitionEvent;
    }
}
