package com.santander.scib.excesses.service.domain.dto;

import com.opencsv.bean.CsvBindByName;
import com.santander.scib.excesses.application.validation.ValueOfEnum;
import com.santander.scib.excesses.domain.valueobject.*;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessRequest {
    @CsvBindByName(column = "excess_id")
    @NotEmpty(message = "{not.empty}")
    @Size(max = 25, message = "{size.max}" + ": 25")
    private String excessId;

    @CsvBindByName(column = "limit_origin")
    @NotEmpty(message = "{not.empty}")
    private String limitOrigin;

    @CsvBindByName(column = "limit_short_name")
    @NotEmpty(message = "{not.empty}")
    private String limitShortName;

    @CsvBindByName(column = "metric_type")
    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = MetricType.class)
    private MetricType metricType;

    @CsvBindByName(column = "excess_metric")
    @NotNull(message = "{not.null}")
    private ExcessMetric excessMetric;

    @CsvBindByName(column = "period")
    @NotEmpty(message = "{not.empty}")
    private String period;

    @CsvBindByName(column = "limit_currency")
    @NotEmpty(message = "{not.empty}")
    private String limitCurrency;

    @CsvBindByName(column = "limit_amount")
    @NotNull(message = "{not.null}")
    private BigDecimal limitAmount;

    @CsvBindByName(column = "used")
    @NotNull(message = "{not.null}")
    private BigDecimal used;

    @CsvBindByName(column = "excess_reason")
    @NotEmpty(message = "{not.empty}")
    private String excessReason;

    @CsvBindByName(column = "excess_begin_date")
    @NotEmpty(message = "{not.empty}")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessBeginDate;

    @CsvBindByName(column = "excess_begin_timestamp")
    @NotEmpty(message = "{not.empty}")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessBeginTimestamp;

    @CsvBindByName(column = "excess_end_date")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessEndDate;

    @CsvBindByName(column = "excess_end_timestamp")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessEndTimestamp;

    @CsvBindByName(column = "limit_internal_key")
    @NotEmpty(message = "{not.empty}")
    private String limitInternalKey;

    //@CsvBindByName(column = "excess_type")
    private ExcessType excessType;

    //@CsvBindByName(column = "excess_status")
    private ExcessStatus excessStatus;

    // FALTAN LAS FECHAS!! VER FORMATO DE FECHAS
}
