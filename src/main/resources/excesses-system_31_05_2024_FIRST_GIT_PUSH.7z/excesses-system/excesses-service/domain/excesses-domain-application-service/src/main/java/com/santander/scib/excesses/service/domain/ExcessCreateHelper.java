package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.service.domain.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.exception.ExcessDomainException;
import com.santander.scib.excesses.service.domain.mapper.ExcessMapper;
import com.santander.scib.excesses.service.domain.ports.output.message.publisher.ExcessCreatedMessagePublisher;
import com.santander.scib.excesses.service.domain.ports.output.repository.ExcessRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
public class ExcessCreateHelper {

    private final ExcessDomainService excessesDomainService;
    private final ExcessRepository excessRepository;
    private final ExcessMapper excessMapper;
    private final ExcessCreatedMessagePublisher excessRequestMessagePublisher;

    public ExcessCreateHelper(ExcessDomainService excessesDomainService, ExcessRepository excessRepository, ExcessMapper excessMapper, ExcessCreatedMessagePublisher excessRequestMessagePublisher) {
        this.excessesDomainService = excessesDomainService;
        this.excessRepository = excessRepository;
        this.excessMapper = excessMapper;
        this.excessRequestMessagePublisher = excessRequestMessagePublisher;
    }

    @Transactional
    public ExcessCreatedEvent persistExcess(ExcessRequest excessRequest){

        Excess excess = excessMapper.ExcessRequestToExcess(excessRequest);
        ExcessCreatedEvent excessCreatedEvent = excessesDomainService.create(excess, excessRequestMessagePublisher);
        save(excess);
        return excessCreatedEvent;
    }

    private Excess save(Excess excess) {
        Excess excessResult = excessRepository.save(excess);
        if (excessResult == null) {
            log.error("Could not save excess!");
            throw new ExcessDomainException("Could not save excess!");
        }
        log.info("Excess is saved with id: {}", excessResult.getId().getValue());
        return excessResult;
    }

}
