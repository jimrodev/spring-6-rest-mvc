package com.santander.scib.excesses.service.domain.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Excess;

import java.time.ZonedDateTime;

public class ExcessUpdatedEvent extends ExcessEvent {

    private final DomainEventPublisher<ExcessUpdatedEvent> excessUpdatedDomainEventPublisher;

    public ExcessUpdatedEvent(Excess excess,
                              ZonedDateTime createdAt,
                              DomainEventPublisher<ExcessUpdatedEvent> excessUpdatedDomainEventPublisher) {
        super(excess, createdAt);
        this.excessUpdatedDomainEventPublisher = excessUpdatedDomainEventPublisher;
    }

    @Override
    public void fire() {
        excessUpdatedDomainEventPublisher.publish(this);
    }
}

