package com.santander.scib.excesses.service.domain.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionProcessEvent extends PartitionEvent {

    private final DomainEventPublisher<PartitionProcessEvent> partitionProcessEventPublisher;

    public PartitionProcessEvent(Partition partition,
                                 ZonedDateTime createdAt,
                                 DomainEventPublisher<PartitionProcessEvent> partitionProcessEventPublisher) {
        super(partition, createdAt);
        this.partitionProcessEventPublisher = partitionProcessEventPublisher;
    }

    @Override
    public void fire() {
        partitionProcessEventPublisher.publish(this);
    }
}
