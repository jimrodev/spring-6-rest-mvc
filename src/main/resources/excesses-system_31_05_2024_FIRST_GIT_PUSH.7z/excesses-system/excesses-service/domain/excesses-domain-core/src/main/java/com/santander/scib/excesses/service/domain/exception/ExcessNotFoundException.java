package com.santander.scib.excesses.service.domain.exception;

import com.santander.scib.excesses.domain.exception.DomainException;

public class ExcessNotFoundException extends DomainException {

    public ExcessNotFoundException(String message) {
        super(message);
    }

    public ExcessNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
