package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.event.PartitionProcessEvent;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static com.santander.scib.excesses.domain.DomainConstants.UTC;

@Slf4j
public class PartitionDomainServiceImpl implements PartitionDomainService {
    @Override
    public PartitionProcessEvent process(Partition partition, DomainEventPublisher<PartitionProcessEvent> partitionProcessDomainEventPublisher) {
        partition.process();
        log.info("Partition with id: {} is driving", partition.getId().getValue());
        return new PartitionProcessEvent(partition,
                ZonedDateTime.now(ZoneId.of(UTC)),
                partitionProcessDomainEventPublisher);
    }
}
