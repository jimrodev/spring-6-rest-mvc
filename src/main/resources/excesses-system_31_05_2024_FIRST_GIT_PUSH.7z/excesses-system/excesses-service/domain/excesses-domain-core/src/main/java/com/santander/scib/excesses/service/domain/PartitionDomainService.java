package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.event.PartitionProcessEvent;
import com.santander.scib.excesses.service.domain.event.PartitionVoidEvent;

public interface PartitionDomainService {

    PartitionProcessEvent process(Partition partition, DomainEventPublisher<PartitionProcessEvent> partitionProcessDomainEventPublisher);

}
