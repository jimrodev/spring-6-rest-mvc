package com.santander.scib.excesses.service.domain.event;



import com.santander.scib.excesses.domain.event.DomainEvent;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.entity.Partition;

import java.time.ZonedDateTime;

public abstract class PartitionEvent implements DomainEvent<Excess> {
    private final Partition partition;
    private final ZonedDateTime createdAt;

    public PartitionEvent(Partition partition, ZonedDateTime createdAt) {
        this.partition = partition;
        this.createdAt = createdAt;
    }

    public Partition  getPartition() {
        return partition;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }
}
