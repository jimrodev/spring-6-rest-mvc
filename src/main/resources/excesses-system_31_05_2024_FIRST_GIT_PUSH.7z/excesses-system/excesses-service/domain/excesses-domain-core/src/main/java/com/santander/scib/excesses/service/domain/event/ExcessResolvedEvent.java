package com.santander.scib.excesses.service.domain.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Excess;

import java.time.ZonedDateTime;

public class ExcessResolvedEvent extends ExcessEvent {

    private final DomainEventPublisher<ExcessResolvedEvent> excessResolvedDomainEventPublisher;

    public ExcessResolvedEvent(Excess excess,
                               ZonedDateTime createdAt,
                               DomainEventPublisher<ExcessResolvedEvent> excessResolvedDomainEventPublisher) {
        super(excess, createdAt);
        this.excessResolvedDomainEventPublisher = excessResolvedDomainEventPublisher;
    }

    @Override
    public void fire() {
        excessResolvedDomainEventPublisher.publish(this);
    }
}
