package com.santander.scib.excesses.service.domain;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.event.ExcessResolvedEvent;
import com.santander.scib.excesses.service.domain.event.ExcessUpdatedEvent;

public interface ExcessDomainService {

    // VER MAS ADELANTE LAS DISTINTAS OPERACIONES FUNCIONALES
    ExcessCreatedEvent create(Excess excess, DomainEventPublisher<ExcessCreatedEvent> excessCreatedDomainEventPublisher);
    ExcessUpdatedEvent update(Excess excess, DomainEventPublisher<ExcessUpdatedEvent> excessUpdatedDomainEventPublisher);
    ExcessResolvedEvent resolve(Excess excess, DomainEventPublisher<ExcessResolvedEvent> excessResolvedDomainEventPublisher);

}
