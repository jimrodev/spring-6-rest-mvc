package com.santander.scib.excesses.service.domain.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionVoidEvent extends PartitionEvent {

    private final DomainEventPublisher<PartitionVoidEvent> partitionVoidEventPublisher;

    public PartitionVoidEvent(Partition partition,
                                 ZonedDateTime createdAt,
                                 DomainEventPublisher<PartitionVoidEvent> partitionVoidEventPublisher) {
        super(partition, createdAt);
        this.partitionVoidEventPublisher = partitionVoidEventPublisher;
    }
    @Override
    public void fire() {
    }
}
