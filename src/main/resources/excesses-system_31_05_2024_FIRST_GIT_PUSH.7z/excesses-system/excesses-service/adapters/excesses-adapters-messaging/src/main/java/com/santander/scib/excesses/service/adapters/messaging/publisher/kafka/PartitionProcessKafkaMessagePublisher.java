package com.santander.scib.excesses.service.adapters.messaging.publisher.kafka;


import com.santander.scib.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.excesses.kafka.producer.KafkaMessageHelper;
import com.santander.scib.excesses.kafka.producer.KafkaProducer;
import com.santander.scib.excesses.service.adapters.messaging.mapper.ExcessMessagingDataMapper;
import com.santander.scib.excesses.service.domain.config.ExcessServiceConfigData;
import com.santander.scib.excesses.service.domain.event.PartitionProcessEvent;
import com.santander.scib.excesses.service.domain.ports.output.message.publisher.PartitionProcessMessagePublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PartitionProcessKafkaMessagePublisher implements PartitionProcessMessagePublisher {

    private final ExcessMessagingDataMapper excessMessagingDataMapper;
    private final ExcessServiceConfigData excessServiceConfigData;
    private final KafkaProducer<String, PartitionRequestAvroModel> kafkaProducer;
    private final KafkaMessageHelper excessKafkaMessageHelper;

    public PartitionProcessKafkaMessagePublisher(ExcessMessagingDataMapper excessMessagingDataMapper,
                                                 ExcessServiceConfigData excessesServiceConfigData,
                                                 KafkaProducer<String, PartitionRequestAvroModel> kafkaProducer,
                                                 KafkaMessageHelper kafkaMessageHelper) {
        this.excessMessagingDataMapper = excessMessagingDataMapper;
        this.excessServiceConfigData = excessesServiceConfigData;
        this.kafkaProducer = kafkaProducer;
        this.excessKafkaMessageHelper = kafkaMessageHelper;
    }

    @Override
    public void publish(PartitionProcessEvent domainEvent) {
        String partitionId = domainEvent.getPartition().getId().getValue().toString();
        log.info("Received PartitionDriveEvent for partition id: {}", partitionId);

        try {
            PartitionRequestAvroModel partitionRequestAvroModel = excessMessagingDataMapper
                    .partitionDriveEventToPartitionRequestAvroModel(domainEvent);

            kafkaProducer.send(excessServiceConfigData.getExcessDailySnapshotTopicName(),
                    partitionId,
                    partitionRequestAvroModel,
                    excessKafkaMessageHelper
                            .getKafkaCallback(excessServiceConfigData.getExcessDailySnapshotTopicName(),
                                    partitionRequestAvroModel,
                                    partitionId,
                                    "PartitionRequestAvroModel"));

            log.info("PartitionRequestAvroModel sent to Kafka for partition id: {}", partitionRequestAvroModel.getPartitionId());
        } catch (Exception e) {
           log.error("Error while sending PartitionRequestAvroModel message" +
                   " to kafka with partition id: {}, error: {}", partitionId, e.getMessage());
        }
    }
}
