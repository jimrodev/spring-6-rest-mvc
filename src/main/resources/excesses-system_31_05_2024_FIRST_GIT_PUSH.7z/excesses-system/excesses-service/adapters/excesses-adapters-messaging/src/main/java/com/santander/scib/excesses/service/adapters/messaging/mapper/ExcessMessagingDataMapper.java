package com.santander.scib.excesses.service.adapters.messaging.mapper;

import com.santander.scib.excesses.kafka.excess.avro.model.ExcessRequestAvroModel;
import com.santander.scib.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.event.PartitionProcessEvent;
import org.springframework.stereotype.Component;

@Component
public class ExcessMessagingDataMapper {
    public ExcessRequestAvroModel excessCreatedEventToExcessRequestAvroModel(ExcessCreatedEvent domainEvent) {
        Excess excess = domainEvent.getExcess();

        return ExcessRequestAvroModel.newBuilder()
                .setExcessId(excess.getId().getValue())
                .setLimitOrigin(excess.getLimitOrigin())
                .setLimitShortName(excess.getLimitShortName())
                .setMetricType(excess.getMetricType().toString())
                .setExcessMetric(excess.getExcessMetric().toString())
                .setPeriod(excess.getPeriod())
                .setLimitCurrency(excess.getLimitCurrency())
                .setLimitAmount(excess.getLimitAmount().toString())     // *
                .setUsed(excess.getUsed().toString())                   // *
                .setExcessReason(excess.getExcessReason())
                .setLimitInternalKey(excess.getLimitInternalKey())
                .setExcessType(excess.getExcessType().toString())
                .setExcessStatus(excess.getExcessStatus().toString())
                .build();
    }

    public PartitionRequestAvroModel partitionDriveEventToPartitionRequestAvroModel(PartitionProcessEvent domainEvent) {
        Partition partition = domainEvent.getPartition();

        return PartitionRequestAvroModel.newBuilder()
                .setPartitionId(partition.getId().getValue())
                .build();
    }
}