package com.santander.scib.excesses.service.adapters.messaging.publisher.kafka;


import com.santander.scib.excesses.kafka.excess.avro.model.ExcessRequestAvroModel;
import com.santander.scib.excesses.kafka.producer.KafkaMessageHelper;
import com.santander.scib.excesses.kafka.producer.KafkaProducer;
import com.santander.scib.excesses.service.adapters.messaging.mapper.ExcessMessagingDataMapper;
import com.santander.scib.excesses.service.domain.config.ExcessServiceConfigData;
import com.santander.scib.excesses.service.domain.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.ports.output.message.publisher.ExcessCreatedMessagePublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ExcessCreatedKafkaMessagePublisher implements ExcessCreatedMessagePublisher {

    private final ExcessMessagingDataMapper excessMessagingDataMapper;
    private final ExcessServiceConfigData excessServiceConfigData;
    private final KafkaProducer<String, ExcessRequestAvroModel> kafkaProducer;
    private final KafkaMessageHelper excessKafkaMessageHelper;

    public ExcessCreatedKafkaMessagePublisher(ExcessMessagingDataMapper excessMessagingDataMapper,
                                              ExcessServiceConfigData excessesServiceConfigData,
                                              KafkaProducer<String, ExcessRequestAvroModel> kafkaProducer,
                                              KafkaMessageHelper kafkaMessageHelper) {
        this.excessMessagingDataMapper = excessMessagingDataMapper;
        this.excessServiceConfigData = excessesServiceConfigData;
        this.kafkaProducer = kafkaProducer;
        this.excessKafkaMessageHelper = kafkaMessageHelper;
    }

    @Override
    public void publish(ExcessCreatedEvent domainEvent) {
        String excessId = domainEvent.getExcess().getId().getValue().toString();
        log.info("Received ExcessCreatedEvent for excess id: {}", excessId);

        try {
            ExcessRequestAvroModel excessRequestAvroModel = excessMessagingDataMapper
                    .excessCreatedEventToExcessRequestAvroModel(domainEvent);

            kafkaProducer.send(excessServiceConfigData.getExcessPublishTopicName(),
                    excessId,
                    excessRequestAvroModel,
                    excessKafkaMessageHelper
                            .getKafkaCallback(excessServiceConfigData.getExcessPublishTopicName(),
                                    excessRequestAvroModel,
                                    excessId,
                                    "ExcessRequestAvroModel"));

            log.info("ExcessRequestAvroModel sent to Kafka for excess id: {}", excessRequestAvroModel.getExcessId());
        } catch (Exception e) {
           log.error("Error while sending ExcessRequestAvroModel message" +
                   " to kafka with excess id: {}, error: {}", excessId, e.getMessage());
        }
    }
}
