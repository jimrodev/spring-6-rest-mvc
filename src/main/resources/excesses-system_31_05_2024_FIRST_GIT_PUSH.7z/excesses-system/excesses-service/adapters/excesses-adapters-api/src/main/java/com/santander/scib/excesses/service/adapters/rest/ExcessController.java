package com.santander.scib.excesses.service.adapters.rest;

import com.santander.scib.excesses.service.domain.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.dto.ExcessResponse;
import com.santander.scib.excesses.service.domain.ports.input.service.ExcessApplicationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
//@RestController
//@RequestMapping(value = "/excess", produces = "application/vnd.api.v1+json")
public class ExcessController {

    private final ExcessApplicationService excessApplicationService;

    public ExcessController(ExcessApplicationService excessApplicationService) {
        this.excessApplicationService = excessApplicationService;
    }

    //@PostMapping
    public ResponseEntity<ExcessResponse> createExcess(@RequestBody ExcessRequest excessRequest) {
        log.info("Creating excess with id: {}", excessRequest.getExcessId());
        ExcessResponse excessResponse = excessApplicationService.processExcess(excessRequest);
        log.info("Excess created with  id: {}", excessResponse.getExcessId());
        return ResponseEntity.ok(excessResponse);
    }
}
