package com.santander.scib.excesses.service.adapters.dataaccess.excess.entity;

import com.santander.scib.excesses.domain.valueobject.*;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import lombok.*;

import java.math.BigDecimal;
import java.util.Objects;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "excesses")
@Entity
public class ExcessEntity {

    @Id
    private String excessId;
    private String limitOrigin;
    private String limitShortName;
    @Enumerated(EnumType.STRING)
    private MetricType metricType;
    @Enumerated(EnumType.STRING)
    private ExcessMetric excessMetric;
    private String period;
    private String limitCurrency;
    private BigDecimal limitAmount;
    private BigDecimal used;
    private String excessReason;
    private String excessBeginDate;
    private String excessBeginTimestamp;
    private String excessEndDate;
    private String excessEndTimestamp;
    private String limitInternalKey;
    @Enumerated(EnumType.STRING)
    private ExcessType excessType;
    @Enumerated(EnumType.STRING)
    private ExcessStatus excessStatus;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExcessEntity that = (ExcessEntity) o;
        return excessId.equals(that.excessId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(excessId);
    }
}
