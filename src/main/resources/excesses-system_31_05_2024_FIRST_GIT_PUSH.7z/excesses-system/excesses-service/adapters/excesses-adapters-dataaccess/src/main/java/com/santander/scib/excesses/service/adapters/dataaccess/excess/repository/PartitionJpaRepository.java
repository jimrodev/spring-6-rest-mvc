package com.santander.scib.excesses.service.adapters.dataaccess.excess.repository;

import com.santander.scib.excesses.service.adapters.dataaccess.excess.entity.ExcessEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PartitionJpaRepository extends JpaRepository<ExcessEntity, String> {
}
