package com.santander.scib.excesses.service.adapters.dataaccess.excess;

import com.santander.scib.excesses.service.adapters.dataaccess.excess.mapper.ExcessDataAccessMapper;
import com.santander.scib.excesses.service.adapters.dataaccess.excess.repository.ExcessJpaRepository;
import com.santander.scib.excesses.service.domain.entity.Excess;
import com.santander.scib.excesses.service.domain.ports.output.repository.ExcessRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class ExcessRepositoryImpl implements ExcessRepository {

    private final ExcessJpaRepository excessJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;

    public ExcessRepositoryImpl(ExcessJpaRepository customerJpaRepository,
                                ExcessDataAccessMapper customerDataAccessMapper) {
        this.excessJpaRepository = customerJpaRepository;
        this.excessDataAccessMapper = customerDataAccessMapper;
    }

    @Override
    public Excess save(Excess excess) {
        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessDataAccessMapper.excessToExcessEntity(excess)));
    }

    @Override
    public Excess update(Excess excess) {
        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessDataAccessMapper.excessToExcessEntity(excess)));
    }
}
