package com.santander.scib.excesses.service.adapters.dataaccess.excess.entity;

import com.santander.scib.excesses.domain.valueobject.PartitionStatus;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "partitions")
@Entity
public class PartitionEntity {
    @Id
    private String partitionId;
    @Enumerated(EnumType.STRING)
    private PartitionStatus partitionStatus;
}
