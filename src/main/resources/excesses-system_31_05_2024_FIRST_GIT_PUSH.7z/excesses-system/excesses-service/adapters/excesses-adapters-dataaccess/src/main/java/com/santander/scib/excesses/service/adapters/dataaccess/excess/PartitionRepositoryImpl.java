package com.santander.scib.excesses.service.adapters.dataaccess.excess;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.adapters.dataaccess.excess.mapper.ExcessDataAccessMapper;
import com.santander.scib.excesses.service.adapters.dataaccess.excess.repository.PartitionJpaRepository;
import com.santander.scib.excesses.service.domain.entity.Partition;
import com.santander.scib.excesses.service.domain.ports.output.repository.PartitionRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class PartitionRepositoryImpl implements PartitionRepository {

    private final PartitionJpaRepository partitionJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;

    public PartitionRepositoryImpl(PartitionJpaRepository partitionJpaRepository,
                                   ExcessDataAccessMapper excessDataAccessMapper) {
        this.partitionJpaRepository = partitionJpaRepository;
        this.excessDataAccessMapper = excessDataAccessMapper;
    }

    @Override
    public Partition save(Partition partition) {
        return null;
    }

    @Override
    public Optional<Partition> findByPartitionId(PartitionId partitionId) {
        return Optional.empty();
    }
}
