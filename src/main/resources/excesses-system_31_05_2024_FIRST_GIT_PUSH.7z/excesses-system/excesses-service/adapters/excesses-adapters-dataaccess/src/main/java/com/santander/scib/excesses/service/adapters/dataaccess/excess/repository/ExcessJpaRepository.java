package com.santander.scib.excesses.service.adapters.dataaccess.excess.repository;

import com.santander.scib.excesses.service.adapters.dataaccess.excess.entity.ExcessEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
@Repository
public interface ExcessJpaRepository  extends JpaRepository<ExcessEntity, String> {
}
