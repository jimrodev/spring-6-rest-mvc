package com.santander.scib.creame.blackhole.service.adapters.messaging.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.blackhole.service.domain.application.ports.input.message.listener.FilterResponseMessageListener;
import com.santander.scib.creame.blackhole.service.domain.application.ports.input.message.listener.WorkflowResponseMessageListener;
import org.mockito.Mockito;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class KafkaTestConfig {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    @Primary
    public FilterResponseMessageListener filterResponseMessageListener() {
        return Mockito.mock(FilterResponseMessageListener.class);
    }

    @Bean
    @Primary
    public WorkflowResponseMessageListener workflowResponseMessageListener() {
        return Mockito.mock(WorkflowResponseMessageListener.class);
    }
}
