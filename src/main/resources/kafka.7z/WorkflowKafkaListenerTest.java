package com.santander.scib.creame.blackhole.service.adapters.messaging.kafka;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.hortonworks.registries.schemaregistry.SchemaVersionKey;
import com.hortonworks.registries.schemaregistry.client.SchemaRegistryClient;
import com.hortonworks.registries.schemaregistry.exceptions.RegistryRetryableException;
import com.hortonworks.registries.shaded.javax.ws.rs.NotFoundException;
import com.santander.scib.creame.avro.models.FilterRequestAvroModel;
import com.santander.scib.creame.avro.models.WorkflowRequestAvroModel;
import com.santander.scib.creame.blackhole.service.adapters.messaging.listener.kafka.WorkflowResponseKafkaListener;
import com.santander.scib.creame.blackhole.service.adapters.messaging.mapper.WorkflowMessagingDataMapper;
import com.santander.scib.creame.blackhole.service.adapters.messaging.publisher.kafka.WorkflowKafkaMessagePublisher;
import com.santander.scib.creame.blackhole.service.domain.application.ports.input.message.listener.WorkflowResponseMessageListener;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducerHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.config.KafkaConsumerConfig;
import com.santander.scib.creame.excesses.infrastructure.kafka.config.KafkaProducerConfig;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.Encoder;
import org.apache.avro.io.EncoderFactory;
import org.apache.avro.specific.SpecificDatumWriter;
import org.apache.avro.specific.SpecificRecordBase;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.junit.jupiter.api.*;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.SocketException;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static java.util.concurrent.TimeUnit.SECONDS;
import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(classes = {KafkaConsumerConfig.class,
                                                KafkaProducerConfig.class,
                                                WorkflowMessagingDataMapper.class,
                                                WorkflowKafkaMessagePublisher.class,
                                                KafkaProducerHelper.class,
                                                KafkaTestConfig.class,
                                               WorkflowResponseKafkaListener.class})
@TestPropertySource(locations = "classpath:application.yml")
@EmbeddedKafka(partitions = 1, brokerProperties = { "listeners=PLAINTEXT://localhost:9093", "port=9093" })
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@EnableConfigurationProperties({KafkaConsumerConfig.class, KafkaProducerConfig.class})
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class WorkflowKafkaListenerTest {

    private static final String BLACK_HOLE_ID_RC = "0ED0G|DNBEG|SAN|TOT|TOT|2024121100103308";
    private static final String BLACK_HOLE_ID_RC_FILTERED = "ABEGG|0SQW5|SAN|TOT|TOT|2025021400102875";

    private static String PROCESS_DATE = "20250203";
    private static final String PROCESS_TIMESTAMP = "2025020300102293";

//    @Autowired
//    private EmbeddedKafkaBroker embeddedKafka;

    @Autowired
    private ObjectMapper objectMapper;

    @Value( "#{@kafkaTopics['workflow-request']}")
    private String testTopic;

    @Value( "#{@kafkaTemplates['workflow']}")
    private KafkaTemplate<String, WorkflowRequestAvroModel> workflowKafkaTemplate;

    private static final int SCHEMA_REGISTRY_PORT = 38082;
    private static WireMockServer wireMockServer;

    private BlockingQueue<ConsumerRecord<String, GenericRecord>> records;
    private BlockingQueue<ILoggingEvent> logQueue;

    @Autowired
    private WorkflowResponseKafkaListener workflowResponseKafkaListener;

    @Autowired
    private WorkflowResponseMessageListener workflowResponseMessageListener;

    @Autowired
    private WorkflowKafkaMessagePublisher workflowKafkaMessagePublisher;

    @BeforeAll
    static void startWireMockServer() {
        wireMockServer = new WireMockServer(SCHEMA_REGISTRY_PORT);
        wireMockServer.start();
        setupStubs();
    }

    @AfterAll
    static void stopWireMockServer() {
        wireMockServer.stop();
    }

    private static void setupStubs() {

        // Stub for schema registration
        wireMockServer.stubFor(post(urlPathMatching("/schemaregistry/schemas/"))
                .willReturn(aResponse().withStatus(201).withBody("1")));

        // Stub for schema version registration
        wireMockServer.stubFor(post(urlPathMatching("/schemaregistry/schemas/workflow-request-value/versions"))
                .willReturn(aResponse().withStatus(201).withBody("1")));

        // Stub for retrieving schema metadata
        wireMockServer.stubFor(get(urlPathMatching("/schemaregistry/schemas/workflow-request-value"))
                .willReturn(aResponse().withStatus(200).withBody(getSchemaMetadataResponse(1, "workflow-request-value"))));

        // Stub for retrieving specific schema version
        wireMockServer.stubFor(get(urlPathMatching("/schemaregistry/schemas/workflow-request-value/versions/1"))
                .willReturn(aResponse().withStatus(200).withBody(getSchemaVersion(1, "workflow-request-value"))));

        // Stub for retrieving schema by ID
        wireMockServer.stubFor(get(urlPathMatching("/schemaregistry/schemas/versionsById/1"))
                .willReturn(aResponse().withStatus(200).withBody(getSchemaVersion(1, "workflow-request-value"))));

        // Stub for retrieving schema by ID for WorkflowRequestAvroModel
        wireMockServer.stubFor(get(urlEqualTo("/schemas/ids/workflow-request/1"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/vnd.schemaregistry.v1+json")
                        .withBody("{\"schema\": \"{\\\"type\\\":\\\"record\\\",\\\"name\\\":\\\"WorkflowRequestAvroModel\\\",\\\"fields\\\":[{\\\"name\\\":\\\"excessId\\\",\\\"type\\\":\\\"string\\\"},{\\\"name\\\":\\\"automaticClassification\\\",\\\"type\\\":\\\"string\\\"}]}\"}")));
    }

    public static String getSchemaMetadataResponse(int id, String name) {
        //language=JSON
        return "{\"schemaMetadata\":" +
                "{\"type\":\"avro\",\"schemaGroup\":\"cib-cream-online\",\"name\":\""+name+"\"," +
                "\"description\":\"description\",\"compatibility\":\"NONE\",\"validationLevel\":\"LATEST\"," +
                "\"evolve\":true},\"id\":"+id+",\"timestamp\":1593683350951}";
    }

    public static String getSchemaVersion(int id, String name) {

        return "{\"id\":" + id + ",\"schemaMetadataId\":1,\"name\":\"workflow-request-value\",\"description\":\"description\"," +
                                        "\"version\":1,\"schemaText\":\"{\\\"type\\\":\\\"record\\\",\\\"name\\\":\\\"WorkflowRequestAvroModel\\\"," +
                                        "\\\"fields\\\":[" +
                                        "{\\\"name\\\":\\\"excessId\\\",\\\"type\\\":\\\"string\\\"}," +
                                        "{\\\"name\\\":\\\"automaticClassification\\\",\\\"type\\\":\\\"string\\\"}" +
                                        "]}\"," +
                                        "\"timestamp\":1593683351021,\"stateId\":5,\"mergeInfo\":null}";
    }

    @BeforeEach
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    void setUp() throws InterruptedException {

        if (!wireMockServer.isRunning()) {
            wireMockServer.start();
        }

        logQueue = new LinkedBlockingQueue<>();
        Logger rootLogger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
        rootLogger.setLevel(Level.ERROR);
        AppenderBase<ILoggingEvent> appender = new AppenderBase<ILoggingEvent>() {
            @Override
            protected void append(ILoggingEvent eventObject) {
                logQueue.add(eventObject);
            }
        };
        appender.start();
        rootLogger.addAppender(appender);
        records = new LinkedBlockingQueue<>();

        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9093");
        props.put("group.id", "test-group-workflow");
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "com.hortonworks.registries.schemaregistry.serdes.avro.kafka.KafkaAvroDeserializer");
        props.put("schema.registry.url", "http://localhost:38082");

        KafkaConsumer<String, GenericRecord> kafkaConsumer = new KafkaConsumer<>(props);
        kafkaConsumer.subscribe(Collections.singletonList(testTopic));

        new Thread(() -> {
            while (true) {
                ConsumerRecords<String, GenericRecord> consumerRecords = kafkaConsumer.poll(Duration.ofMillis(100));
                for (ConsumerRecord<String, GenericRecord> record : consumerRecords) {
                    records.add(record);
                }
            }
        }).start();
    }

    @AfterEach
    void tearDown() {
        if (wireMockServer.isRunning()) wireMockServer.stop();
    }

    @Test
    @Order(1)
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    void testPublishWorkflowRequestAvroModel() throws InterruptedException, IOException {

        WorkflowRequestAvroModel workflowRequestAvroModel = WorkflowRequestAvroModel.newBuilder()
                .setExcessId(BLACK_HOLE_ID_RC)
                .setAutomaticClassification("BlackHole")
                .build();

        // Verify schema registry stubs
        assertDoesNotThrow(
                () -> verifySchemaRegistryStubs(testTopic), "verifySchemaRegistryStubs should not throw an exception");

        // Validate Avro record
        String schemaVersionJson = getSchemaVersion(1, testTopic + "-value");
        Schema schema = getAvroSchema(schemaVersionJson);

        boolean isValid = validateAvroRecord(workflowRequestAvroModel, schema);
        assertTrue(isValid, "The Avro record should be valid");

        // Send message with KafkaTemplate
        //sendMessage(workflowKafkaTemplate, workflowRequestTestTopic, "key", workflowRequestAvroModel);

        // Create a coordinator message

        String outboxId = UUID.randomUUID().toString();
        String sagaId = UUID.randomUUID().toString();

        CoordinatorMessage coordinatorMessage = CoordinatorMessage.builder()
                .outboxId(outboxId) // Generate a random UUID for outboxId
                .sagaId(sagaId) // Generate a random UUID for sagaId
                .createdAt(ZonedDateTime.now()) // Set the current date and time for createdAt
                .processedAt(ZonedDateTime.now().plusMinutes(5)) // Set the processedAt to 5 minutes after createdAt
                .eventSource("BLACKHOLE")
                .eventTarget("FILTER")
                .messageId(BLACK_HOLE_ID_RC)
                .payload("{\"blackHoleId\":\"" + BLACK_HOLE_ID_RC  + "\",\"metricType\":\"RC\",\"metric\":\"TOT\",\"beginDate\":\"20241211\",\"beginTimestamp\":\"2024121100103310\",\"endDate\":null,\"endTimestamp\":null,\"status\":\"UNFILTERED\",\"blackHoleDetail\":{\"processDate\":\"" + PROCESS_DATE + "\",\"processTimestamp\":\"" + PROCESS_TIMESTAMP + "\",\"aggLevel\":\"F\",\"metricCurrency\":\"EUR\",\"metricDate\":\"2025-02-18'\",\"timestep\":null,\"metricAmount\":504459.5899777785,\"impactNumber\":62,\"maxMetricAmount\":90869.5699959972,\"maxMetricAmountUsd\":94995.04847381547288,\"maxMetricAmountMetricDate\":\"2025-05-21\",\"maxMetricAmountTimestep\":null,\"maxMetricDate\":\"2025-05-21\",\"maxMetricTimestep\":null,\"automaticClassification\":\"BlackHole\",\"firmCode\":\"DNBEG\",\"firmName\":\"ANDRITZ INGENIERIA S.A.,SAN SEBA, GR\",\"firmSector\":\"MACHINERY\",\"firmSegment\":\"Corporate\",\"firmRating\":null,\"firmIndustry\":\"SCIB.CORPORATE\",\"firmCountryCode\":\"ES\",\"groupCode\":\"0ED0G\",\"groupName\":\"ANDRITZ\",\"groupSector\":\"MACHINERY\",\"groupSegment\":\"Corporate\",\"groupRating\":6.3,\"groupIndustry\":\"SCIB.CORPORATE\",\"groupCountryCode\":\"DE\",\"folder\":\"SAN\",\"instrument\":\"TOT\",\"severity\":\"WHITE\",\"escalationLevel\":\"Global/Local analyst\"}}")
                .context("{\"messageId\":\"" + BLACK_HOLE_ID_RC  + "\",\"messageType\":\"com.santander.scib.creame.blackhole.service.domain.application.dto.BlackHoleRequest\",\"interchangeId\":\"" + sagaId + "\",\"eventSource\":\"BLACKHOLE\",\"inboundTransportType\":\"s3://\",\"inboundTransportLocation\":\"gcb-des-pr-saccr-online/2025020300102293\",\"batchId\":\"798913c9-eefe-49d9-aab0-cc17fbc288e0\",\"batchTotalNumber\":\"4898\",\"batchSequenceNumber\":\"558\",\"operationMode\":\"ELASTIC\",\"s3BucketName\":\"gcb-des-pr-saccr-online\",\"s3keyName\":\"2025020300102293\"}")
                .outboxStatus(OutboxStatus.STARTED)
                .sagaStatus(SagaStatus.STARTED)
                .version(0)
                .isNew(false)
                .build();

        // Send message with ExcessKafkaMessagePublisher
        workflowKafkaMessagePublisher.publish(coordinatorMessage, (msg, status) -> {
            System.out.println("Message published with status: " + status);
        });

        // Use Awaitility to wait until the message is received
        await().atMost(20, SECONDS).until(() -> !records.isEmpty());

        ConsumerRecord<String, GenericRecord> receivedSuccess = records.poll(5, TimeUnit.SECONDS);
        assertNotNull(receivedSuccess, "Message was not received");

        // Assert that the received message is equal to the sent message
        assertThat(receivedSuccess.key()).isEqualTo(BLACK_HOLE_ID_RC);
        assertThat(receivedSuccess.value().get("excessId").toString()).isEqualTo(workflowRequestAvroModel.getExcessId());
        assertThat(receivedSuccess.value().get("automaticClassification").toString()).isEqualTo(workflowRequestAvroModel.getAutomaticClassification());
    }

//    @Test
//    @Order(2)
//    void testReceivedBatch() {
//        // Create a sample FilterRequestAvroModel
//        FilterRequestAvroModel filterRequestAvroModel = FilterRequestAvroModel.newBuilder()
//                .setExcessId(BLACK_HOLE_ID_RC_UNFILTERED)
//                .setProcessTimestamp(PROCESS_TIMESTAMP)
//                .build();
//
//        // Create a sample FilterRequestAvroModel
//        FilterRequestAvroModel unfilterRequestAvroModel = FilterRequestAvroModel.newBuilder()
//                .setExcessId(BLACK_HOLE_ID_RC_UNFILTERED)
//                .setProcessTimestamp(PROCESS_TIMESTAMP)
//                .build();
//
//        // Create a Message with the sample FilterRequestAvroModel
//        Message<FilterRequestAvroModel> message1 = MessageBuilder.withPayload(filterRequestAvroModel).build();
//        Message<FilterRequestAvroModel> message2 = MessageBuilder.withPayload(unfilterRequestAvroModel).build();
//
//        // Mock the apply method to do nothing
//        doNothing().when(filterResponseMessageListener).apply(any(FilterRequest.class), any(ContextMessage.class));
//
//        // Call the receivedBatch method with a list containing the sample message
//        filterResponseKafkaListener.receivedBatch(Arrays.asList(message1, message2));
//
//        // Verify that the apply method of filterRequestMessageListener was called
//        verify(filterResponseMessageListener, times(2)).apply(any(FilterRequest.class), any(ContextMessage.class));
//    }
//
//    @Test
//    @Order(3)
//    void testReceivedBatchThrowDataIntegrityViolationException() {
//        // Create a sample FilterRequestAvroModel
//        FilterRequestAvroModel filterRequestAvroModel = FilterRequestAvroModel.newBuilder()
//                .setExcessId(BLACK_HOLE_ID_RC_UNFILTERED)
//                .setProcessTimestamp(PROCESS_TIMESTAMP)
//                .build();
//
//        // Create a Message with the sample FilterRequestAvroModel
//        Message<FilterRequestAvroModel> message = MessageBuilder.withPayload(filterRequestAvroModel).build();
//
//        // Mock the apply method to throw DataIntegrityViolationException
//        doThrow(new DataIntegrityViolationException("Data integrity violation"))
//                .when(filterResponseMessageListener).apply(any(FilterRequest.class), any(ContextMessage.class));
//
//        // Call the receivedBatch method with a list containing the sample message
//        filterResponseKafkaListener.receivedBatch(Collections.singletonList(message));
//
//        // Verify that the apply method of filterRequestMessageListener was called
//        verify(filterResponseMessageListener, times(1)).apply(any(FilterRequest.class), any(ContextMessage.class));
//
//        // Verify that the log contains the expected error message
//        System.out.println("Waiting for log message...");
//        Awaitility.await().atMost(10, TimeUnit.SECONDS).until(() -> !logQueue.isEmpty());
//        ILoggingEvent logEvent = logQueue.stream()
//                .filter(event -> event.getFormattedMessage().contains("Caught data integration exception in FilterRequestKafkaListener for excess id"))
//                .findFirst()
//                .orElse(null);
//        System.out.println("Log message received: " + (logEvent != null ? logEvent.getFormattedMessage() : "No log message"));
//        org.assertj.core.api.Assertions.assertThat(logEvent).isNotNull();
//        org.assertj.core.api.Assertions.assertThat(logEvent.getFormattedMessage()).contains("Caught data integration exception in FilterRequestKafkaListener for excess id: " +
//                BLACK_HOLE_ID_RC_UNFILTERED +
//                " and message: Data integrity violation");
//    }
//
//    @Test
//    @Order(4)
//    void testReceivedBatchThrowOptimisticLockingFailureException() {
//        // Create a sample FilterRequestAvroModel
//        FilterRequestAvroModel filterRequestAvroModel = FilterRequestAvroModel.newBuilder()
//                .setExcessId(BLACK_HOLE_ID_RC_UNFILTERED)
//                .setProcessTimestamp(PROCESS_TIMESTAMP)
//                .build();
//
//        // Create a Message with the sample FilterRequestAvroModel
//        Message<FilterRequestAvroModel> message = MessageBuilder.withPayload(filterRequestAvroModel).build();
//
//        // Mock the apply method to throw OptimisticLockingFailureException
//        doThrow(new OptimisticLockingFailureException("Optimistic locking failure"))
//                .when(filterResponseMessageListener).apply(any(FilterRequest.class), any(ContextMessage.class));
//
//        // Call the receivedBatch method with a list containing the sample message
//        filterResponseKafkaListener.receivedBatch(Collections.singletonList(message));
//
//        // Verify that the apply method of filterRequestMessageListener was called
//        verify(filterResponseMessageListener, times(1)).apply(any(FilterRequest.class), any(ContextMessage.class));
//
//        // Verify that the log contains the expected error message
//        System.out.println("Waiting for log message...");
//        Awaitility.await().atMost(10, TimeUnit.SECONDS).until(() -> !logQueue.isEmpty());
//        ILoggingEvent logEvent = logQueue.stream()
//                .filter(event -> event.getFormattedMessage().contains("Caught optimistic locking exception in FilterRequestKafkaListener for excess id"))
//                .findFirst()
//                .orElse(null);
//        System.out.println("Log message received: " + (logEvent != null ? logEvent.getFormattedMessage() : "No log message"));
//        org.assertj.core.api.Assertions.assertThat(logEvent).isNotNull();
//        org.assertj.core.api.Assertions.assertThat(logEvent.getFormattedMessage()).contains("Caught optimistic locking exception in FilterRequestKafkaListener for excess id: " +
//                BLACK_HOLE_ID_RC_UNFILTERED +
//                " and message: Optimistic locking failure");
//    }



    private void verifySchemaRegistryStubs(String schema) {

        Map<String, Object> config = new HashMap<>();
        config.put(SchemaRegistryClient.Configuration.SCHEMA_REGISTRY_URL.name(), "http://localhost:38081");

        SchemaRegistryClient schemaRegistryClient = new SchemaRegistryClient(config);
        try {
            // Attempt to retrieve a schema by name and version
            String schemaName = schema + "-value";
            int version = 1;
            SchemaVersionKey schemaVersionKey = new SchemaVersionKey(schemaName, version);
            schemaRegistryClient.getSchemaVersionInfo(schemaVersionKey);
            System.out.println("Schema retrieved successfully.");
        } catch (NotFoundException e) {
            System.err.println("Schema not found: " + e.getMessage());
            // Handle the 404 error, e.g., by logging or providing a fallback
        } catch (RegistryRetryableException e) {
            System.err.println("Retryable exception: " + e.getMessage());
            // Implement retry logic if needed
        } catch (Exception e) {
            System.err.println("An error occurred: " + e.getMessage());
            // Handle other exceptions
        }
    }

    @Retryable(
            value = { SocketException.class },
            maxAttempts = 5,
            backoff = @Backoff(delay = 2000)
    )
    public <T>void sendMessage(KafkaTemplate<String, T> kafkaTemplate, String topic, String key, T message) {

        try {
            String url = "http://localhost:38081/schemaregistry/schemas/" + topic + "-value/versions";
            System.out.println("Attempting to send message to URL: " + url);
            kafkaTemplate.send(topic, key, message);
            System.out.println("Message sent successfully.");
        } catch (Exception e) {
            System.err.println("An error occurred while sending the message: " + e.getMessage());
            throw e;
        }
    }

    public byte[] convertGenericRecordToByteArray(GenericRecord record) throws IOException {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        BinaryEncoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
        GenericDatumWriter<GenericRecord> datumWriter = new GenericDatumWriter<>(record.getSchema());
        datumWriter.write(record, encoder);
        encoder.flush();
        outputStream.close();
        return outputStream.toByteArray();
    }

    public static Schema getAvroSchema(String schemaJson) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(schemaJson);
        String schemaText = rootNode.get("schemaText").asText();
        return new Schema.Parser().parse(schemaText);
    }

    public static boolean validateAvroRecord(SpecificRecordBase record, Schema schema) {
        try {
            DatumWriter<SpecificRecordBase> writer = new SpecificDatumWriter<>(schema);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Encoder encoder = EncoderFactory.get().binaryEncoder(outputStream, null);
            writer.write(record, encoder);
            encoder.flush();
            outputStream.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}