package com.santander.scib.creame.excesses.infrastructure.s3.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.net.URI;
import java.util.Map;

/**
 * Configuration class for setting up S3 clients.
 * This class is conditionally loaded based on the application's configuration.
 */
@Configuration
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app.infrastructure.s3', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0 and '${app.infrastructure.s3.enabled:true}' == 'true'"
)
@ConfigurationProperties(prefix = "app.infrastructure.s3")
@Getter
@Setter
public class S3ClientConfig {

    private Map<String, Map<String, S3BucketsInfo>> buckets;

    private Map<String, S3ConfigData> profiles;

    /**
     * Returns a map of S3 bucket information based on the application's configuration.
     *
     * @return a map of profile names to a map of bucket names to S3BucketsInfo objects
     */
    @Bean
    public Map<String, Map<String, S3BucketsInfo>> s3Buckets() {
        return buckets;
    }

    /**
     * Creates a map of S3Client objects based on the application's S3 profiles.
     *
     * @return a map of profile names to S3Client objects
     */
    @Bean
    public Map<String, S3Client> s3Clients() {
        return profiles.entrySet().stream().collect(
            java.util.stream.Collectors.toMap(
                Map.Entry::getKey,
                entry -> S3Client.builder()
                    .credentialsProvider(() -> {
                        S3ConfigData config = entry.getValue();
                        return AwsBasicCredentials.create(
                            config.getCredentials().getAccessKeyId(), config.getCredentials().getSecretAccessKey()
                        );
                    })
                    .endpointOverride(URI.create(entry.getValue().getServiceEndpoint()))
                    .region(Region.of(entry.getValue().getRegion()))
                    .forcePathStyle(true)
                    .build()
            )
        );
    }

}
