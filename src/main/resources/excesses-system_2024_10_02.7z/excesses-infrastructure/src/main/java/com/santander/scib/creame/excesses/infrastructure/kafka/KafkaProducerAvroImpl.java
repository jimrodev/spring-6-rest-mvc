package com.santander.scib.creame.excesses.infrastructure.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.BiConsumer;

/**
 * Implementation of the KafkaProducer interface for Avro messages.
 * This class is conditionally loaded based on the application's configuration.
 * It uses a KafkaTemplate to send Avro messages to a Kafka topic.
 *
 * @param <K> the type of the key, which must be Serializable
 * @param <V> the type of the value, which must be a subclass of SpecificRecordBase (an Avro generated class)
 */
@Slf4j
@Component
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app.infrastructure.kafka', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0 and '${app.infrastructure.kafka.enabled:true}' == 'true'"
)
public class KafkaProducerAvroImpl<K extends Serializable, V extends GenericRecord> implements KafkaProducer<K, V> {

    private final KafkaTemplate<K, V> kafkaTemplate;

    /**
     * Constructs a KafkaProducerAvroImpl with the given KafkaTemplate.
     *
     * @param kafkaTemplate the KafkaTemplate to use
     */
    public KafkaProducerAvroImpl(
        //@Value("#{@kafkaTemplates['avro']}") KafkaTemplate<K, V> kafkaTemplate) {
        KafkaTemplate<K, V> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    /**
     * Sends a message to a Kafka topic.
     *
     * @param message the message to send
     */
    @Override
    public void send(Message<V> message) {
        CompletableFuture<SendResult<K, V>> futureSend = kafkaTemplate.send(message);
        futureSend.whenComplete((result, throwable) -> {
            if (throwable == null) {
                handleSuccess(message, result);
            } else {
                handleFailure(message, throwable);
            }
        });
    }

    /**
     * Sends a message to Kafka.
     *
     * @param message the message to be sent to Kafka
     * @param callback the callback function called to handle shipping result
     */
    @Override
    public void send(Message<V> message, BiConsumer<SendResult<K, V>, Throwable> callback){
        CompletableFuture<SendResult<K, V>> kafkaResultFuture = kafkaTemplate.send(message);
        kafkaResultFuture.whenComplete(callback);

//        try{
//            CompletableFuture<SendResult<K, V>> kafkaResultFuture = kafkaTemplate.send(message);
//            SendResult<K, V> sendResult = kafkaResultFuture.get();
//            callback.accept(sendResult, null);
//        }catch (InterruptedException | ExecutionException e){
//            callback.accept(null, e);
//        }
    }

    /**
     * Handles the success case of sending a message.
     *
     * @param message the message that was sent
     * @param result the result of the send operation
     */
    private void handleSuccess(Message<V> message, SendResult<K,V> result) {
        RecordMetadata metadata = result.getRecordMetadata();
        log.debug(
            "Successful send message with key: {} Topic: {} Partition: {} Offset: {} Timestamp: {}",
            message.getHeaders().get(KafkaHeaders.KEY),
            metadata.topic(),
            metadata.partition(),
            metadata.offset(),
            metadata.timestamp()
        );
    }

    /**
     * Handles the failure case of sending a message.
     *
     * @param message the message that was attempted to be sent
     * @param ex the exception that occurred
     */
    private void handleFailure(Message<V> message, Throwable ex ) {
        log.error(
            "Error while sending message with key: {} to topic: {} with schema: {} error: {}",
            message.getHeaders().get(KafkaHeaders.KEY),
            message.getHeaders().get(KafkaHeaders.TOPIC),
            message.getPayload().getSchema().getName(),
            ex.getMessage()
        );
    }
}
