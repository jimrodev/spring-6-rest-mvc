package com.santander.scib.creame.excesses.infrastructure.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.OutboxBehavior;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.domain.exception.DomainException;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;

@Slf4j
@Component
public class KafkaProducerHelper {

    private final ObjectMapper objectMapper;

    public KafkaProducerHelper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public <T, U extends OutboxBehavior> BiConsumer<SendResult<String, T>, Throwable>
    getKafkaCallback(U outboxMessage,
                     Message<T> message,
                     BiConsumer<U, OutboxStatus> outboxCallback) {

        return (result, ex) -> {
            if (ex == null) {
                RecordMetadata metadata = result.getRecordMetadata();
                log.debug(
                        "Successful send message with key: {} Topic: {} Partition: {} Offset: {} Timestamp: {}",
                        message.getHeaders().get(KafkaHeaders.KEY),
                        metadata.topic(),
                        metadata.partition(),
                        metadata.offset(),
                        metadata.timestamp()
                );

                outboxCallback.accept(outboxMessage, OutboxStatus.COMPLETED);

            } else {
                log.error(
                        "Error while sending message with key: {} to topic: {} with schema: {} error: {}",
                        message.getHeaders().get(KafkaHeaders.KEY),
                        message.getHeaders().get(KafkaHeaders.TOPIC),
                        message.getPayload().getClass().getName(),
                        ex.getMessage()
                );

                outboxCallback.accept(outboxMessage, OutboxStatus.FAILED);
            }
        };
    }

    public <T> T deserializePayload(String payload, Class<T> outputType) {
        try {
            return objectMapper.readValue(payload, outputType);
        } catch (JsonProcessingException e) {
            log.error("Could not deserialize {} object!", outputType.getName(), e);
            throw new DomainException("Could not deserialize " + outputType.getName() + " object!", e);
        }
    }
}
