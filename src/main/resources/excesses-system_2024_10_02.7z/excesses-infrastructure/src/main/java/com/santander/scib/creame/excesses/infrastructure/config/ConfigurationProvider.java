package com.santander.scib.creame.excesses.infrastructure.config;

import lombok.Getter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * The Configuration provider, provides de all configurations of the application.
 */
@Configuration
@ConfigurationProperties(prefix = "app")
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0"
)
@Getter
public class ConfigurationProvider {

    private final Properties infrastructure = new Properties();

    /**
     * Parameters properties.
     *
     * @return the properties
     */
    @Bean
    public Properties parameters() {
        return (Properties)this.infrastructure.clone();
    }

}
