package com.santander.scib.creame.excesses.infrastructure.kafka.config;

import lombok.Data;

import java.util.Properties;

/**
 * Configuration data for Kafka producers.
 */
@Data
public class KafkaProducerConfigData {

    @SuppressWarnings("java:S1068")
    private Properties configurations;

}
