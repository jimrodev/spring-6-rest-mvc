# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0-SNAPSHOT] - 2024-06-28.
### Added
- Implement config provider for application configuration.
- Implement kafka consumer and producer components.
- Implement jdbc database connection and query components.
- Implement s3 service components.
- Implement cors utility for local development.
- Implement test cases for all components.
