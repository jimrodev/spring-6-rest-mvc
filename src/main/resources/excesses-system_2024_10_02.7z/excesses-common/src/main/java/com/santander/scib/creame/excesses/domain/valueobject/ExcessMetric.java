package com.santander.scib.creame.excesses.domain.valueobject;

public enum ExcessMetric {
    TOT(0), TOT_SETT(1), CER(2), HEDGE_FUNDS(3), NOMINAL_REPO(4), NOMINAL_STOCK_LENDING(5);

    private final Integer excessMetric;
    ExcessMetric(Integer excessMetric){
        this.excessMetric = excessMetric;
    }
    public Integer getExcessMetric(){
        return excessMetric;
    }
}
