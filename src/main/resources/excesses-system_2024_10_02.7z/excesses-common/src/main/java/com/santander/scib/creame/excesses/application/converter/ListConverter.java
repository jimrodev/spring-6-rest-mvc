package com.santander.scib.creame.excesses.application.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Helper class to handle JSON objects.
 * This class provides methods for serialize and deserialize JSON Objects when dealing with relational database.
 */
@Slf4j
public class ListConverter implements AttributeConverter<List<String>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Convert a JSON object to String.
     *
     * @param metadata JSON object's List representation
     * @return a String with the JSON object's serialization
     */
    @Override
    public String convertToDatabaseColumn(List<String> metadata) {

        String metadataJson = null;
        try {
            metadataJson = objectMapper.writeValueAsString(metadata);
        } catch (final JsonProcessingException e) {
            log.error("JSON writing error", e);
        }

        return metadataJson;
    }

    /**
     * Convert a String to JSON object.
     *
     * @param metadata JSON object's String representation
     * @return a List with the JSON object's deserialization
     */
    @Override
    public List<String> convertToEntityAttribute(String metadata) {

        List<String> metadataList =  null;
        try {
            metadataList = objectMapper.readValue(metadata, new TypeReference<List<String>>() {});
        } catch (final IOException e) {
            log.error("JSON reading error", e);
        }

        return metadataList;
    }
}
