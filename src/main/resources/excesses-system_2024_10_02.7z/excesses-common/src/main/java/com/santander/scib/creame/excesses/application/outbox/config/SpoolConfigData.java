package com.santander.scib.creame.excesses.application.outbox.config;

import lombok.Data;

@Data
public class SpoolConfigData {
    private Integer maxBatchSize;
    private Integer threadPoolSize;
    private SpoolQueue spoolQueue;
    private TransportOptions transportOptions;
    private Throttling throttling;

    @Data
    public static class SpoolQueue{

        private Integer queueDepth;
        private Integer entryDuration;
        private Boolean entryClean;
    }

    @Data
    public static class TransportOptions{
        private Boolean enableFaultTolerance;
        private Integer retryCount;
        private Integer retryInterval;
        private Integer priority;
    }

    @Data
    public static class Throttling{
        private Boolean enable;
        private Integer minimunThreshold;
        private Integer maximunThreshold;
        private Integer rateThrottleFactor;
        private Boolean autoStartFailedMessages;
    }
}
