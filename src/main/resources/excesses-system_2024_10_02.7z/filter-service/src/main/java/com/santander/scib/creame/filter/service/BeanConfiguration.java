package com.santander.scib.creame.filter.service;

import com.santander.scib.creame.filter.service.domain.core.FilterDomainService;
import com.santander.scib.creame.filter.service.domain.core.FilterDomainServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public FilterDomainService filterDomainService() {
        return new FilterDomainServiceImpl();
    }
 }
