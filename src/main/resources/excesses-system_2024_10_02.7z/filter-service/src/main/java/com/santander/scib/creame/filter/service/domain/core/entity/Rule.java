package com.santander.scib.creame.filter.service.domain.core.entity;

import java.util.List;

public class Rule {
    private List<String> rules;

    public List<String> getRules() {

        return rules;
    }

    public void setRules(List<String> rules) {
        this.rules = rules;
    }

    private Rule(Builder builder) {
        rules = builder.rules;
    }

    public static Builder builder() {
        return new Builder();
    }
    public static final class Builder {
        private List<String> rules;

        private Builder() {
        }

        public Builder rules(List<String> val) {
            rules = val;
            return this;
        }

        public Rule build() {
            return new Rule(this);
        }
    }
}
