package com.santander.scib.creame.workflow.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.workflow.service.domain.application.mapper.WorkflowDataMapper;
import com.santander.scib.creame.workflow.service.domain.application.outbox.ExcessOutboxHelper;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import com.santander.scib.creame.workflow.service.domain.core.event.WorkflowEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class WorkflowAssignHandler {

    private final WorkflowAssignHelper workflowAssignHelper;
    private final ExcessOutboxHelper excessOutboxHelper;
    private final WorkflowDataMapper workflowDataMapper;
    public WorkflowAssignHandler(WorkflowAssignHelper workflowAssignHelper,
                                 ExcessOutboxHelper excessOutboxHelper,
                                 WorkflowDataMapper workflowDataMapper) {
        this.workflowAssignHelper = workflowAssignHelper;
        this.excessOutboxHelper = excessOutboxHelper;
        this.workflowDataMapper = workflowDataMapper;
    }

    @Transactional
    public WorkflowResponse assign(WorkflowRequest workflowRequest, ContextMessage contextRequest){

        // BEGIN - OUTBOX ATOMIC SCOPE {}

        // Contingency Actions(1)
        // If found an entry with same excess Id
        // Do not process - Duplicate request
        Optional<Workflow> workflowFound = workflowAssignHelper.findById(
                new ExcessId(workflowRequest.getExcessId()));

        if(workflowFound.isPresent()){
            log.info("A workflow request message with excess id: {} is already processed!", workflowRequest.getExcessId());

            // Review for api call
            return null;
        }

        WorkflowEvent workflowEvent = workflowAssignHelper.assign(workflowRequest);
        log.info("Excess is {} with id: {}", workflowEvent.getEntity().getWorkflowStatus(),
                                             workflowEvent.getEntity().getId().getValue());

        // OUTBOX IMPLEMENTATION (SAGA CORRELATION - CONTINUATION)
        UUID outboxId = UUID.randomUUID();                  // Outbox Id
        UUID sagaId = contextRequest.getInterchangeId();    // Interchange Id for the saga flow

        // Load context properties - Send by headers (Event Bus)
        contextRequest.setMessageId(workflowEvent.getId());
        contextRequest.setMessageType(WorkflowResponse.class.getTypeName());
        contextRequest.setEventSource(Stakeholders.WORKFLOW);

        // SAVE Outbox Message (Event Message, Message Context)
        excessOutboxHelper.saveCoordinatorMessage(sagaId,
                                                  SagaStatus.CONTINUATION,
                                                  outboxId,
                                                  OutboxStatus.STARTED,
                                                  workflowEvent,
                                                  workflowDataMapper::workflowToWorkflowResponse,
                                                  contextRequest);

        // END - OUTBOX ATOMIC SCOPE {}
        return workflowDataMapper.workflowToWorkflowResponse(workflowEvent.getEntity());
    }
}
