package com.santander.scib.creame.workflow.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.AggregateRoot;
import com.santander.scib.creame.excesses.domain.valueobject.*;

public class Workflow extends AggregateRoot<ExcessId> {

    private final String processTimestamp;
    private WorkflowStatus workflowStatus;
    private WorkflowGroup assignedGroup;

    public void initialize(){
        workflowStatus = WorkflowStatus.PENDING;
    }
    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void assignGroup(WorkflowGroup assignedGroup){
        this.assignedGroup = assignedGroup;

        // HERE ALL FUNCTIONALITY OF ASSIGN GROUP
        this.workflowStatus = WorkflowStatus.ASSIGNED;
    }

    public void setWorkflowStatus(WorkflowStatus workflowStatus) {this.workflowStatus = workflowStatus;}

    public void setAssignedGroup(WorkflowGroup assignedGroup) {this.assignedGroup = assignedGroup;}

    public String getProcessTimestamp() {return processTimestamp;}

    public WorkflowStatus getWorkflowStatus() {return workflowStatus;}

    public WorkflowGroup getAssignedGroup() {return assignedGroup;}

    private Workflow(Builder builder) {
        super.setId(builder.excessId);
        processTimestamp = builder.processTimestamp;
        workflowStatus = builder.workflowStatus;
        assignedGroup = builder.assignedGroup;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private ExcessId excessId;
        private String processTimestamp;
        private WorkflowStatus workflowStatus;
        private WorkflowGroup assignedGroup;

        private Builder() {
        }
        public Builder excessId(ExcessId val) {
            excessId = val;
            return this;
        }

        public Builder processTimestamp(String val) {
            processTimestamp = val;
            return this;
        }

        public Builder workflowStatus(WorkflowStatus val) {
            workflowStatus = val;
            return this;
        }

        public Builder assignedGroup(WorkflowGroup val) {
            assignedGroup = val;
            return this;
        }

        public Workflow build() {
            return new Workflow(this);
        }
    }
}
