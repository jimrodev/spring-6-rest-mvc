package com.santander.scib.creame.workflow.service.adapters.dataaccess.exception;

public class WorkflowDataaccessException extends RuntimeException {

    public WorkflowDataaccessException(String message) {
        super(message);
    }
}
