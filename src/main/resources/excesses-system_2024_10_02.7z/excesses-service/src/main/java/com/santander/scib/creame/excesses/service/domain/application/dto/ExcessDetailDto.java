package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.creame.excesses.application.converter.HashMapConverter;
import jakarta.persistence.Convert;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessDetailDto {
    @NotEmpty(message = "{not.empty}")
    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    @JsonProperty
    private String processDate;
    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String processTimestamp;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String limitOrigin;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String limitShortName;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String period;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String limitCurrency;
    @NotNull(message = "{not.null}")
    @JsonProperty
    private BigDecimal limitAmount;
    @NotNull(message = "{not.null}")
    @JsonProperty
    private BigDecimal used;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String excessReason;
    @Convert(converter = HashMapConverter.class)
    @JsonProperty
    private Map<String, Object> metadata;
}
