package com.santander.scib.creame.excesses.service.domain.core;


import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionProcessedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionReprocessedEvent;

public interface PartitionDomainService {

    PartitionProcessedEvent process(Partition partition);
    PartitionReprocessedEvent reprocess(Partition partition);

}
