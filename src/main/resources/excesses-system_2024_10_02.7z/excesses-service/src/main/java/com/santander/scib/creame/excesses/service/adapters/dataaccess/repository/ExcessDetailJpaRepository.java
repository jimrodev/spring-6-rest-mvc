package com.santander.scib.creame.excesses.service.adapters.dataaccess.repository;

import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntityId;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ExcessDetailJpaRepository extends JpaRepository<ExcessDetailEntity, ExcessDetailEntityId> {

    //Optional<List<ExcessDetailEntity>> findByExcessId(String excessId);
    Optional<ExcessDetailEntity> findByExcessIdAndProcessTimestamp(String excessId, String processTimestamp);
}
