package com.santander.scib.creame.excesses.service.adapters.messaging.receive.s3;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;

import com.santander.scib.creame.avro.models.ExcessRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import com.santander.scib.creame.excesses.infrastructure.s3.S3Service;
import com.santander.scib.creame.excesses.infrastructure.s3.config.S3BucketsInfo;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessDetailDto;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.receive.ExcessesSnapshotReceive;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.generic.GenericRecord;
import org.apache.parquet.avro.AvroParquetReader;
import org.apache.parquet.conf.ParquetConfiguration;
import org.apache.parquet.conf.PlainParquetConfiguration;
import org.apache.parquet.hadoop.ParquetReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Import;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import software.amazon.awssdk.services.s3.S3Client;

import java.io.*;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Slf4j
@Service
@Import(ExcessRequestAvroModel.class)
public class ExcessS3Service implements ExcessesSnapshotReceive {
    private final S3Service s3Service;
    private final S3Client s3Client;
    private final Map<String, S3BucketsInfo> bucketsInfo;
    private final LocalValidatorFactoryBean validatorFactoryBean;

    public ExcessS3Service(
            S3Service s3Service,
            @Value("#{@s3Clients['localstack']}") S3Client s3Client,
            @Value("#{@s3Buckets['online']}") Map<String, S3BucketsInfo> bucketsInfo,
            LocalValidatorFactoryBean validatorFactoryBean) {
        this.s3Service = s3Service;
        this.s3Client = s3Client;
        this.bucketsInfo = bucketsInfo;
        this.validatorFactoryBean = validatorFactoryBean;
    }

    @Override
    public Set<ExcessRequest> processFile(String partition, ContextMessage context) {
        Set<ExcessRequest> excesses = Collections.emptySet();

        // Implementamos reintentos como el adaptador file?
        boolean processFile = false;
        Integer retry = 0;

        try{
            log.info("Processing the file {} ", partition);
            excesses = parseParquet(
                    partition,
                    s3Service.downloadFile(
                            s3Client,
                            bucketsInfo.get("online-bucket").getName(),
                            //bucketsInfo.get("online-bucket").getLocations().get("root-folder").concat(partition)
                            partition
                    )
            );

            if(!validateSet(excesses, partition)){
                // Que hacemos si no pasa las validaciones?
                // ALERTA
            }

            // QUE HACEMOS SI EL FICHERO ESTÁ MAL
            // SI CAPTURAMOS LA EXCEPCIÓN AQUÍ LE DEVOLVEMOS LA EJECICIÓN CON UN SET NULO Y DA POR BUENA LA PARTICIÓN ACTUAL
            // QUE HACER SI EL FICHERO ESTÁ VACÍO
            // ALERTA
        }catch (Exception e)
        {

            log.error("Error while processing the file {}, error message: {} ", partition, e.getMessage());
        }
        // Context properties
        context.setMessageType(ExcessRequest.class.getTypeName());
        context.setInboundTransportType("s3://");
        context.setInboundTransportLocation(bucketsInfo.get("online-bucket").getName() + "/" + partition);
        context.setS3BucketName(bucketsInfo.get("online-bucket").getName());
        context.setS3keyName(partition);
        // Set Batch properties
        context.setBatchId(UUID.randomUUID().toString());
        if(excesses.isEmpty())
            context.setBatchTotalNumber(String.valueOf(0));
        else
            context.setBatchTotalNumber(String.valueOf(excesses.size()));

        return excesses;
    }

    private Set<ExcessRequest> parseParquet(String partition, InputStream data){
        Set<ExcessRequest> excesses = new HashSet<>();
        ParquetConfiguration configuration = new PlainParquetConfiguration();
        // Opción 1 - Pasar por el Avro Model primero y convertirlo al Dto
        // Probar cuando el proyecto no sea multi modulo
//      configuration.setBoolean(AvroReadSupport.AVRO_COMPATIBILITY, true);
//      configuration.setBoolean("parquet.avro.add-list-element-records", false);
//      configuration.setBoolean("parquet.avro.write-old-list-structure", false);
//      configuration.setBoolean("parquet.avro.readInt96AsFixed", true);
        /*
        try(ParquetReader<ExcessRequestAvroModel> reader = AvroParquetReader
                .<ExcessRequestAvroModel>builder(new ParquetStream(partition, data))
                .withConf(configuration)
                    //.disableCompatibility()
                    .build()){
            ExcessRequestAvroModel excess = null;

            while ((excess = reader.read()) != null) {
                excesses.add(excessMessagingDataMapper.excessRequestAvroModelToExcessRequest(excess));
            }
         */
        // Opción 2 - Crear directamente el Dto a partir del generid record
        try(ParquetReader<GenericRecord> reader = AvroParquetReader
                .<GenericRecord>builder(new ParquetStream(partition, data))
                .withConf(configuration)
                //.disableCompatibility()
                .build()){

            GenericRecord excess = null;

            while ((excess = reader.read()) != null) {
                excesses.add(ExcessRequest.builder()
                        //.excessId(excess.get("excess_id").toString())
                        .excessId(UUID.randomUUID().toString())
                        .metricType(MetricType.valueOf(excess.get("metric_type").toString()))
                        .excessMetric(ExcessMetric.valueOf(excess.get("excess_metric").toString()))
                        .excessBeginDate(excess.get("excess_begin_date").toString())
                        .excessBeginTimestamp(excess.get("excess_begin_timestamp").toString())
                        .excessEndDate((excess.get("excess_end_date")!=null)?excess.get("excess_end_date").toString():null)
                        .excessEndTimestamp((excess.get("excess_end_timestamp")!=null)?excess.get("excess_end_timestamp").toString():null)
                        .limitInternalKey(excess.get("limit_internal_key").toString())
                        .excessDetail(ExcessDetailDto.builder()
                                .processDate(excess.get("process_date").toString())
                                .processTimestamp(excess.get("process_timestamp").toString())
                                .limitOrigin(excess.get("limit_origin").toString())
                                .limitShortName(excess.get("limit_short_name").toString())
                                .period(excess.get("period").toString())
                                .limitCurrency(excess.get("limit_currency").toString())
                                .limitAmount(new BigDecimal(excess.get("limit_amount").toString()))
                                .used(new BigDecimal(excess.get("used").toString()))
                                .excessReason(excess.get("excess_reason").toString())
                                .metadata(excess.hasField("metadata") ? (Map<String, Object>) excess.get("metadata") : null)
                                .build())
                        .build());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return excesses;
    }

    // CSV FORMAT
    private Set<ExcessRequest> parseCsv(InputStream data) throws IOException {
        try(Reader reader = new BufferedReader(new InputStreamReader(data))) {
            HeaderColumnNameMappingStrategy<ExcessRequest> strategy =
                    new HeaderColumnNameMappingStrategy<>();
            strategy.setType(ExcessRequest.class);
            CsvToBean<ExcessRequest> csvToBean =
                    new CsvToBeanBuilder<ExcessRequest>(reader)
                            .withMappingStrategy(strategy)
                            .withIgnoreEmptyLine(true)
                            .withIgnoreLeadingWhiteSpace(true)
                            .build();

            return new HashSet<>(csvToBean.parse());
        }
    }

    public static <T> Consumer<T> withCounter(BiConsumer<Integer, T> consumer) {
        AtomicInteger counter = new AtomicInteger(0);
        return item -> consumer.accept(counter.getAndIncrement(), item);
    }

    private boolean validateSet(Set<ExcessRequest> excesses, String partition) {

        Validator validator =  validatorFactoryBean.getValidator();
        Map<String, Map<String, List<String>>> fileErrorList = new HashMap<>();

        Integer Row = 0;
        excesses.stream().forEach(withCounter((i, excess)->{

            Map<String, List<String>> rowErrorList = new HashMap<>();

            rowErrorList = validator.validate(excess).stream().map(fieldError -> {
                return Pair.of(fieldError.getPropertyPath().toString(), fieldError.getMessage());
            }).collect(Collectors.groupingBy(Pair::getFirst, Collectors.mapping(Pair::getSecond, Collectors.toList())));

            if(!rowErrorList.isEmpty()) {
                fileErrorList.put("Row: " + i, rowErrorList);
            }
        }));
        if (!fileErrorList.isEmpty()) {
            log.warn("Error while validating the file {}, error messages: {} ", partition, Arrays.toString(List.of(fileErrorList).toArray()));
        }

        return fileErrorList.isEmpty();
    }
}