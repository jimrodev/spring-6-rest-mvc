package com.santander.scib.creame.excesses.service.domain.application.saga;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStep;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.mapper.ExcessDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.outbox.FilterOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.outbox.WorkflowOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.excesses.service.domain.core.ExcessDomainService;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessAssignedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessFilteredEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class FilterSagaHandler implements SagaStep<FilterResponse, ContextMessage> {

    private final ExcessDomainService excessDomainService;
    private final ExcessRepository excessRepository;
    private final ExcessDataMapper excessDataMapper;
    private final FilterOutboxHelper filterOutboxHelper;
    private final WorkflowOutboxHelper workflowOutboxHelper;
    private final SagaHelper sagaHelper;

    public FilterSagaHandler(ExcessDomainService excessDomainService,
                             ExcessRepository excessRepository,
                             ExcessDataMapper excessDataMapper,
                             FilterOutboxHelper filterOutboxHelper,
                             WorkflowOutboxHelper workflowOutboxHelper,
                             SagaHelper sagaHelper) {
        this.excessDomainService = excessDomainService;
        this.excessRepository = excessRepository;
        this.excessDataMapper = excessDataMapper;
        this.filterOutboxHelper = filterOutboxHelper;
        this.workflowOutboxHelper = workflowOutboxHelper;
        this.sagaHelper = sagaHelper;
    }

    @Override
    @Transactional
    public void process(FilterResponse filterResponse, ContextMessage context) {
        // SAGA STEP - Process (Filter response)
        // BEGIN - OUTBOX ATOMIC SCOPE {}

        Optional<CoordinatorMessage> coordinatorMessageFound =
                filterOutboxHelper.getOutboxMessageBySagaIdAndSagaStatus(context.getInterchangeId(),
                                                                         SagaStatus.STARTED);

        // Contingency Actions(1)
        // If not found an outbox entry with interchangeId and SagaStatus.STARTER
        // means is a duplicate message!
        if(coordinatorMessageFound.isEmpty()){
            log.info("A Filter response message with saga id: {} is already processed!", context.getInterchangeId());
            return;
        }

        // UPDATE STATUS (Excess, OUTBOX, SAGA)
        CoordinatorMessage coordinatorMessage = coordinatorMessageFound.get();

        // UPDATE the Excess status (FILTERED, UNFILTERED)
        ExcessFilteredEvent excessFilteredEvent = completeFilterForExcess(filterResponse);

        // Contingency Actions(2)
        // When receive a response of Filter Service but the outbox status is FAILED
        // Kafka callback was made with FAILED status
        // COMPlETED OUBOX STATUS
        coordinatorMessage.setOutboxStatus(OutboxStatus.COMPLETED);

        // UPDATE SAGA STATUS (CONTINUTATION, COMPLETED)
        coordinatorMessage.setSagaStatus(sagaHelper
                                        .excessStatusToSagaStatus(excessFilteredEvent.getEntity().getExcessStatus()));
        // UPDATE
        filterOutboxHelper.updateCoordinatorMessage(coordinatorMessage);

        // UNFILTERED -> NEXT SAGA STEP (WORKFLOW)
        if(excessFilteredEvent
                .getEntity()
                .getExcessStatus()
                .equals(ExcessStatus.UNFILTERED)) {

            // OUTBOX IMPLEMENTATION (SAGA CORRELATION - CONTINUATION)
            UUID outboxId = UUID.randomUUID();  // Outbox Id
            // Update context properties - SEND by headers
            context.setMessageId(excessFilteredEvent.getId());
            context.setMessageType(ExcessRequest.class.getTypeName());
            context.setEventSource(Stakeholders.EXCESS);
            workflowOutboxHelper.saveCoordinatorMessage(context.getInterchangeId(),
                                                        SagaStatus.CONTINUATION,
                                                        outboxId,
                                                        OutboxStatus.STARTED,
                                                        excessFilteredEvent,
                                                        excessDataMapper::ExcessToExcessRequest,
                                                        context);
        }

        // END - OUTBOX ATOMIC SCOPE {}
    }

    @Override
    @Transactional
    public void compensation(FilterResponse filterResponse, ContextMessage context) {
        // SAGA STEP - Compensation (Filter response)
        // BEGIN - OUTBOX ATOMIC SCOPE {}

        Optional<CoordinatorMessage> coordinatorMessageFound =
                filterOutboxHelper.getOutboxMessageBySagaIdAndSagaStatus(context.getInterchangeId(),
                                                                         SagaStatus.STARTED);

        // Contingency Actions(1)
        // If not found an outbox entry with interchangeId and SagaStatus.STARTER
        // means is a duplicate message!
        if(coordinatorMessageFound.isEmpty()){
            log.info("A Filter response message with saga id: {} is already compensated!", context.getInterchangeId());
            return;
        }

        // Compensation
        // UPDATE STATUS (Excess, OUTBOX, SAGA)
        CoordinatorMessage coordinatorMessage = coordinatorMessageFound.get();

        // UPDATE the Excess status (FAILED)
        ExcessFilteredEvent excessFilteredEvent = completeFilterForExcess(filterResponse);

        // Contingency Actions(2)
        // When receive a response of Workflow Service but the publishing filter`s outbox status is FAILED
        // Kafka callback was made with FAILED status but publisher publish message on workflow request topic
        // COMPlETED OUBOX STATUS
        coordinatorMessage.setOutboxStatus(OutboxStatus.COMPLETED);

        // UPDATE SAGA STATUS (FAILED)
        coordinatorMessage.setSagaStatus(sagaHelper
                .excessStatusToSagaStatus(excessFilteredEvent.getEntity().getExcessStatus()));

        workflowOutboxHelper.updateCoordinatorMessage(coordinatorMessage);

        // END - OUTBOX ATOMIC SCOPE {}
    }

    private ExcessFilteredEvent completeFilterForExcess(FilterResponse filterResponse) {
        log.info("Completing filter for excess id: {}", filterResponse.getExcessId());
        Excess excess = sagaHelper.findExcess(filterResponse.getExcessId());
        ExcessDetail excessDetail = sagaHelper.findExcessDetail(filterResponse.getExcessId(),
                                                                filterResponse.getProcessTimestamp());
        excess.setExcessDetail(excessDetail);

        ExcessFilteredEvent excessFilteredEvent =  excessDomainService.filter(excess,
                                                                              filterResponse.getFilterStatus());
        excessRepository.update(excess);
        return excessFilteredEvent;
    }
}
