package com.santander.scib.creame.excesses.service;

import com.santander.scib.creame.excesses.service.domain.core.ExcessDomainService;
import com.santander.scib.creame.excesses.service.domain.core.ExcessDomainServiceImpl;
import com.santander.scib.creame.excesses.service.domain.core.PartitionDomainService;
import com.santander.scib.creame.excesses.service.domain.core.PartitionDomainServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfiguration {

    @Bean
    public ExcessDomainService excessDomainService() {
        return new ExcessDomainServiceImpl();
    }
    @Bean
    public PartitionDomainService partitionDomainService(){return new PartitionDomainServiceImpl();}
}
