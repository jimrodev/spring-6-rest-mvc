package com.santander.scib.creame.excesses.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.PartitionRequestAvroModel;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import org.springframework.stereotype.Component;

@Component
public class PartitionMessagingDataMapper {

    public PartitionRequestAvroModel partitionRequestToPartitionRequestAvroModel(PartitionRequest partitionRequest) {

        return PartitionRequestAvroModel.newBuilder()
                .setPartitionId(partitionRequest.getPartitionId())
                .build();
    }

    public PartitionRequest partitionRequestAvroModelToPartitionRequest(PartitionRequestAvroModel partitionRequestAvroModel) {

        return PartitionRequest.builder()
                .partitionId(partitionRequestAvroModel.getPartitionId())
                .force(null)
                .build();
    }
}