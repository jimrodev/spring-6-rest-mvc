package com.santander.scib.creame.workflow.service.adapters.api.web.fn;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.validation.ValidationHandler;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.ports.input.service.WorkflowApplicationService;
import org.springframework.aot.hint.annotation.RegisterReflectionForBinding;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

@Component
public class WorkflowHandler {
    private final WorkflowApplicationService workflowApplicationService;

    private final ValidationHandler<WorkflowRequest, Validator> workflowValidator;

    public WorkflowHandler(WorkflowApplicationService workflowApplicationService,
                           @Qualifier("FunctionalEndPointValidator") Validator validator) {
        this.workflowApplicationService = workflowApplicationService;
        this.workflowValidator = new ValidationHandler<WorkflowRequest, Validator>(WorkflowRequest.class, validator);
   }

    @RegisterReflectionForBinding(WorkflowRequest.class)
    public Mono<ServerResponse> assign(final ServerRequest request){

        ContextMessage context = ContextMessage.builder()
                .messageType(WorkflowRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest
                .inboundTransportType("https://")
                .inboundTransportLocation(WorkflowRouterConfig.WORKFLOW_PATH)
                .build();

        return request.bodyToMono(WorkflowRequest.class)
                .doOnNext(this.workflowValidator::validate)
                .flatMap(workflowRequest ->  ServerResponse
                        .ok()
                        .header("location", UriComponentsBuilder.fromPath(WorkflowRouterConfig.WORKFLOW_PATH_ID).build(workflowRequest.getExcessId()).toString())
                        .body(Mono.just(workflowApplicationService.assign(workflowRequest, context)), WorkflowRequest.class));
                        //.bodyValue(excessApplicationService.create(excessRequest)));
    }
}
