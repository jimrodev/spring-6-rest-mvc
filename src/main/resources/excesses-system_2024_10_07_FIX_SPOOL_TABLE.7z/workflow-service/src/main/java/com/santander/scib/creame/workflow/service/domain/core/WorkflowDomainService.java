package com.santander.scib.creame.workflow.service.domain.core;

import com.santander.scib.creame.excesses.domain.valueobject.WorkflowGroup;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import com.santander.scib.creame.workflow.service.domain.core.event.WorkflowEvent;

public interface WorkflowDomainService {
   WorkflowEvent assign(Workflow workflow, WorkflowGroup assignedGroup);
}
