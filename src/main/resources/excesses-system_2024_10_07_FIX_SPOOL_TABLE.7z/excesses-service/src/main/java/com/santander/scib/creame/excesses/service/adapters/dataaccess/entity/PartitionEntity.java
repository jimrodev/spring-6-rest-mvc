package com.santander.scib.creame.excesses.service.adapters.dataaccess.entity;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionStatus;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "partitions")
@Entity
public class PartitionEntity {
    @Id
    private String partitionId;
    @Enumerated(EnumType.STRING)
    private PartitionStatus partitionStatus;
}
