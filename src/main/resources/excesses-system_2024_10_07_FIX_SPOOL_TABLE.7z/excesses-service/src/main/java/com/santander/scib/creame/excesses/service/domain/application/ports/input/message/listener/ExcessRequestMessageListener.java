package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import jakarta.validation.Valid;

public interface ExcessRequestMessageListener {
    void process(@Valid ExcessRequest excessRequest, @Valid ContextMessage context);
}
