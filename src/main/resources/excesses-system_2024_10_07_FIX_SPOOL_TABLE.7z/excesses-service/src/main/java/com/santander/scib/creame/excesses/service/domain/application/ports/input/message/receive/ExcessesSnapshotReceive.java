package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.receive;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;

import java.util.Set;

public interface ExcessesSnapshotReceive {

    public Set<ExcessRequest> processFile(String partition, ContextMessage context);

}
