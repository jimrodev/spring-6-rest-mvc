package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import jakarta.validation.Valid;

public interface FilterResponseMessageListener {
    void filter(@Valid FilterResponse filterResponse, @Valid ContextMessage context);
    void failed(@Valid FilterResponse filterResponse, @Valid ContextMessage context);
}
