package com.santander.scib.creame.excesses.service.domain.application.outbox.scheduler;

import com.santander.scib.creame.excesses.application.outbox.CoordinatorScheduler;
import com.santander.scib.creame.excesses.application.outbox.config.SchedulerConfigData;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.service.domain.application.outbox.FilterOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher.FilterMessagePublisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
public class FilterOutBoxScheduler extends CoordinatorScheduler<FilterOutboxHelper, FilterMessagePublisher> {
    public FilterOutBoxScheduler(@Value("#{Spools['filter']}") final SpoolConfigData spoolConfigData,
                                 FilterOutboxHelper coordinatorHelper,
                                 FilterMessagePublisher outboxMessagePublisher) {
        super(spoolConfigData,
              coordinatorHelper,
              outboxMessagePublisher);
    }

    @Override
    @Transactional
    @Async
    @Scheduled(fixedDelayString = "#{Schedulers['filter'].fixedDelay}" ,
             initialDelayString = "#{Schedulers['filter'].initialDelay}" )
    public void process() {

        super.process();
    }

    @Override
    @Transactional
    //@Scheduled(cron = "@midnight")
    public void clear(){

        super.clear();
    }

    @Override
    @Transactional
//    @Scheduled(fixedDelayString = "#{Schedulers['healthcheck'].fixedDelay}" ,
//            initialDelayString = "#{Schedulers['healthcheck'].initialDelay}" )
    public void healthcheck(){

        super.healthcheck();
    }
}
