package com.santander.scib.creame.excesses.service.domain.application.saga;

import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.excesses.service.domain.application.mapper.ExcessDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessDetailRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessAssignedEvent;
import com.santander.scib.creame.excesses.service.domain.core.exception.ExcessNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@Slf4j
public class SagaHelper {

    private final ExcessRepository excessRepository;
    private final ExcessDetailRepository excessDetailRepository;
    private final ExcessDataMapper excessDataMapper;

    public SagaHelper(ExcessRepository excessRepository,
                      ExcessDetailRepository excessDetailRepository,
                      ExcessDataMapper excessDataMapper) {
        this.excessRepository = excessRepository;
        this.excessDetailRepository = excessDetailRepository;
        this.excessDataMapper = excessDataMapper;
    }

    public Excess findExcess(String excessId) {
        Optional<Excess> excessFound = excessRepository.findById(new ExcessId(excessId));
        if (excessFound.isEmpty()) {
            log.error("Excess with id: {} could not be found!", excessId);
            throw new ExcessNotFoundException("Excess with id " + excessId + " could not be found!");
        }
        return excessFound.get();
    }

    public ExcessDetail findExcessDetail(String excessId, String processTimestamp) {
        Optional<ExcessDetail> excessDetailFound = excessDetailRepository.getByExcessIdAndProcessTimestamp(new ExcessId(excessId), processTimestamp);
        if (excessDetailFound.isEmpty()) {
            log.error("Excess detail with id: {} and process timestamp: {} could not be found!", excessId, processTimestamp);
            throw new ExcessNotFoundException("Excess detail with id " + excessId +
                    " and process timestamp " + processTimestamp + " could not be found!");
        }
        return excessDetailFound.get();
    }

    public SagaStatus excessStatusToSagaStatus(ExcessStatus excessStatus) {
        // REVISAR LOS ESTADOS DEL WORKFLOW
        switch (excessStatus) {
            case PENDING:
                return SagaStatus.STARTED;
            case FILTERED:
                return SagaStatus.COMPLETED;
            case UNFILTERED:
                return SagaStatus.CONTINUATION;
            case ASSIGNED:
                return SagaStatus.COMPLETED;
            case FAILED: // ESTA LA RELANZAMOS AUTOMATICAMENTE?? LE PONEMOS UN TRATAMIENTO DE REINTENTOS?
                return SagaStatus.FAILED;
            default:
                return SagaStatus.STARTED;
        }
    }
}
