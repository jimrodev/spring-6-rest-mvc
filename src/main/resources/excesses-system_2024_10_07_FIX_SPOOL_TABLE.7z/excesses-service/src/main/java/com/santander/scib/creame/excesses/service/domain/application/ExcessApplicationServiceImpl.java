package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.service.ExcessApplicationService;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.Optional;

@Slf4j
@Validated
@Service
public class ExcessApplicationServiceImpl implements ExcessApplicationService {

    private final ExcessProcessHandler excessProcessHandler;
    private final PartitionProcessHandler partitionProcessHandler;
    public ExcessApplicationServiceImpl(ExcessProcessHandler excessProcessHandler, PartitionProcessHandler partitionProcessHandler) {
        this.excessProcessHandler = excessProcessHandler;
        this.partitionProcessHandler = partitionProcessHandler;
    }

    @Override
    public ExcessResponse processExcess(ExcessRequest excessRequest, ContextMessage context) {
        return switch (excessProcessHandler.computeOperation(excessRequest)){
            case NEW -> excessProcessHandler.create(excessRequest, context);
            case UPDATE -> excessProcessHandler.update(excessRequest, context);
            case SOLVED -> excessProcessHandler.solve(excessRequest, context);
            case ALERT -> excessProcessHandler.alert(excessRequest, context);
        };
    }

    @Override
    public PartitionResponse processPartition(PartitionRequest partitionRequest, ContextMessage context) {

        return switch(partitionProcessHandler.computeOperation(partitionRequest)) {

            case PROCESS -> partitionProcessHandler.process(partitionRequest, context);
            case REPROCESS -> partitionProcessHandler.reprocess(partitionRequest, context);
            case ALERT -> partitionProcessHandler.alert(partitionRequest, context);
        };
    }
}
