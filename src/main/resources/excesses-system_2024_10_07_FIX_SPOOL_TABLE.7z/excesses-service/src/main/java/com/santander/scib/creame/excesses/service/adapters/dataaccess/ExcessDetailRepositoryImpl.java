package com.santander.scib.creame.excesses.service.adapters.dataaccess;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper.ExcessDataAccessMapper;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.repository.ExcessDetailJpaRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessDetailRepository;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class ExcessDetailRepositoryImpl implements ExcessDetailRepository {

    private final ExcessDetailJpaRepository excessDetailJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;
    public ExcessDetailRepositoryImpl(ExcessDetailJpaRepository excessDetailJpaRepository,
                                      ExcessDataAccessMapper excessDataAccessMapper) {
        this.excessDetailJpaRepository = excessDetailJpaRepository;
        this.excessDataAccessMapper = excessDataAccessMapper;
    }

    @Override
    public ExcessDetail save(ExcessDetail excessDetail) {
        ExcessDetailEntity excessDetailEntity = excessDataAccessMapper.excessDetailToExcessDetailEntity(excessDetail);
        excessDetailEntity.setNew(true);

        return excessDataAccessMapper.excessDetailEntityToExcessDetail(
                excessDetailJpaRepository
                    .save(excessDetailEntity));
    }

    @Override
    public ExcessDetail update(ExcessDetail excessDetail) {
        ExcessDetailEntity excessDetailEntity = excessDataAccessMapper.excessDetailToExcessDetailEntity(excessDetail);
        excessDetailEntity.setNew(false);

        return excessDataAccessMapper.excessDetailEntityToExcessDetail(
                excessDetailJpaRepository
                        .save(excessDataAccessMapper.excessDetailToExcessDetailEntity(excessDetail)));
    }

    @Override
    public Optional<ExcessDetail> getByExcessIdAndProcessTimestamp(ExcessId excessId, String processTimestamp) {
        return excessDetailJpaRepository
                            .findByExcessIdAndProcessTimestamp(excessId.getValue(), processTimestamp)
                .map(excessDataAccessMapper::excessDetailEntityToExcessDetail);
    }

    @Override
    public void flush() {
        excessDetailJpaRepository.flush();
    }
}
