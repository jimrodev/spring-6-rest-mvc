package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;

import java.time.ZonedDateTime;

public class ExcessCreatedEvent extends ExcessEvent {

    public ExcessCreatedEvent(Excess excess,
                              ZonedDateTime createdAt) {
        super(excess, createdAt);
    }
}
