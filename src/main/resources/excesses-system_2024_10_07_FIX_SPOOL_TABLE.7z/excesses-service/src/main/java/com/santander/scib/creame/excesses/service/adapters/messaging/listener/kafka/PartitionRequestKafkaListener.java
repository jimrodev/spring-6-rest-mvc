package com.santander.scib.creame.excesses.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.PartitionRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.PartitionRequestMessageListener;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.PartitionMessagingDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class PartitionRequestKafkaListener implements KafkaConsumer<PartitionRequestAvroModel> {

    private final PartitionRequestMessageListener partitionRequestMessageListener;
    private final PartitionMessagingDataMapper partitionMessagingDataMapper;
    private final String topicName;

    public PartitionRequestKafkaListener(PartitionRequestMessageListener partitionRequestMessageListener,
                                         PartitionMessagingDataMapper partitionMessagingDataMapper,
                                         @Value("#{@kafkaTopics['partition-request']}") String topicName) {
        this.partitionRequestMessageListener = partitionRequestMessageListener;
        this.partitionMessagingDataMapper = partitionMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    @KafkaListener(
            id = "partition-listener",
            topics = "#{@kafkaTopics['partition-request']}",
            containerFactory = "#{@kafkaListenerContainerFactories['partition']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<PartitionRequestAvroModel>> messages) {
        List<Message<PartitionRequestAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.forEach(partitionRequestAvroModelMessage -> {
            try {
                ContextMessage context = ContextMessage.builder()
                        .messageId(partitionRequestAvroModelMessage.getPayload().getPartitionId())
                        .messageType(PartitionRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.excesses.service.domain.application.dto.PartitonRequest
                        .inboundTransportType("kafka://")
                        .inboundTransportLocation(topicName)
                        .build();

                partitionRequestMessageListener.process(
                        partitionMessagingDataMapper.partitionRequestAvroModelToPartitionRequest(
                                partitionRequestAvroModelMessage.getPayload()
                        ),
                        context
                );
            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in PartitionRequestKafkaListener for partition id: {}",
                        partitionRequestAvroModelMessage.getPayload().getPartitionId());
            }
        });
    }

}