package com.santander.scib.creame.excesses.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.FilterResponseAvroModel;
import com.santander.scib.creame.avro.models.FilterStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaContextHelper;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.FilterMessagingDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.FilterResponseMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class FilterResponseKafkaListener implements KafkaConsumer<FilterResponseAvroModel> {

    private final FilterResponseMessageListener filterResponseMessageListener;
    private final FilterMessagingDataMapper filterMessagingDataMapper;
    private final String topicName;

    public FilterResponseKafkaListener(FilterResponseMessageListener filterResponseMessageListener,
                                       FilterMessagingDataMapper filterMessagingDataMapper,
                                       @Value("#{@kafkaTopics['filter-response']}") String topicName) {
        this.filterResponseMessageListener = filterResponseMessageListener;
        this.filterMessagingDataMapper = filterMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    @KafkaListener(
            id = "filter-listener",
            topics = "#{@kafkaTopics['filter-response']}",
            containerFactory = "#{@kafkaListenerContainerFactories['filter']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<FilterResponseAvroModel>> messages) {
        List<Message<FilterResponseAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.parallelStream().forEach(filterResponsetAvroModelMessage -> {
            try {
                // Load Message context (Kafka custom headers)
                ContextMessage context = KafkaContextHelper.getContextMessage(filterResponsetAvroModelMessage.getHeaders());
                ContextHelper.clean(context, ContextHelper.ContextSection.TRANSPORT);
                // MessageType
                context.setMessageType(FilterResponse.class.getTypeName());
                // Transport properties
                context.setInboundTransportType("kafka://");
                context.setInboundTransportLocation(topicName);

                FilterStatus filterStatus = filterResponsetAvroModelMessage.getPayload().getFilterStatus();
                switch (filterStatus) {
                    case FILTERED, UNFILTERED -> {
                        filterResponseMessageListener.filter(
                                filterMessagingDataMapper.filterResponseAvroModelToFilterResponse(
                                        filterResponsetAvroModelMessage.getPayload()
                                ),
                                context);
                    }
                    case FAILED -> {
                        filterResponseMessageListener.failed(
                                filterMessagingDataMapper.filterResponseAvroModelToFilterResponse(
                                        filterResponsetAvroModelMessage.getPayload()
                                ),
                                context);
                    }
                }

            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in FilterResponseKafkaListener for excess id: {}",
                        filterResponsetAvroModelMessage.getPayload().getExcessId());
            }
        });
    }
}