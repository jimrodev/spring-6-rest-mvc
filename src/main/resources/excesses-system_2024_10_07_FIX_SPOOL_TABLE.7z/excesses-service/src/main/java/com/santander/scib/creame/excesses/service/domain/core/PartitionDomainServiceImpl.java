package com.santander.scib.creame.excesses.service.domain.core;

import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionProcessedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionReprocessedEvent;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static com.santander.scib.creame.excesses.domain.DomainConstants.UTC;

@Slf4j
public class PartitionDomainServiceImpl implements PartitionDomainService {
    @Override
    public PartitionProcessedEvent process(Partition partition) {

        partition.process();
        log.info("Partition with id: {} is processing", partition.getId().getValue());

        return new PartitionProcessedEvent(partition,
                     ZonedDateTime.now(ZoneId.of(UTC)));
    }

    @Override
    public PartitionReprocessedEvent reprocess(Partition partition) {

        partition.reprocess();
        log.info("Partition with id: {} is reprocessing", partition.getId().getValue());

        return new PartitionReprocessedEvent(partition,
                ZonedDateTime.now(ZoneId.of(UTC)));
    }
}
