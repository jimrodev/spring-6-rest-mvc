package com.santander.scib.creame.filter.service.domain.core;

import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import com.santander.scib.creame.filter.service.domain.core.entity.Rule;
import com.santander.scib.creame.filter.service.domain.core.event.FilterEvent;

public interface FilterDomainService {
    FilterEvent apply(Filter filter, Rule rule);
}
