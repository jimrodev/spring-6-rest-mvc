package com.santander.scib.creame.filter.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.ports.input.message.listener.FilterRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FilterRequestMessageListenerImpl implements FilterRequestMessageListener {

    private final FilterApplyHandler filterApplyHandler;

    public FilterRequestMessageListenerImpl(FilterApplyHandler filterApplyHandler) {
        this.filterApplyHandler = filterApplyHandler;
    }

    @Override
    public void apply(FilterRequest filterRequest, ContextMessage context) {
            filterApplyHandler.apply(filterRequest, context);
    }
}
