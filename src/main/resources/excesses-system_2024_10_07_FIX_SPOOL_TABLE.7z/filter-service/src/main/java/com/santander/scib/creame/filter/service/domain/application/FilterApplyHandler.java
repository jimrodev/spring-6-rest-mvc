package com.santander.scib.creame.filter.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.application.mapper.FilterDataMapper;
import com.santander.scib.creame.filter.service.domain.application.outbox.ExcessOutboxHelper;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import com.santander.scib.creame.filter.service.domain.core.event.FilterEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.naming.Context;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class FilterApplyHandler {

    private final FilterApplyHelper filterApplyHelper;
    private final ExcessOutboxHelper excessOutboxHelper;

    public FilterApplyHandler(FilterApplyHelper filterApplyHelper,
                              ExcessOutboxHelper excessOutboxHelper,
                              FilterDataMapper filterDataMapper) {
        this.filterApplyHelper = filterApplyHelper;
        this.excessOutboxHelper = excessOutboxHelper;
        this.filterDataMapper = filterDataMapper;
    }

    private final FilterDataMapper filterDataMapper;

    @Transactional
    public FilterResponse apply (FilterRequest filterRequest, ContextMessage contextRequest){

        // BEGIN - OUTBOX ATOMIC SCOPE {}

        // Contingency Actions(1)
        // If found an entry with same excess Id
        // Do not process - Duplicate request
        Optional<Filter> filterFound = filterApplyHelper.findByExcessIdAndProcessTimestamp(
                                                                    new ExcessId(filterRequest.getExcessId()),
                                                                    filterRequest.getProcessTimestamp());

        if(filterFound.isPresent()){
            log.info("A filter request message with excess id: {} is already processed!", filterRequest.getExcessId());

            // Review for api call
            return null;
        }

        FilterEvent filterEvent = filterApplyHelper.apply(filterRequest);
        log.info("Excess is {} with id: {}", filterEvent.getEntity().getFilterStatus(),
                                             filterEvent.getEntity().getId().getValue());

        // OUTBOX IMPLEMENTATION (SAGA CORRELATION - CONTINUATION)
        UUID outboxId = UUID.randomUUID();                  // Outbox Id
        UUID sagaId = contextRequest.getInterchangeId();    // Interchange Id for the saga flow

        // Load context properties - Send by headers (Event Bus)
        contextRequest.setMessageId(filterEvent.getId());
        contextRequest.setMessageType(FilterResponse.class.getTypeName());
        contextRequest.setEventSource(Stakeholders.FILTER);

        // SAVE Outbox Message (Event Message, Message Context)
        excessOutboxHelper.saveCoordinatorMessage(sagaId,
                                                  SagaStatus.CONTINUATION,
                                                  outboxId,
                                                  OutboxStatus.STARTED,
                                                  filterEvent,
                                                  filterDataMapper::FilterToFilterResponse,
                                                  contextRequest);

        // END - OUTBOX ATOMIC SCOPE {}
        return filterDataMapper.FilterToFilterResponse(filterEvent.getEntity());
    }
}
