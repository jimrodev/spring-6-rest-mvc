package com.santander.scib.creame.filter.service.domain.core.exception;

import com.santander.scib.creame.excesses.domain.exception.DomainException;

public class FilterNotFoundException extends DomainException {

    public FilterNotFoundException(String message) {
        super(message);
    }

    public FilterNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
