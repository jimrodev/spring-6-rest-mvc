package com.santander.scib.creame.filter.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.util.List;
import java.util.Optional;

public interface FilterRepository {

    Filter save(Filter filter);
    Filter update(Filter filter);
    Optional<List<Filter>> findById(ExcessId excessId);
    Optional<Filter> findByExcessIdAndProcessTimestamp(ExcessId excessId, String processTimestamp);
}
