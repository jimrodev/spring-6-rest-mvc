package com.santander.scib.creame.filter.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepository;

public interface ExcessOutboxRepository extends CoordinatorRepository {
}
