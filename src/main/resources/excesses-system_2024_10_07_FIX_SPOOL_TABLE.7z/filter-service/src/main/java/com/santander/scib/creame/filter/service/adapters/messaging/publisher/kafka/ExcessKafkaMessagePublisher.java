package com.santander.scib.creame.filter.service.adapters.messaging.publisher.kafka;

import com.santander.scib.creame.avro.models.FilterResponseAvroModel;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.OutboxCommonHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaOutboxMessagePublisher;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducerHelper;
import com.santander.scib.creame.filter.service.adapters.messaging.mapper.FilterMessagingDataMapper;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.application.outbox.ExcessOutboxHelper;
import com.santander.scib.creame.filter.service.domain.application.ports.output.message.publisher.ExcessMessagePublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;

@Slf4j
@Component
public class ExcessKafkaMessagePublisher extends KafkaOutboxMessagePublisher<FilterResponse, FilterResponseAvroModel, CoordinatorMessage>
                                         implements ExcessMessagePublisher {

    private final FilterMessagingDataMapper filterMessagingDataMapper;
    private final String topicName;

    public ExcessKafkaMessagePublisher(FilterMessagingDataMapper filterMessagingDataMapper,
                                       ExcessOutboxHelper excessOutboxHelper,
                                       @Value("#{@KafkaProducers['excesses']}")  KafkaProducer<String, FilterResponseAvroModel> kafkaProducer,
                                       KafkaProducerHelper kafkaProducerHelper,
                                       @Value("#{@kafkaTopics['filter-response']}") String topicName){
        super(kafkaProducer, kafkaProducerHelper);
        this.filterMessagingDataMapper = filterMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    public void publish(CoordinatorMessage coordinatorMessage, BiConsumer<CoordinatorMessage, OutboxStatus> outboxCallback) {
        // Set output context properties
        ContextMessage context = OutboxCommonHelper.deserializePayload(coordinatorMessage.getContext(),
                                                                        ContextMessage.class);
        // Message Type
        context.setMessageType(FilterResponse.class.getTypeName());
        // Outbound transport properties
        context.setOutboundTransportType("Kafka://");
        context.setOutboundTransportLocation(topicName);

        coordinatorMessage.setContext(OutboxCommonHelper.serializeContext(coordinatorMessage.getOutboxId(),

                                                                          context));
        // Publish message (Event bus)
        publish(coordinatorMessage,
                outboxCallback,
                filterMessagingDataMapper::filterResponseToFilterResponseAvroModel,
                topicName);
    }

    @Override
    public void flush() {
        super.flush();
    }
}
