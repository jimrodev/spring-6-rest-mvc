package com.santander.scib.creame.excesses.application.outbox.config;

import lombok.Data;

@Data
public class SchedulerConfigData {
    private String fixedDelay;
    private String initialDelay;
}
