package com.santander.scib.creame.excesses.domain.event;

import org.apache.logging.log4j.util.Strings;

import java.time.ZonedDateTime;

public class EmptyEvent implements DomainEvent<Void>{
    public static final EmptyEvent INSTANCE = new EmptyEvent();

    private EmptyEvent(){}

    @Override
    public Void getEntity() {
        return null;
    }

    @Override
    public ZonedDateTime getCreatedAt() {
        return null;
    }

    @Override
    public String getId()
    {
        return Strings.EMPTY;
    }
}
