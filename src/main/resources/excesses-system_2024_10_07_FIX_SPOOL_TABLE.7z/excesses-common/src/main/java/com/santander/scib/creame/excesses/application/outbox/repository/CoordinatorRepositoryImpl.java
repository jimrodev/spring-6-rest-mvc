package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.application.outbox.mapper.CoordinatorDataAccessMapper;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import org.springframework.data.domain.PageRequest;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.stream.Collectors;

public abstract class CoordinatorRepositoryImpl implements CoordinatorRepository {

    private final String eventSource;
    private final String eventTarget;
    private final CoordinatorJpaRepository coordinatorJpaRepository;
    private final CoordinatorDataAccessMapper coordinatorDataAccessMapper;

    public CoordinatorRepositoryImpl(String eventSource,
                                     String eventTarget,
                                     CoordinatorJpaRepository coordinatorJpaRepository,
                                     CoordinatorDataAccessMapper coordinatorDataAccessMapper) {
        this.eventSource = eventSource;
        this.eventTarget = eventTarget;
        this.coordinatorJpaRepository = coordinatorJpaRepository;
        this.coordinatorDataAccessMapper = coordinatorDataAccessMapper;
    }

    @Override
    public int insert(CoordinatorMessage coordinatorMessage) {

        return coordinatorJpaRepository
                .insert(coordinatorDataAccessMapper.coordinatorMessageToCoordinatorEntity(coordinatorMessage));
    }

    @Override
    public int update(CoordinatorMessage coordinatorMessage) {

        return coordinatorJpaRepository
                .update(coordinatorDataAccessMapper.coordinatorMessageToCoordinatorEntity(coordinatorMessage));
    }

    @Override
    public CoordinatorMessage save(CoordinatorMessage coordinatorMessage) {

        return coordinatorDataAccessMapper
                .coordinatorEntityCoordinatorMessage(coordinatorJpaRepository
                        .save(coordinatorDataAccessMapper
                                .coordinatorMessageToCoordinatorEntity(coordinatorMessage)));
    }

    @Override
    public Optional<CoordinatorMessage> findByOutboxId(UUID outboxId) {
        return (coordinatorJpaRepository
                .findById(outboxId)
                .map(coordinatorDataAccessMapper::coordinatorEntityCoordinatorMessage));
    }

    @Override
    public Optional<CoordinatorMessage> findBySagaIdAndSagaStatus(UUID sagaId,
                                                                  SagaStatus... sagaStatus) {
        return coordinatorJpaRepository
                .findBySagaIdAndSagaStatus(
                        this.eventSource,
                        this.eventTarget,
                        sagaId,
                        Arrays.asList(sagaStatus))
                .map(coordinatorDataAccessMapper::coordinatorEntityCoordinatorMessage);
    }

    @Override
    public int updateSagaStatusBySagaIdAndSagaStatus(UUID sagaId,
                                                     List<SagaStatus> sagaStatus,
                                                     SagaStatus newSagaStatus) {

            return coordinatorJpaRepository
                    .updateSagaStatusBySagaIdAndSagaStatus(
                                    sagaId,
                                    sagaStatus,
                                    newSagaStatus);
    }

    @Override
    public int updateOutboxStatusByOutboxStatusAndSagaStatusAndProcessedAt(List<OutboxStatus> outboxStatus,
                                                                           List<SagaStatus> sagasStatus,
                                                                           Integer retryInterval,
                                                                           OutboxStatus newOutboxStatus) {

        return coordinatorJpaRepository
                .updateOutboxStatusByOutboxStatusAndSagaStatusAndProcessedAt(
                        this.eventSource,
                        this.eventTarget,
                        outboxStatus,
                        sagasStatus,
                        ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)).minusMinutes(retryInterval),
                        newOutboxStatus);
    }

    @Override
    public Optional<List<CoordinatorMessage>> findByOutboxStatusAndSagaStatus(Integer maxBatchSize,
                                                                              List<OutboxStatus> outboxStatus,
                                                                              SagaStatus... sagaStatus) {
        return Optional.of(coordinatorJpaRepository
               .findByOutboxStatusAndSagaStatus(
                    this.eventSource,
                    this.eventTarget,
                    outboxStatus,
                    Arrays.asList(sagaStatus),
                    PageRequest.of(0,maxBatchSize))
               .stream()
               .flatMap(Collection::stream)
               .map(coordinatorDataAccessMapper::coordinatorEntityCoordinatorMessage)
               .collect(Collectors.toList()));
    }

    @Override
    public Optional<List<CoordinatorMessage>> findByCreatedAtAndOutboxStatusAndSagaStatus(Integer maxBatchSize,
                                                                                          ZonedDateTime createdAt,
                                                                                          List<OutboxStatus> outboxStatus,
                                                                                          SagaStatus... sagaStatus) {
        return Optional.of(coordinatorJpaRepository
                .findByCreatedAtAndOutboxStatusAndSagaStatus(
                        this.eventSource,
                        this.eventTarget,
                        createdAt,
                        outboxStatus,
                        Arrays.asList(sagaStatus),
                        PageRequest.of(0,maxBatchSize))
                .stream()
                .flatMap(Collection::stream)
                .map(coordinatorDataAccessMapper::coordinatorEntityCoordinatorMessage)
                .collect(Collectors.toList()));
    }

    @Override
    public int deleteByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                                 SagaStatus... sagaStatus) {
        return coordinatorJpaRepository
                .deleteByOutboxStatusAndSagaStatus(
                    this.eventSource,
                    this.eventTarget,
                    outboxStatus,
                    Arrays.asList(sagaStatus));
    }

    @Override
    public void flush() {
        coordinatorJpaRepository.flush();;
    }
}
