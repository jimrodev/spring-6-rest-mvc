package com.santander.scib.creame.excesses.application.outbox.helper;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.SpoolQueue;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepository;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.excesses.domain.exception.DomainException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Function;

@Slf4j
public abstract class CoordinatorHelper<T extends CoordinatorRepository> {

    private final SpoolQueue spoolQueue;
    private final String eventSource;
    private final String eventTarget;
    private final SpoolConfigData spoolConfigData;
    private final T coordinatorRepository;
    private final ExecutorService executorService;
    private ZonedDateTime currentCreateAt;

    public CoordinatorHelper(String eventSource,
                             String eventTarget,
                             SpoolConfigData spoolConfigData,
                             T coordinatorRepository) {
        this.eventSource = eventSource;
        this.eventTarget = eventTarget;
        this.spoolConfigData = spoolConfigData;
        this.coordinatorRepository = coordinatorRepository;
        this.currentCreateAt = ZonedDateTime.of(1970,1,1,0,0,0,0, ZoneId.of(DomainConstants.UTC));

        // Coordinator SpoolQueue
        this.spoolQueue = new SpoolQueue(this.spoolConfigData);

        // Executor service
        // To execute DB Operations outside the I/O Kafka producer Thread
        executorService = Executors.newFixedThreadPool(this.spoolConfigData.getThreadPoolSize());
    }

    @Transactional(readOnly = true)
    public Optional<List<CoordinatorMessage>>
    getOutboxMessageByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                                SagaStatus... sagaStatus) {

//        return OutboxCommonHelper.filterSpoolQueue(
//                this.spoolQueue,
//                this.coordinatorRepository
//                        .findByOutboxStatusAndSagaStatus(
//                                this.spoolConfigData.getMaxBatchSize(),
//                                outboxStatus,
//                                sagaStatus)
//        );

        // PROCESS SPOOL TABLE
        Optional<List<CoordinatorMessage>> coordinatorMessages =
                this.coordinatorRepository
                        .findByCreatedAtAndOutboxStatusAndSagaStatus(
                                this.spoolConfigData.getMaxBatchSize(),
                                this.currentCreateAt,
                                outboxStatus,
                                sagaStatus);

        // SLIDES (SpoolBatchSize) ruled by created at
        if (coordinatorMessages.isPresent() && !coordinatorMessages.get().isEmpty()) {

            // If found messages means we are in one of the Spool Table Slides 0,1, ... n
            List<CoordinatorMessage> coordinatorMessagesList = coordinatorMessages.get();

            // Slides 0,1,...
            if(coordinatorMessagesList.size() == spoolConfigData.getMaxBatchSize()){
                // Update created at with the last message in the Slide
                this.currentCreateAt = coordinatorMessagesList.get(coordinatorMessagesList.size()-1).getCreatedAt();
            // Slide n (Last)
            } else {
                // RESTART THE PROCESS
                this.currentCreateAt = ZonedDateTime.of(1970,1,1,0,0,0,0, ZoneId.of(DomainConstants.UTC));
            }
        // Empty Spool Table
        } else {
            // RESTART THE PROCESS (Redundant)
            this.currentCreateAt = ZonedDateTime.of(1970,1,1,0,0,0,0, ZoneId.of(DomainConstants.UTC));
        }

        return OutboxCommonHelper.filterSpoolQueue(
                this.spoolQueue,
                coordinatorMessages);
    }

//    @Transactional(readOnly = true)
//    public Optional<List<CoordinatorMessage>>
//    getOutboxMessageByCreatedAtAndOutboxStatusAndSagaStatus(ZonedDateTime createdAt,
//                                                            List<OutboxStatus> outboxStatus,
//                                                            SagaStatus... sagaStatus) {
//        return OutboxCommonHelper.filterSpoolQueue(
//                this.spoolQueue,
//                this.coordinatorRepository
//                .findByCreatedAtAndOutboxStatusAndSagaStatus(
//                        this.spoolConfigData.getMaxBatchSize(),
//                        createdAt,
//                        outboxStatus,
//                        sagaStatus)
//                );
//    }

    @Transactional(readOnly = true)
    public Optional<CoordinatorMessage>
    getOutboxMessageBySagaIdAndSagaStatus(UUID sagaId,
                                          SagaStatus... sagaStatus) {
        return coordinatorRepository
                .findBySagaIdAndSagaStatus(
                    sagaId,
                    sagaStatus);
    }

    private void save(CoordinatorMessage coordinatorMessage) {
        CoordinatorMessage response = coordinatorRepository.save(coordinatorMessage);
        if (response == null) {
            log.error("Could not save CoordinatorMessage with message id: {} and outbox id: {}",
                    coordinatorMessage.getMessageId(),
                    coordinatorMessage.getOutboxId());
            throw new DomainException("Could not save CoordinatorMessage with message id: " +
                    coordinatorMessage.getMessageId() +
                    " and outbox id: " +
                    coordinatorMessage.getOutboxId());
        }
        log.info("CoordinatorMessage saved with message id: {} and outbox id: {}",
                coordinatorMessage.getMessageId(),
                coordinatorMessage.getOutboxId());
    }

    @Transactional
    public <U, V> void saveCoordinatorMessage(UUID sagaId,
                                              SagaStatus sagaStatus,
                                              UUID outboxId,
                                              OutboxStatus outboxStatus,
                                              DomainEvent<U> domainEvent,
                                              Function<U, V> mapper,
                                              ContextMessage context)
    {

        save(CoordinatorMessage.builder()
                .outboxId(outboxId)
                .sagaId(sagaId)
                .createdAt(domainEvent.getCreatedAt())
                .processedAt(domainEvent.getCreatedAt())
                .messageId(domainEvent.getId())
                .payload(OutboxCommonHelper.serializePayload(outboxId, mapper.apply(domainEvent.getEntity())))
                .context(OutboxCommonHelper.serializeContext(outboxId, context))
                .eventSource(this.eventSource)
                .eventTarget(this.eventTarget)
                .sagaStatus(sagaStatus)
                .outboxStatus(outboxStatus)
                .isNew(true)
                .build());
    }

    @Transactional
    public int deleteOutboxMessageByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                                              SagaStatus... sagaStatus) {
        return coordinatorRepository
                .deleteByOutboxStatusAndSagaStatus(outboxStatus,
                                                   sagaStatus);
    }

    @Transactional
    public void updateSagaStatus(CoordinatorMessage coordinatorMessage) {

        // REVISAR ESTO, a lo mejor no es necesario hacer la actualizador en el Task executor
        //this.executorService.submit(()->{
            try {
                log.info("CoordinatorMessage with outbox id: {} is updated with saga tatus: {}",
                        coordinatorMessage.getOutboxId(),
                        coordinatorMessage.getSagaStatus());

                // Update coordinator message
                coordinatorMessage.setProcessedAt(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
                coordinatorMessage.setNew(false);
                save(coordinatorMessage);

            } catch (OptimisticLockingFailureException e) {

                // Contingency Actions(1)
                // Otimistic locking exception
                Optional<CoordinatorMessage>  optCoordinatorMessage = coordinatorRepository.findByOutboxId(coordinatorMessage.getOutboxId());
                if(optCoordinatorMessage.isPresent()) {

                    CoordinatorMessage coordinatorMessageToUpdate = optCoordinatorMessage.get();
                    coordinatorMessageToUpdate.setOutboxStatus(coordinatorMessage.getOutboxStatus());
                    coordinatorMessageToUpdate.setSagaStatus(coordinatorMessage.getSagaStatus());
                    coordinatorMessageToUpdate.setProcessedAt(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
                    coordinatorMessageToUpdate.setNew(false);
                    save(coordinatorMessageToUpdate);

                    log.info("Caught optimistic locking exception in updateCoordinatorMessage with outbox id: {} ",
                            coordinatorMessageToUpdate.getOutboxId());
                }
            }
        //});
    }

    @Transactional
    public void updateOutboxStatus(CoordinatorMessage coordinatorMessage, OutboxStatus outboxStatus) {

        // Execute the Outbox Status DB update in other Thread (Not inside I/O Kafka Producer Thread)
        this.executorService.submit(()->{

            ZonedDateTime processedAt = ZonedDateTime.now(ZoneId.of(DomainConstants.UTC));

            try{
                // Update de spool queue
                if(spoolQueue.getSpoolQueue().containsKey(coordinatorMessage.getOutboxId())) {

                    // Update spool queue info
                    SpoolQueue.QueueInfo queueInfo = spoolQueue.getSpoolQueue().get(coordinatorMessage.getOutboxId());
                    queueInfo.setLastProcessedAt(processedAt);
                }

                // Update outbox status (COMPLETED/FAILED)
                if(this.spoolConfigData.getUpdateOutboxStatus()) {

                    log.info("CoordinatorMessage with outbox id: {} is updated with outbox status: {}",
                            coordinatorMessage.getOutboxId(),
                            outboxStatus.name());

                    // UPDATE
                    coordinatorMessage.setOutboxStatus(outboxStatus);
                    coordinatorMessage.setProcessedAt(processedAt);
                    coordinatorMessage.setNew(false);
                    save(coordinatorMessage);
                }

            } catch (OptimisticLockingFailureException e) {

                log.info("Caught optimistic locking exception in updateOutboxStatus with outbox id: {} ",
                        coordinatorMessage.getOutboxId());

                // Contingency Actions(1)
                // Otimistic locking exception
                // When receive the response from service before ack from the kafka callback
                Optional<CoordinatorMessage>  optCoordinatorMessage = coordinatorRepository.findByOutboxId(coordinatorMessage.getOutboxId());
                if(optCoordinatorMessage.isPresent()) {

                    CoordinatorMessage coordinatorMessageToUpdate = optCoordinatorMessage.get();

                    // If the saga step COMPLETED the outbox satatus before the kafka's callback be called
                    if(coordinatorMessageToUpdate.getOutboxStatus().equals(OutboxStatus.COMPLETED)){

                        // Revisar esta traza !!!!!!
                        log.info("Houston we have a problem, outbox id: {} has been completed by a saga step before the kafka's callback be called",
                                   coordinatorMessage.getOutboxId());

                    }else { // REVISAR EL ESTADO STARTED/FAILED
                        coordinatorMessageToUpdate.setOutboxStatus(outboxStatus);
                        coordinatorMessageToUpdate.setProcessedAt(processedAt);
                        coordinatorMessageToUpdate.setNew(false);
                        save(coordinatorMessageToUpdate);
                    }
                }
            }
            // Remove from spool queue
            if(this.spoolConfigData.getSpoolQueue()
                                   .getEntryClean()) {
                spoolQueue.getSpoolQueue().remove(coordinatorMessage.getOutboxId());
            }
        });
    }

    @Transactional
    public int updateSagaStatusBySagaIdAndSagaStatus(UUID sagaId,
                                                     List<SagaStatus> sagaStatus,
                                                     SagaStatus newSagaStatus) {
        return coordinatorRepository
                .updateSagaStatusBySagaIdAndSagaStatus(sagaId,
                                             sagaStatus,
                                             newSagaStatus);
    }

    @Transactional
    public int updateOutboxStatusByOutboxStatusAndProcessedAt(List<OutboxStatus> outboxStatus,
                                                              Integer retryInterval,
                                                              OutboxStatus newOutboxStatus) {

        if(spoolConfigData.getTransportOptions().getEnableFaultTolerance()) {
            return coordinatorRepository
                    .updateOutboxStatusByOutboxStatusAndSagaStatusAndProcessedAt(
                            outboxStatus,
                            Arrays.asList(SagaStatus.STARTED, SagaStatus.CONTINUATION, SagaStatus.COMPENSATING),
                            retryInterval,
                            newOutboxStatus);
        }else
            return 0;
    }
}
