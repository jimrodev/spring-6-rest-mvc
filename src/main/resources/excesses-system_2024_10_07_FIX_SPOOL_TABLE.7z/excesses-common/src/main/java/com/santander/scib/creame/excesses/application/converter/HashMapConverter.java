package com.santander.scib.creame.excesses.application.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.AttributeConverter;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Helper class to handle JSON objects.
 * This class provides methods for serialize and deserialize JSON Objects when dealing with relational database.
 */
@Slf4j
public class HashMapConverter implements AttributeConverter<Map<String, Object>, String> {

    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Convert a JSON object to String.
     *
     * @param metadata JSON object's HashMap representation
     * @return a String with the JSON object's serialization
     */
    @Override
    public String convertToDatabaseColumn(Map<String, Object> metadata) {

        String metadataJson = null;
        try {
            metadataJson = objectMapper.writeValueAsString(metadata);
        } catch (final JsonProcessingException e) {
            log.error("JSON writing error", e);
        }

        return metadataJson;
    }

    /**
     * Convert a String to JSON object.
     *
     * @param metadata JSON object's String representation
     * @return a HashMap with the JSON object's deserialization
     */
    @Override
    public Map<String, Object> convertToEntityAttribute(String metadata) {

        Map<String, Object> metadataHashMap =  null;
        try {
            metadataHashMap = objectMapper.readValue(metadata, new TypeReference<HashMap<String, Object>>() {});
        } catch (final IOException e) {
            log.error("JSON reading error", e);
        }

        return metadataHashMap;
    }
}
