package com.santander.scib.creame.excesses.application.outbox.helper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.SpoolQueue;
import com.santander.scib.creame.excesses.application.outbox.SpoolQueue.QueueInfo;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.domain.exception.DomainException;
import lombok.extern.slf4j.Slf4j;

import java.time.Duration;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
public class OutboxCommonHelper {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static  <U> String serializePayload(UUID outboxId, U eventPayload) {
        try {
            return objectMapper.writeValueAsString(eventPayload);
        } catch (JsonProcessingException e) {
            log.error("Could not serialize EventPayload for outbox id: {}", outboxId, e);
            throw new DomainException("Could not serialize EventPayload for outbox id: " + outboxId, e);
        }
    }

    public static <U> String serializeContext(UUID outboxId, U contextPayload) {
        try {
            return objectMapper.writeValueAsString(contextPayload);
        } catch (JsonProcessingException e) {
            log.error("Could not serialize ContextPayload for outbox id: {}", outboxId, e);
            throw new DomainException("Could not serialize ContextPayload for outbox id: " + outboxId, e);
        }
    }

    public static <U> U deserializePayload(String payload, Class<U> outputType) {
        try {
            return objectMapper.readValue(payload, outputType);
        } catch (JsonProcessingException e) {
            log.error("Could not deserialize {} object!", outputType.getName(), e);
            throw new DomainException("Could not deserialize " + outputType.getName() + " object!", e);
        }
    }

    public static Optional<List<CoordinatorMessage>> filterSpoolQueue(SpoolQueue spoolQueue,
                                                                      Optional<List<CoordinatorMessage>> outboxMessages){

        // First Tacking the spool queue
        trackingSpoolQueue(spoolQueue);

        if (outboxMessages.isPresent() && !outboxMessages.get().isEmpty()) {

            List<CoordinatorMessage> outboxMessagesList = outboxMessages.get();

            // Tracking the spool queue - NEW
            List<CoordinatorMessage> outboxTrackedList = outboxMessagesList
                    .stream()
                    .filter(outboxMessage -> {

                        // If message is inside the spool queue
                        if(spoolQueue.getSpoolQueue().containsKey(outboxMessage.getOutboxId()))
                        {
                            // Update spool queue info
                            QueueInfo queueInfo = spoolQueue.getSpoolQueue().get(outboxMessage.getOutboxId());
                            // Increment scheduler pass count
                            queueInfo.incrementPassCount();

                            return false;
                        } else {

                            // Add new tracked message to spool queue
                            spoolQueue.getSpoolQueue().put(outboxMessage.getOutboxId(),
                                                  new QueueInfo(outboxMessage.getOutboxId(),
                                                                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)),
                                                                outboxMessage.getOutboxStatus()));
                            return true;
                        }
                    })
                    .collect(Collectors.toList());

            return Optional.of(outboxTrackedList);
        }
        return outboxMessages;
    }

    private static void trackingSpoolQueue(SpoolQueue spoolQueue){
        spoolQueue.getSpoolQueue()
                .entrySet()
                .removeIf(spoolEntry -> {
                    // Here all spool queue validation (By config section)
                    QueueInfo queueInfo = spoolEntry.getValue();

                    // LIFETIME
                    // Lifetime (Expiration time)
                    Duration d = Duration.between(queueInfo.getLastProcessedAt(),
                                                  ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));

                    if (d.toMinutes() > spoolQueue.getSpoolConfigData()
                                                   .getSpoolQueue()
                                                   .getEntryDuration()) {
                        return true;
                    }

                    return false;
                });
    };
}
