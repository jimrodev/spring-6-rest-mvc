package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.FilterResponseMessageListener;
import com.santander.scib.creame.excesses.service.domain.application.saga.FilterSagaHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class FilterResponseMessageListenerImpl implements FilterResponseMessageListener {

    private final FilterSagaHandler filterSagaHandler;

    public FilterResponseMessageListenerImpl(FilterSagaHandler filterSagaHandler) {
        this.filterSagaHandler = filterSagaHandler;
    }

    @Override
    @Transactional
    public void filter(FilterResponse filterResponse, ContextMessage context) {
        filterSagaHandler.process(filterResponse, context);
        log.info("Filter Saga operation is completed for excess id: {}", filterResponse.getExcessId());

    }

    @Override
    public void failed(FilterResponse filterResponse, ContextMessage context) {
        // DEJAMOS EL SAGA EN FAILED? -> RELANZADO AUTOMÁTICO - RETRY (DELAY, COUNT, INTERVAL)
        // LANZAMOS ALERTA?
        filterSagaHandler.compensation(filterResponse, context);
    }
}
