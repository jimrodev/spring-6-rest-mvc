package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionReprocessedEvent extends PartitionEvent {

    public PartitionReprocessedEvent(Partition partition,
                                     ZonedDateTime createdAt) {
        super(partition, createdAt);
    }
}
