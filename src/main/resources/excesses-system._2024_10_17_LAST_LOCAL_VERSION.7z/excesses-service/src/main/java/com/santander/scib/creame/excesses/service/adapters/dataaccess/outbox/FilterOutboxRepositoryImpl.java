package com.santander.scib.creame.excesses.service.adapters.dataaccess.outbox;

import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.outbox.mapper.CoordinatorDataAccessMapper;
import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorJpaRepository;
import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepositoryImpl;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.FilterOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FilterOutboxRepositoryImpl extends CoordinatorRepositoryImpl implements FilterOutboxRepository {

    public FilterOutboxRepositoryImpl(@Value(Stakeholders.EXCESS) final String eventSource,
                                      @Value(Stakeholders.FILTER) final String eventTarget,
                                      CoordinatorJpaRepository coordinatorJpaRepository,
                                      CoordinatorDataAccessMapper coordinatorDataAccessMapper) {
        super(eventSource, eventTarget, coordinatorJpaRepository, coordinatorDataAccessMapper);
    }
}
