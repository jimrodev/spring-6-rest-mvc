package com.santander.scib.creame.excesses.service.domain.core.exception;

import com.santander.scib.creame.excesses.domain.exception.DomainException;

public class ExcessDomainException extends DomainException {

    public ExcessDomainException(String message) {
        super(message);
    }

    public ExcessDomainException(String message, Throwable cause) {
        super(message, cause);
    }
}
