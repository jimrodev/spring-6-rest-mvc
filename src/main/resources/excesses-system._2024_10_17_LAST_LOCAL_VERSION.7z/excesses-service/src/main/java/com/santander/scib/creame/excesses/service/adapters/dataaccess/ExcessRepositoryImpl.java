package com.santander.scib.creame.excesses.service.adapters.dataaccess;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
            import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper.ExcessDataAccessMapper;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.repository.ExcessJpaRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class ExcessRepositoryImpl implements ExcessRepository {

    private final ExcessJpaRepository excessJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;

    public ExcessRepositoryImpl(ExcessJpaRepository customerJpaRepository,
                                ExcessDataAccessMapper customerDataAccessMapper) {
        this.excessJpaRepository = customerJpaRepository;
        this.excessDataAccessMapper = customerDataAccessMapper;
    }

    @Override
    public Optional<Excess> findById(ExcessId excessId) {
//     return excessJpaRepository.findById(excessId.getValue())
//                .map(excessDataAccessMapper::excessEntityToExcess);
        return excessJpaRepository.findByExcessId(excessId.getValue())
                .map(excessDataAccessMapper::excessEntityToExcess);
    }

    @Override
    public Excess save(Excess excess) {
        ExcessEntity excessEntity = excessDataAccessMapper.excessToExcessEntity(excess);
        excessEntity.setNew(true);

        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessEntity));
    }

    @Override
    public Excess update(Excess excess) {
        ExcessEntity excessEntity = excessDataAccessMapper.excessToExcessEntity(excess);
        excessEntity.setNew(false);

        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessEntity));
    }

    @Override
    public void flush() {
        excessJpaRepository.flush();
    }
}
