package com.santander.scib.creame.excesses.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.WorkflowRequestAvroModel;
import com.santander.scib.creame.avro.models.WorkflowResponseAvroModel;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowStatus;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowResponse;
import org.springframework.stereotype.Component;

@Component
public class WorkflowMessagingDataMapper {
    public WorkflowResponse workflowResponseAvroModelToWorkflowResponse(WorkflowResponseAvroModel workflowResponseAvroModel) {
        return WorkflowResponse.builder()
                .excessId(workflowResponseAvroModel.getExcessId())
                .processTimestamp(workflowResponseAvroModel.getProcessTimestamp())
                .workflowStatus(WorkflowStatus.valueOf(workflowResponseAvroModel.getWorkflowStatus().name()))
                .build();
    }

    public WorkflowRequestAvroModel excessRequestToWorkflowRequestAvroModel(ExcessRequest excessRequest){

        return WorkflowRequestAvroModel.newBuilder()
                .setExcessId(excessRequest.getExcessId())
                .setProcessTimestamp(excessRequest.getExcessDetail().getProcessTimestamp())
                .build();
    }
}
