package com.santander.scib.creame.excesses.service.adapters.dataaccess.repository;

import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
public interface ExcessJpaRepository  extends JpaRepository<ExcessEntity, String> {

    @Transactional(readOnly = true)
    Optional<ExcessEntity> findByExcessId(String excessId);
}
