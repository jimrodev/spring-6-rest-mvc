package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import jakarta.validation.Valid;

public interface PartitionRequestMessageListener {
    void process(@Valid PartitionRequest partitionRequest, @Valid ContextMessage context);
}
