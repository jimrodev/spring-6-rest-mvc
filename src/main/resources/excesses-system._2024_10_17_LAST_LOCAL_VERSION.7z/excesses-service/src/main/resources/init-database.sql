DROP SCHEMA IF EXISTS excesses CASCADE;

CREATE SCHEMA excesses;

DROP TABLE IF EXISTS excesses.partitions;

CREATE TABLE excesses.partitions
(
    partition_id VARCHAR NOT NULL,
    partition_status VARCHAR NOT NULL
);

DROP TABLE IF EXISTS excesses.excesses;

CREATE TABLE excesses.excesses
(
    excess_id VARCHAR NOT NULL,
    metric_type VARCHAR NOT NULL,
    excess_metric VARCHAR NOT NULL,
    excess_begin_date VARCHAR NOT NULL,
    excess_begin_timestamp VARCHAR NOT NULL,
    excess_end_date VARCHAR,
    excess_end_timestamp VARCHAR,
    limit_internal_Key VARCHAR NOT NULL,
    excess_type VARCHAR NOT NULL,
    excess_status VARCHAR NOT NULL,
    CONSTRAINT excess_pkey PRIMARY KEY (excess_id)
);

DROP TABLE IF EXISTS excesses.excesses_history;

CREATE TABLE excesses.excesses_history
(
    excess_id VARCHAR NOT NULL,
    process_timestamp VARCHAR NOT NULL,
    process_date VARCHAR NOT NULL,
    limit_origin VARCHAR NOT NULL,
    limit_short_name VARCHAR NOT NULL,
    period VARCHAR NOT NULL,
    limit_currency VARCHAR NOT NULL,
    limit_amount VARCHAR NOT NULL,
    used VARCHAR NOT NULL,
    excess_reason VARCHAR NOT NULL,
    metadata VARCHAR,
    CONSTRAINT excess_history_pkey PRIMARY KEY (excess_id, process_timestamp)
);

DROP TYPE IF EXISTS saga_status;
CREATE TYPE saga_status AS ENUM ('STARTED', 'COMPLETED',  'RETRY', 'FAILED', 'CONTINUATION', 'COMPENSATING', 'COMPENSATED');

DROP TYPE IF EXISTS outbox_status;
CREATE TYPE outbox_status AS ENUM ('STARTED', 'COMPLETED', 'RETRY', 'FAILED');

DROP TABLE IF EXISTS excesses.excess_coordinator;
CREATE TABLE excesses.excess_coordinator
(
    outbox_id uuid NOT NULL,
    saga_id uuid NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    processed_at TIMESTAMP WITH TIME ZONE,
    event_source character varying COLLATE pg_catalog."default" NOT NULL,
    event_target character varying COLLATE pg_catalog."default" NOT NULL,
    message_id VARCHAR NOT NULL,
    payload jsonb NOT NULL,
    context jsonb NOT NULL,
    outbox_status outbox_status NOT NULL,
    saga_status saga_status NOT NULL,
    version integer NOT NULL,
    CONSTRAINT excess_coordinator_pkey PRIMARY KEY (outbox_id)
);

-- DEPRECATE
DROP INDEX IF EXISTS excesses.excess_coordinator_event_stakeholder_outbox_saga_status;

CREATE INDEX "excess_coordinator_event_stakeholder_outbox_saga_status"
    ON "excesses".excess_coordinator
        (event_source, event_target, outbox_status, saga_status);

DROP INDEX IF EXISTS excesses.excess_coordinator_created_at_event_stakeholder_outbox_saga_sta;

CREATE INDEX excess_coordinator_created_at_event_stakeholder_outbox_saga_sta
    ON excesses.excess_coordinator
        (created_at, event_source, event_target, outbox_status, saga_status);

DROP INDEX IF EXISTS excesses.excess_coordinator_event_stakeholder_saga_id_outbox_status;

CREATE INDEX excess_coordinator_event_stakeholder_saga_id_outbox_status
    ON "excesses".excess_coordinator
        (event_source, event_target, saga_id, saga_status);


DROP TABLE IF EXISTS excesses.excess_outbox;
CREATE TABLE excesses.excess_outbox
(
    outbox_id uuid NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    processed_at TIMESTAMP WITH TIME ZONE,
    event_source character varying COLLATE pg_catalog."default" NOT NULL,
    event_target character varying COLLATE pg_catalog."default" NOT NULL,
    message_id VARCHAR NOT NULL,
    payload jsonb NOT NULL,
    context jsonb NOT NULL,
    outbox_status outbox_status NOT NULL,
    version integer NOT NULL,
    CONSTRAINT excess_outbox_pkey PRIMARY KEY (outbox_id)
);

CREATE INDEX excess_outbox_event_stakeholder_status
    ON excesses.excess_outbox
        (event_source, event_target, outbox_status);

ALTER TABLE excesses.excesses_history
    ADD CONSTRAINT constraint_name
        FOREIGN KEY (excess_id)
            REFERENCES excesses.excesses (excess_id);
