package com.santander.scib.creame.filter.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.AggregateRoot;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class Filter extends AggregateRoot<FilterId> {

    private Rule rule;
    private ZonedDateTime createdAt;
    private FilterStatus filterStatus;
    private List<String> filtersMatching;

    public void initialize(){

        filterStatus = FilterStatus.PENDING;
        createdAt = ZonedDateTime.now(ZoneId.of("UTC"));
    }
    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void apply(Rule rule){
        setRule(rule);
        // HERE ALL FUNCTIONALITY OF APPLY THE RULES

        //this.filterStatus = FilterStatus.UNFILTERED;
        Random r = new Random();
        this.filterStatus = r.nextBoolean() ? FilterStatus.UNFILTERED : FilterStatus.FILTERED;
    }

    public void setRule(Rule rule) {
        this.rule = rule;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setFilterStatus(FilterStatus filterStatus) {
        this.filterStatus = filterStatus;
    }

    public void setFiltersMatching(List<String> filtersMatching) {
        this.filtersMatching = filtersMatching;
    }

    public Rule getRule() {
        return rule;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }

    public FilterStatus getFilterStatus() {
        return filterStatus;
    }

    public List<String> getFiltersMatching() {
        return filtersMatching;
    }

    private Filter(Builder builder) {
        super.setId(builder.filterId);
        rule = builder.rule;
        createdAt = builder.createdAt;
        filterStatus = builder.filterStatus;
        filtersMatching = builder.filtersMatching;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private FilterId filterId;
        private Rule rule;
        private ZonedDateTime createdAt;
        private FilterStatus filterStatus;

        private List<String> filtersMatching;

        private Builder() {
        }

        public Builder filterId(FilterId val) {
            filterId = val;
            return this;
        }

        public Builder rule(Rule val) {
            rule = val;
            return this;
        }

        public Builder createdAt(ZonedDateTime val) {
            createdAt = val;
            return this;
        }

        public Builder filterStatus(FilterStatus val) {
            filterStatus = val;
            return this;
        }

        public Builder filtersMatching(List<String> val) {
            filtersMatching = val;
            return this;
        }

        public Filter build() {
            return new Filter(this);
        }
    }
}
