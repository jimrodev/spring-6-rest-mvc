package com.santander.scib.creame.filter.service.adapters.dataaccess.exception;

public class FilterDataaccessException extends RuntimeException {

    public FilterDataaccessException(String message) {
        super(message);
    }
}
