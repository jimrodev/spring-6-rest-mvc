package com.santander.scib.creame.filter.service.domain.core;

import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import com.santander.scib.creame.filter.service.domain.core.entity.Rule;
import com.santander.scib.creame.filter.service.domain.core.event.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
public class FilterDomainServiceImpl implements FilterDomainService {
    @Override
    public FilterEvent apply(Filter filter, Rule rule) {

        filter.initialize();
        filter.apply(rule);
        log.info("Filter is applied for excess id: {}", filter.getId().getKey(0)); // Excess Id
        return switch (filter.getFilterStatus()){

            case FILTERED ->    new FilteredEvent(filter,
                                                //ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
                                                // SAME created at in (Filter and Coordinator)
                                                filter.getCreatedAt());
            case UNFILTERED ->  new UnfilteredEvent(filter,
                                                filter.getCreatedAt());
            case FAILED ->      new FailedEvent(filter,
                                                filter.getCreatedAt());
            case PENDING ->     new AlertEvent(filter,
                                                filter.getCreatedAt());
        };

    }
}
