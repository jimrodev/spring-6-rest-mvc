package com.santander.scib.creame.filter.service.domain.application.ports.input.service;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import jakarta.validation.Valid;
import org.springframework.transaction.annotation.Transactional;

public interface FilterApplicationService {

    FilterResponse apply(@Valid FilterRequest filterRequest, @Valid ContextMessage context);
}
