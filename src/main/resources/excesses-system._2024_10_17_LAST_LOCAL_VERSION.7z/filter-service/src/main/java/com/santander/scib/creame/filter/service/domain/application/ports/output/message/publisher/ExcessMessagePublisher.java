package com.santander.scib.creame.filter.service.domain.application.ports.output.message.publisher;

import com.santander.scib.creame.excesses.application.outbox.OutboxMessagePublisher;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;

public interface ExcessMessagePublisher extends OutboxMessagePublisher<CoordinatorMessage> {
}
