package com.santander.scib.creame.filter.service.adapters.dataaccess;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.filter.service.adapters.dataaccess.entity.FilterEntity;
import com.santander.scib.creame.filter.service.adapters.dataaccess.entity.FilterEntityId;
import com.santander.scib.creame.filter.service.adapters.dataaccess.mapper.FilterDataAccessMapper;
import com.santander.scib.creame.filter.service.adapters.dataaccess.repository.FilterJpaRepository;
import com.santander.scib.creame.filter.service.domain.application.ports.output.repository.FilterRepository;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class FilterRepositoryImpl implements FilterRepository {

    private final FilterJpaRepository filterJpaRepository;
    private final FilterDataAccessMapper filterDataAccessMapper;

    public FilterRepositoryImpl(FilterJpaRepository filterJpaRepository,
                                FilterDataAccessMapper filterDataAccessMapper) {
        this.filterJpaRepository = filterJpaRepository;
        this.filterDataAccessMapper = filterDataAccessMapper;
    }

    @Override
    public Filter save(Filter filter) {
        FilterEntity filterEntity = filterDataAccessMapper.filterToFilterEntity(filter);
        filterEntity.setNew(true);
        return filterDataAccessMapper.filterEntityToFilter(filterJpaRepository
                .save(filterEntity));
    }

    @Override
    public Filter update(Filter filter) {
        FilterEntity filterEntity = filterDataAccessMapper.filterToFilterEntity(filter);
        filterEntity.setNew(false);
        return filterDataAccessMapper.filterEntityToFilter(filterJpaRepository
                .save(filterEntity));
    }

    @Override
    public Optional<Filter> findByExcessIdAndProcessTimestamp(ExcessId excessId, String processTimestamp) {

        FilterEntityId filterEntityId = FilterEntityId.builder()
                .excessId(excessId.getValue())
                .processTimestamp(processTimestamp)
                .build();

        return filterJpaRepository.findById(filterEntityId)
                .map(filterDataAccessMapper::filterEntityToFilter);
    }
}
