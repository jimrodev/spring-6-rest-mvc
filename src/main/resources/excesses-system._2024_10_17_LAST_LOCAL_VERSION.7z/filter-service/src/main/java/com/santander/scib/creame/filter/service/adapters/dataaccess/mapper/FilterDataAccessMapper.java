package com.santander.scib.creame.filter.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;
import com.santander.scib.creame.filter.service.adapters.dataaccess.entity.FilterEntity;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class FilterDataAccessMapper {

    public FilterEntity filterToFilterEntity(Filter filter){
        return FilterEntity.builder()
                .excessId(filter.getId().getKey(0))             // Excess Id
                .processTimestamp(filter.getId().getKey(1))     // Process Timestamp
                .createdAt(filter.getCreatedAt())
                .filterStatus(filter.getFilterStatus())
                .filtersMatching(filter.getFiltersMatching())
                .build();
    }

    public Filter filterEntityToFilter(FilterEntity filterEntity){
        return Filter.builder()
                .filterId(new FilterId(filterEntity.getExcessId(), filterEntity.getProcessTimestamp()))
                .createdAt(filterEntity.getCreatedAt())
                .filterStatus(filterEntity.getFilterStatus())
                .filtersMatching(filterEntity.getFiltersMatching())
                .build();
    }
}
