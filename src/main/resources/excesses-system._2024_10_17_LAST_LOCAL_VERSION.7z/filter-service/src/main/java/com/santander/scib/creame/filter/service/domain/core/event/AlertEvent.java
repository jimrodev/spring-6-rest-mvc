package com.santander.scib.creame.filter.service.domain.core.event;

import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.time.ZonedDateTime;

public class AlertEvent extends FilterEvent{
    public AlertEvent(Filter filter,
                      ZonedDateTime createdAt) {
        super(filter, createdAt);
    }
}
