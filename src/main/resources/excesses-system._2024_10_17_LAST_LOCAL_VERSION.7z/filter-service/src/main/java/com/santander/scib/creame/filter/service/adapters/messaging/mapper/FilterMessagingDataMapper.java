package com.santander.scib.creame.filter.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.FilterRequestAvroModel;
import com.santander.scib.creame.avro.models.FilterResponseAvroModel;
import com.santander.scib.creame.avro.models.FilterStatus;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
public class FilterMessagingDataMapper {

    public FilterRequest filterRequestAvroModelToFilterRequest(FilterRequestAvroModel filterRequestAvroModel){
        return FilterRequest.builder()
                .excessId(filterRequestAvroModel.getExcessId())
                .processTimestamp(filterRequestAvroModel.getProcessTimestamp())
                .build();
    }

    public FilterResponseAvroModel filterResponseToFilterResponseAvroModel(FilterResponse filterResponse){
        return FilterResponseAvroModel.newBuilder()
                .setFilterId(UUID.randomUUID().toString())          /**/ //QUITAR
                .setExcessId(filterResponse.getExcessId())
                .setProcessTimestamp(filterResponse.getProcessTimestamp())
                .setFilterStatus(FilterStatus.valueOf(filterResponse.getFilterStatus().toString()))
                .setFiltersMatching(filterResponse.getFiltersMatching())
                .build();
    }
}
