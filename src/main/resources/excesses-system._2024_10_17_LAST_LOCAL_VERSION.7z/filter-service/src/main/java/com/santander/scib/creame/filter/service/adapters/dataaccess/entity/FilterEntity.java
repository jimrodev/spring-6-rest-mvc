package com.santander.scib.creame.filter.service.adapters.dataaccess.entity;

import com.google.common.base.Objects;
import com.santander.scib.creame.excesses.application.converter.ListConverter;
import com.santander.scib.creame.excesses.domain.valueobject.*;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "filters")
@Entity
@IdClass(FilterEntityId.class)
public class FilterEntity  implements Persistable<FilterEntityId> {

    @Id
    private String excessId;
    @Id
    private String processTimestamp;
    private ZonedDateTime createdAt;
    @Enumerated(EnumType.STRING)
    private FilterStatus filterStatus;
    @Convert(converter = ListConverter.class)
    private List<String> filtersMatching;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FilterEntity that = (FilterEntity) o;
        return Objects.equal(excessId, that.excessId) && Objects.equal(processTimestamp, that.processTimestamp);
    }

    @Override
    public int hashCode() {return Objects.hashCode(excessId, processTimestamp);
    }

    @Override
    public FilterEntityId getId() {return FilterEntityId.builder()
            .excessId(this.excessId)
            .processTimestamp(this.processTimestamp)
            .build();}

    @Override
    public boolean isNew() {return this.isNew;}
}
