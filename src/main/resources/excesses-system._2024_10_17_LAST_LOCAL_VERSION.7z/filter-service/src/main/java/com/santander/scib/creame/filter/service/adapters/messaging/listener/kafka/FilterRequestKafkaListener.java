package com.santander.scib.creame.filter.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.FilterRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaContextHelper;
import com.santander.scib.creame.filter.service.adapters.messaging.mapper.FilterMessagingDataMapper;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.ports.input.message.listener.FilterRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Component
public class FilterRequestKafkaListener implements KafkaConsumer<FilterRequestAvroModel> {

    private final FilterRequestMessageListener filterRequestMessageListener;

    private final FilterMessagingDataMapper filterMessagingDataMapper;

    public FilterRequestKafkaListener(FilterRequestMessageListener filterRequestMessageListener,
                                      FilterMessagingDataMapper filterMessagingDataMapper) {
        this.filterRequestMessageListener = filterRequestMessageListener;
        this.filterMessagingDataMapper = filterMessagingDataMapper;
    }

    @Override
    @KafkaListener(
            id = "filter-listener",
            topics = "#{@kafkaTopics['filter-request']}",
            containerFactory = "#{@kafkaListenerContainerFactories['filter']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<FilterRequestAvroModel>> messages) {
        List<Message<FilterRequestAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.parallelStream().forEach(filterRequestAvroModelMessage -> {
            try {
                // Load Message context (Kafka custom headers)
                ContextMessage context = KafkaContextHelper.getContextMessage(filterRequestAvroModelMessage.getHeaders());
                ContextHelper.clean(context, ContextHelper.ContextSection.TRANSPORT);

                // Message Type
                context.setMessageType(FilterRequest.class.getTypeName());
                // Inbound transport properties
                context.setInboundTransportType("kafka://");
                context.setInboundTransportLocation("filter-request");

                filterRequestMessageListener.apply(
                        filterMessagingDataMapper.filterRequestAvroModelToFilterRequest(
                                filterRequestAvroModelMessage.getPayload()),
                        context);

            }catch (DataIntegrityViolationException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught data integration exception in FilterRequestKafkaListener for excess id: {} and message: {}",
                        filterRequestAvroModelMessage.getPayload().getExcessId(),
                        e.getMessage());

            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in FilterRequestKafkaListener for excess id: {} and message: {}",
                        filterRequestAvroModelMessage.getPayload().getExcessId(),
                        e.getMessage());
            }
        });
    }
}