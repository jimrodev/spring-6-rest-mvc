package com.santander.scib.creame.filter.service.domain.application.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterId;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import org.springframework.stereotype.Component;

@Component
public class FilterDataMapper {

    public Filter filterRequestToFilter(FilterRequest filterRequest){
        return Filter.builder()
                .filterId(new FilterId(filterRequest.getExcessId(), filterRequest.getProcessTimestamp()))
                .build();
    }

    public FilterResponse FilterToFilterResponse(Filter filter) {
        return FilterResponse.builder()
                .excessId(filter.getId().getKey(0))         // Excess Id
                .processTimestamp(filter.getId().getKey(1)) // Process timestamp
                .filterStatus(filter.getFilterStatus())
                .filtersMatching(filter.getFiltersMatching())
                .build();
    }
}
