DROP TYPE IF EXISTS filter_status;
CREATE TYPE filter_status AS ENUM ('PENDING', 'FILTERED',  'UNFILTERED', 'FAILED');

DROP TABLE IF EXISTS excesses.filters;
CREATE TABLE excesses.filters
(
    excess_id VARCHAR NOT NULL,
    process_timestamp VARCHAR NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    filter_status filter_status NOT NULL,
    filters_matching jsonb,
    CONSTRAINT filter_pkey PRIMARY KEY (excess_id, process_timestamp)
);

CREATE INDEX filter_excess_process_timestamp
    ON "excesses".filters
        (excess_id, process_timestamp);