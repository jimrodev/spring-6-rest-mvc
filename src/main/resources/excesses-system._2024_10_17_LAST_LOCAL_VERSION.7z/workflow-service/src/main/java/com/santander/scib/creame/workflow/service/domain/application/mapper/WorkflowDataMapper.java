package com.santander.scib.creame.workflow.service.domain.application.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowId;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import org.springframework.stereotype.Component;

@Component
public class WorkflowDataMapper {

    public Workflow workflowRequestToWorkflow(WorkflowRequest workflowRequest){
        return Workflow.builder()
                .workflowId(new WorkflowId(workflowRequest.getExcessId(), workflowRequest.getProcessTimestamp()))
                .build();
    }

    public WorkflowResponse workflowToWorkflowResponse(Workflow workflow) {
        return WorkflowResponse.builder()
                .excessId(workflow.getId().getKey(0))
                .processTimestamp(workflow.getId().getKey(1))
                .workflowStatus(workflow.getWorkflowStatus())
                .assignedGroup(workflow.getAssignedGroup())
                .build();
    }
}
