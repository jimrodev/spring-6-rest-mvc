package com.santander.scib.creame.workflow.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowId;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntity;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import org.springframework.stereotype.Component;

@Component
public class WorkflowDataAccessMapper {

    public WorkflowEntity workflowToWorkflowEntity(Workflow workflow){
        return WorkflowEntity.builder()
                .excessId(workflow.getId().getKey(0))
                .processTimestamp(workflow.getId().getKey(1))
                .createdAt(workflow.getCreatedAt())
                .workflowStatus(workflow.getWorkflowStatus())
                .assignedGroup(workflow.getAssignedGroup())
                .build();
    }

    public Workflow workflowEntityToWorkflow(WorkflowEntity workflowEntity){
        return Workflow.builder()
                .workflowId(new WorkflowId(workflowEntity.getExcessId(), workflowEntity.getProcessTimestamp()))
                .createdAt(workflowEntity.getCreatedAt())
                .workflowStatus(workflowEntity.getWorkflowStatus())
                .assignedGroup(workflowEntity.getAssignedGroup())
                .build();
    }
}
