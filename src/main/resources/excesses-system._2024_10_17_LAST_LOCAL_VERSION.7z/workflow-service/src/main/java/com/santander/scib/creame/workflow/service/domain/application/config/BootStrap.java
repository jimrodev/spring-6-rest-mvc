package com.santander.scib.creame.workflow.service.domain.application.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.workflow.service.domain.application.dto.Condition;
import com.santander.scib.creame.workflow.service.domain.application.dto.Result;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowManagement;
import com.santander.scib.creame.workflow.service.domain.application.dto.Rule;
import lombok.AllArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@AllArgsConstructor
public class BootStrap implements CommandLineRunner {

    private final ObjectMapper objectMapper;

    private static String body = "{\n" +
            "  \"scope\": \"ExcessDetail\",\n" +
            "  \"description\": \"Workflow Management rules\",\n" +
            "  \"version\": \"1.0\",\n" +
            "  \"rules\": [\n" +
            "    {\n" +
            "      \"condition\": {\n" +
            "        \"field\": \"workflowStatus\",\n" +
            "        \"operator\": \"EQUALS\",\n" +
            "        \"values\": [\"PTE_CLASIFICACION\"]\n" +
            "      },\n" +
            "      \"result\": {\n" +
            "        \"workflowStatus\": [\"CLASIFICADO\"],\n" +
            "        \"assignedGropus\": [\"Admision\"]\n" +
            "      }\n" +
            "    },\n" +
            "    {\n" +
            "      \"condition\": {\n" +
            "        \"field\": \"workflowStatus\",\n" +
            "        \"operator\": \"EQUALS\",\n" +
            "        \"values\": [\"CLASIFICADO\"]\n" +
            "      },\n" +
            "      \"result\": {\n" +
            "        \"workflowStatus\": [\"PTE_PLAN\",\"SEGUIMIENTO_PLAN\"],\n" +
            "        \"assignedGropus\": [\"Front Office\"]\n" +
            "      }\n" +
            "    },\n" +
            "    {\n" +
            "      \"condition\": {\n" +
            "        \"field\": \"workflowStatus\",\n" +
            "        \"operator\": \"IN\",\n" +
            "        \"values\": [\"PTE_PLAN\",\"SEGUIMIENTO_PLAN\"]\n" +
            "      },\n" +
            "      \"result\": {\n" +
            "        \"workflowStatus\": [\"CLASIFICADO\"],\n" +
            "        \"assignedGropus\": [\"GlobalController\"]\n" +
            "      }\n" +
            "    }\n" +
            "  ]\n" +
            "}";

    @Override
    public void run(String... args) throws Exception {

        WorkflowManagement workflowManagement = objectMapper.readValue(body, WorkflowManagement.class);

        Map<String, String> parameters = new HashMap<>();
        parameters.put("workflowStatus", "CLASIFICADO");

        Result resultApply = workflowManagement.apply(parameters);

    }
}
