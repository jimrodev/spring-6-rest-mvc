package com.santander.scib.creame.workflow.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.AggregateRoot;
import com.santander.scib.creame.excesses.domain.valueobject.*;

import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Workflow extends AggregateRoot<WorkflowId> {

    private ZonedDateTime createdAt;
    private WorkflowStatus workflowStatus;
    private WorkflowGroup assignedGroup;

    public void initialize(){

        workflowStatus = WorkflowStatus.PENDING;
        createdAt = ZonedDateTime.now(ZoneId.of("UTC"));
    }

    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void assignGroup(WorkflowGroup assignedGroup){
        this.assignedGroup = assignedGroup;

        // HERE ALL FUNCTIONALITY OF ASSIGN GROUP
        this.workflowStatus = WorkflowStatus.ASSIGNED;
    }

    public void setCreatedAt(ZonedDateTime createdAt) {this.createdAt = createdAt;}

    public void setWorkflowStatus(WorkflowStatus workflowStatus) {this.workflowStatus = workflowStatus;}

    public void setAssignedGroup(WorkflowGroup assignedGroup) {this.assignedGroup = assignedGroup;}

    public ZonedDateTime getCreatedAt() { return createdAt;}

    public WorkflowStatus getWorkflowStatus() {return workflowStatus;}

    public WorkflowGroup getAssignedGroup() {return assignedGroup;}

    private Workflow(Builder builder) {
        super.setId(builder.workflowId);
        createdAt = builder.createdAt;
        workflowStatus = builder.workflowStatus;
        assignedGroup = builder.assignedGroup;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private WorkflowId workflowId;
        private ZonedDateTime createdAt;
        private WorkflowStatus workflowStatus;
        private WorkflowGroup assignedGroup;

        private Builder() {
        }
        public Builder workflowId(WorkflowId val) {
            workflowId = val;
            return this;
        }

        public Builder createdAt(ZonedDateTime val) {
            createdAt = val;
            return this;
        }

        public Builder workflowStatus(WorkflowStatus val) {
            workflowStatus = val;
            return this;
        }

        public Builder assignedGroup(WorkflowGroup val) {
            assignedGroup = val;
            return this;
        }

        public Workflow build() {
            return new Workflow(this);
        }
    }
}
