package com.santander.scib.creame.workflow.service.domain.core;

import com.santander.scib.creame.excesses.domain.valueobject.WorkflowGroup;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import com.santander.scib.creame.workflow.service.domain.core.event.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WorkflowDomainServiceImpl implements WorkflowDomainService {
    @Override
    public WorkflowEvent assign(Workflow workflow, WorkflowGroup assignedGroup){

        workflow.initialize();
        workflow.assignGroup(assignedGroup);

        log.info("Group {} is assigned for excess id: {}",
                assignedGroup,
                workflow.getId().getKey(0));

        return switch (workflow.getWorkflowStatus()){

            case ASSIGNED ->    new AssignedEvent(workflow,
                                                //ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
                                                workflow.getCreatedAt());
            case FAILED ->      new FailedEvent(workflow,
                                                workflow.getCreatedAt());
            case PENDING ->     new AlertEvent(workflow,
                                                workflow.getCreatedAt());
        };

    }
}
