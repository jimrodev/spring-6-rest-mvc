package com.santander.scib.creame.workflow.service.adapters.dataaccess.repository;

import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntity;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface WorkflowJpaRepository extends JpaRepository<WorkflowEntity, WorkflowEntityId> {

}
