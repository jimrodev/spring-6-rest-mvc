package com.santander.scib.creame.workflow.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.WorkflowRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaContextHelper;
import com.santander.scib.creame.workflow.service.adapters.messaging.mapper.WorkflowMessagingDataMapper;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.ports.input.message.listener.WorkflowRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Component
public class WorkflowRequestKafkaListener implements KafkaConsumer<WorkflowRequestAvroModel> {

    private final WorkflowRequestMessageListener workflowRequestMessageListener;

    private final WorkflowMessagingDataMapper workflowMessagingDataMapper;

    public WorkflowRequestKafkaListener(WorkflowRequestMessageListener workflowRequestMessageListener,
                                        WorkflowMessagingDataMapper workflowMessagingDataMapper) {
        this.workflowRequestMessageListener = workflowRequestMessageListener;
        this.workflowMessagingDataMapper = workflowMessagingDataMapper;
    }

    @Override
    @KafkaListener(
            id = "workflow-listener",
            topics = "#{@kafkaTopics['workflow-request']}",
            containerFactory = "#{@kafkaListenerContainerFactories['workflow']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<WorkflowRequestAvroModel>> messages) {
        List<Message<WorkflowRequestAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.parallelStream().forEach(workflowRequestAvroModelMessage -> {
            try {
                // Load Message context (Kafka custom headers)
                ContextMessage context = KafkaContextHelper.getContextMessage(workflowRequestAvroModelMessage.getHeaders());
                ContextHelper.clean(context, ContextHelper.ContextSection.TRANSPORT);

                // Message Type
                context.setMessageType(WorkflowRequest.class.getTypeName());
                // Inbound transport properties
                context.setInboundTransportType("kafka://");
                context.setInboundTransportLocation("workflow-request");

                workflowRequestMessageListener.assign(
                        workflowMessagingDataMapper.workflowRequestAvroModelToWorkflowRequest(
                                                    workflowRequestAvroModelMessage.getPayload()),
                        context);
            }catch (DataIntegrityViolationException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught data integration exception in WorkflowRequestKafkaListener for excess id: {} and message: {}",
                        workflowRequestAvroModelMessage.getPayload().getExcessId(),
                        e.getMessage());

            }catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in WorkflowRequestKafkaListener for excess id: {} and message: {}",
                        workflowRequestAvroModelMessage.getPayload().getExcessId(),
                        e.getMessage());
            }
        });
    }
}