package com.santander.scib.creame.workflow.service.adapters.dataaccess.entity;

import com.santander.scib.creame.excesses.domain.valueobject.*;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.time.ZonedDateTime;
import java.util.Objects;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "workflow")
@Entity
@IdClass(WorkflowEntityId.class)
public class WorkflowEntity implements Persistable<WorkflowEntityId> {

    @Id
    private String excessId;
    @Id
    private String processTimestamp;
    private ZonedDateTime createdAt;
    @Enumerated(EnumType.STRING)
    private WorkflowStatus workflowStatus;
    @Enumerated(EnumType.STRING)
    private WorkflowGroup assignedGroup;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorkflowEntity that = (WorkflowEntity) o;
        return excessId.equals(that.excessId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(excessId);
    }

    @Override
    public WorkflowEntityId getId() {return WorkflowEntityId.builder()
            .excessId(this.excessId)
            .processTimestamp(this.processTimestamp)
            .build();}

    @Override
    public boolean isNew() {return this.isNew;}
}
