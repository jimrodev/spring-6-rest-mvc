package com.santander.scib.creame.workflow.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class Condition{

    @JsonProperty
    private String field;
    @JsonProperty
    private String operator;
    @JsonProperty
    private List<String> values;
 }