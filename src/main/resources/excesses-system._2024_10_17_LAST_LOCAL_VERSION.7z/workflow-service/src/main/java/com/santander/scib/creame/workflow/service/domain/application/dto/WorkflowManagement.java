package com.santander.scib.creame.workflow.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class WorkflowManagement {

    @JsonProperty
    private String scope;
    @JsonProperty
    private String description;
    @JsonProperty
    private String version;

//  @JsonProperty
//  private HashMap<String, String> parameters = new HashMap();
    @JsonProperty
    private List<Rule> rules;

    public Result apply(Map<String, String> parameters) {
        
        AtomicReference<Result> result = new AtomicReference<>();
        this.rules.forEach(rule -> {
            switch (rule.getCondition().getOperator()){
                case "EQUALS":
                    if(parameters.get(rule.getCondition().getField()).equals(rule.getCondition().getValues().get(0))) {
                        result.set(rule.getResult());
                        return;
                    }
//                case "NOT_EQUALS":
//                    if(parameters.get(rule.getCondition().getField()).equals(rule.getCondition().getValues().get(0))) {
//                        result.set(rule.getResult());
//                        return;
//                    }
//                case "IN":
//                    result.set(null);
//                    return;
            }
        });
        return result.get();
    }
}
