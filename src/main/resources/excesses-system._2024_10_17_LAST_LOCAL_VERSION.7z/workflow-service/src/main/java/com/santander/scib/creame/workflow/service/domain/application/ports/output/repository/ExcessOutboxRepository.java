package com.santander.scib.creame.workflow.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepository;

public interface ExcessOutboxRepository extends CoordinatorRepository {
}
