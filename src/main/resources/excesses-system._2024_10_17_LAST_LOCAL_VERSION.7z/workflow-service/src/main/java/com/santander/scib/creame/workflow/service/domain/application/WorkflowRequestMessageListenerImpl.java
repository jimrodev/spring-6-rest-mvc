package com.santander.scib.creame.workflow.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.ports.input.message.listener.WorkflowRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class WorkflowRequestMessageListenerImpl implements WorkflowRequestMessageListener {

    private final WorkflowAssignHandler workflowAssignHandler;

    public WorkflowRequestMessageListenerImpl(WorkflowAssignHandler workflowAssignHandler) {
        this.workflowAssignHandler = workflowAssignHandler;
    }

    @Override
    public void assign(WorkflowRequest workflowRequest, ContextMessage context) {
        workflowAssignHandler.assign(workflowRequest, context);
    }
}
