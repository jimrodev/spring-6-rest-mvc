package com.santander.scib.creame.excesses.domain.valueobject;

import java.util.UUID;

public class FilterId extends CompositeId<String>{

    public FilterId(String key1, String key2) {
        super(key1, key2);
    }
}
