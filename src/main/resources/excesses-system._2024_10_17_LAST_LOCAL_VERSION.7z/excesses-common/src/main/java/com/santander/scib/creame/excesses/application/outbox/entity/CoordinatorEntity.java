package com.santander.scib.creame.excesses.application.outbox.entity;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.time.ZonedDateTime;
import java.util.Objects;
import java.util.UUID;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "excess_coordinator")
@Entity
public class CoordinatorEntity implements Persistable<String> {

    @Id
    private UUID outboxId;
    private UUID sagaId;
    private ZonedDateTime createdAt;
    private ZonedDateTime processedAt;
    private String eventSource;
    private String eventTarget;
    private String messageId;
    private String payload;
    private String context;
    @Enumerated(EnumType.STRING)
    private SagaStatus sagaStatus;
    @Enumerated(EnumType.STRING)
    private OutboxStatus outboxStatus;
    @Version
    private int version;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CoordinatorEntity that = (CoordinatorEntity) o;
        return outboxId.equals(that.outboxId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(outboxId);
    }

    @Override
    public String getId() {
        return this.outboxId.toString();
    }

    @Override
    public boolean isNew() {
        return this.isNew;
    }
}

