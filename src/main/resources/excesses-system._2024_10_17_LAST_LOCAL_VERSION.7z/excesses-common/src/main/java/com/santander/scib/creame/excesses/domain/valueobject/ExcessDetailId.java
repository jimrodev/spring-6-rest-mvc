package com.santander.scib.creame.excesses.domain.valueobject;

public class ExcessDetailId extends CompositeId<String>{
    public ExcessDetailId(String key1, String key2) {
        super(key1, key2);
    }
}
