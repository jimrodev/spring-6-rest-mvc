package com.santander.scib.creame.excesses.domain.valueobject;

public class WorkflowId extends CompositeId<String>{

    public WorkflowId(String key1, String key2) {
        super(key1, key2);
    }
}
