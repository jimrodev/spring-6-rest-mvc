package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.OutboxMessage;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;

public interface OutboxRepository {

    int insert(OutboxMessage outboxMessage);

    int update(OutboxMessage outboxMessage);

    OutboxMessage save(OutboxMessage outboxMessage);

    Optional<List<OutboxMessage>> findByOutboxStatus(Integer maxBatchSize,
                                                     OutboxStatus status);

    Optional<List<OutboxMessage>> findByCreatedAtAndOutboxStatus(Integer maxBatchSize,
                                                                 ZonedDateTime createdAt,
                                                                 OutboxStatus status);
    int deleteByOutboxStatus(OutboxStatus status);

    void flush();
}
