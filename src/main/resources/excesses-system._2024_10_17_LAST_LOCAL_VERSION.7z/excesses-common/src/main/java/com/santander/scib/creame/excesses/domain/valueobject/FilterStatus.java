package com.santander.scib.creame.excesses.domain.valueobject;

public enum FilterStatus {

    PENDING(0), FILTERED(1), UNFILTERED(2), FAILED(3);

    private final Integer filterStatus;
    FilterStatus(Integer excessStatus){
        this.filterStatus = excessStatus;
    }
    public Integer getExcessStatus(){
        return filterStatus;
    }
}
