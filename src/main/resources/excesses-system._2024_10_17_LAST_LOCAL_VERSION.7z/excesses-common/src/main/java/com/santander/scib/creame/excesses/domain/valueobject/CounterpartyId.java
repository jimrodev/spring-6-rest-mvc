package com.santander.scib.creame.excesses.domain.valueobject;

public class CounterpartyId extends BaseId<String>{

    public CounterpartyId(String value) {
        super(value);
    }
}
