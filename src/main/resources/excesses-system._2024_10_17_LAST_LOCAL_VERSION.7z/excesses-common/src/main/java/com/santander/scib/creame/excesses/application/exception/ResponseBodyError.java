package com.santander.scib.creame.excesses.application.exception;

import lombok.*;

import java.time.ZonedDateTime;

@Data
@Builder
@AllArgsConstructor
public class ResponseBodyError
{
    private ZonedDateTime timestamp;
    private Integer status;
    private String error;
    private String message;
    private String path;
};
