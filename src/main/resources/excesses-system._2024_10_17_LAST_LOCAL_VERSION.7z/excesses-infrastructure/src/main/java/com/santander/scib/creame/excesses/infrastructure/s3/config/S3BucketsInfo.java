package com.santander.scib.creame.excesses.infrastructure.s3.config;

import lombok.Data;

import java.util.Map;

/**
 * Configuration data for S3 buckets.
 */
@Data
public class S3BucketsInfo {

    @SuppressWarnings("java:S1068")
    private String name;

    @SuppressWarnings("java:S1068")
    private Map<String, String> locations;

}
