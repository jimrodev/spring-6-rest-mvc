package com.santander.scib.creame.excesses.infrastructure.s3.config;

import lombok.Data;

/**
 * Configuration data for S3.
 * This class holds the region, service endpoint, and credentials for an S3 service.
 */
@Data
public class S3ConfigData {

    @SuppressWarnings("java:S1068")
    private String region;

    @SuppressWarnings("java:S1068")
    private String serviceEndpoint;

    @SuppressWarnings("java:S1068")
    private Credentials credentials;


    /**
     * AWS S3 credentials.
     * This class holds the access key ID and secret access key for an AWS S3 service.
     */
    @Data
    public static class Credentials {

        @SuppressWarnings("java:S1068")
        private String accessKeyId;

        @SuppressWarnings("java:S1068")
        private String secretAccessKey;

    }

}
