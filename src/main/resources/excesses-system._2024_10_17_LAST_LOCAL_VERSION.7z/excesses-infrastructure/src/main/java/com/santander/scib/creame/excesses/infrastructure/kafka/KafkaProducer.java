package com.santander.scib.creame.excesses.infrastructure.kafka;

import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;

import java.util.function.BiConsumer;

/**
 * Interface for Kafka producers.
 * This interface provides a method for sending messages to Kafka.
 *
 * @param <V> the type of the message value
 */
public interface KafkaProducer<K, V> {

    /**
     * Sends a message to Kafka.
     *
     * @param message the message to be sent to Kafka
     */
    void send(Message<V> message);

    /**
     * Sends a message to Kafka.
     *
     * @param message the message to be sent to Kafka
     * @param callback the callback function called to handle shipping result
     */
    void send(Message<V> message,  BiConsumer<SendResult<K, V>, Throwable> callback);

    void flush();
}
