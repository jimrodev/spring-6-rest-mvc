package com.santander.scib.excesses.service.domain.core.event;

import com.santander.scib.excesses.domain.event.DomainEvent;
import com.santander.scib.excesses.service.domain.core.entity.Excess;

import java.time.ZonedDateTime;

public abstract class ExcessEvent implements DomainEvent<Excess> {
    private final Excess excess;
    private final ZonedDateTime createdAt;

    public ExcessEvent(Excess excess, ZonedDateTime createdAt) {
        this.excess = excess;
        this.createdAt = createdAt;
    }

    public Excess getExcess() {
        return excess;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }
}
