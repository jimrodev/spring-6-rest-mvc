package com.santander.scib.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.excesses.service.domain.application.dto.PartitionRequest;

public interface PartitionRequestMessageListener {
    void process(PartitionRequest partitionRequest);
}
