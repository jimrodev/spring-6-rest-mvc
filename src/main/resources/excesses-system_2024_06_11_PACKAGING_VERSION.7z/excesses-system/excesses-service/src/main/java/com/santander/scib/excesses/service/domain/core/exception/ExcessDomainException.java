package com.santander.scib.excesses.service.domain.core.exception;

import com.santander.scib.excesses.domain.exception.DomainException;

public class ExcessDomainException extends DomainException {

    public ExcessDomainException(String message) {
        super(message);
    }

    public ExcessDomainException(String message, Throwable cause) {
        super(message, cause);
    }
}
