package com.santander.scib.excesses.service.domain.application.ports.output.repository;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.domain.core.entity.Partition;

import java.util.Optional;

public interface PartitionRepository {

    Partition save(Partition partition);
    Optional<Partition> findByPartitionId(PartitionId partitionId);
}
