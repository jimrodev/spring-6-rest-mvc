package com.santander.scib.excesses.service.domain.core.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionProcessEvent extends PartitionEvent {

    private final DomainEventPublisher<PartitionEvent> partitionEventPublisher;

    public PartitionProcessEvent(Partition partition,
                                 ZonedDateTime createdAt,
                                 DomainEventPublisher<PartitionEvent> partitionEventPublisher) {
        super(partition, createdAt);
        this.partitionEventPublisher = partitionEventPublisher;
    }

    @Override
    public void fire() {
        partitionEventPublisher.publish(this);
    }
}
