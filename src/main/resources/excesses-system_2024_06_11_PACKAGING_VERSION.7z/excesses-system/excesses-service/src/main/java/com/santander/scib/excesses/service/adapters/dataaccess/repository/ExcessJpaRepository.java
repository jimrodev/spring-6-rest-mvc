package com.santander.scib.excesses.service.adapters.dataaccess.repository;

import com.santander.scib.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
@Repository
public interface ExcessJpaRepository  extends JpaRepository<ExcessEntity, String> {
}
