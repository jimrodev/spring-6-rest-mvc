package com.santander.scib.excesses.service.adapters.dataaccess.entity;

import com.google.common.base.Objects;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;
import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "excesses_history")
@Entity
@IdClass(ExcessHistoryEntityId.class)
public class ExcessHistoryEntity {

    @Id
    private String excessId;
    @Id
    private String processTimestamp;
    private String period;
    private String limitCurrency;
    private BigDecimal limitAmount;
    private BigDecimal used;
    private String excessReason;


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExcessHistoryEntity that = (ExcessHistoryEntity) o;
        return Objects.equal(excessId, that.excessId) && Objects.equal(processTimestamp, that.processTimestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(excessId, processTimestamp);
    }
}
