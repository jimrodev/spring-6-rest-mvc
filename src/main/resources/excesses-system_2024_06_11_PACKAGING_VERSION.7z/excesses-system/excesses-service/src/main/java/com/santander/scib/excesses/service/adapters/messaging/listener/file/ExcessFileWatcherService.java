package com.santander.scib.excesses.service.adapters.messaging.listener.file;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.HeaderColumnNameMappingStrategy;
import com.santander.scib.excesses.file.watcher.FileWatcherService;
import com.santander.scib.excesses.file.watcher.config.FileWatcherProperties;
import com.santander.scib.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.application.ports.input.service.ExcessApplicationService;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.util.Pair;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.WatchService;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ExcessFileWatcherService extends FileWatcherService
{
    private final ExcessApplicationService excessApplicationService;
    private final LocalValidatorFactoryBean validatorFactoryBean;

    public ExcessFileWatcherService(WatchService watchService,
                                    @Qualifier("AsyncTaskExecutor") Executor asyncTaskExecutor,
                                    FileWatcherProperties fileWatcherProperties,
                                    ExcessApplicationService excessApplicationService,
                                    LocalValidatorFactoryBean validatorFactoryBean) {
        super(watchService, asyncTaskExecutor, fileWatcherProperties);
        this.excessApplicationService = excessApplicationService;
        this.validatorFactoryBean = validatorFactoryBean;
    }

    @Async
    @Override
    public void processFile(Path fullPath, FileWatcherProperties fileWatcherProperties) {

        boolean processFile = false;
        Integer retry = 0;

        do{
            retry++;
            if(!retry.equals(1)){
                try{
                    TimeUnit.MILLISECONDS.sleep(fileWatcherProperties.retryInterval());
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }

            try {
                File file = new File(String.valueOf(fullPath));

                Set<ExcessRequest> excesses = parseCsv(file);

                if (validateSet(excesses)) {
                    processFile = true;
                    excesses.forEach(excessApplicationService::processExcess);
                }

            // QUE HACEMOS SI EL FICHERO ESTÁ MAL
            }catch (Exception e)
            {
                log.error("Error while processing the file {}, error message: {} ", fullPath, e.getMessage());
            }
        }while(!processFile && retry < fileWatcherProperties.retryCount());
    }

    private Set<ExcessRequest> parseCsv(File file) throws IOException {
        try(Reader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)))) {
            HeaderColumnNameMappingStrategy<ExcessRequest> strategy =
                    new HeaderColumnNameMappingStrategy<>();
            strategy.setType(ExcessRequest.class);
            CsvToBean<ExcessRequest> csvToBean =
                    new CsvToBeanBuilder<ExcessRequest>(reader)
                            .withMappingStrategy(strategy)
                            .withIgnoreEmptyLine(true)
                            .withIgnoreLeadingWhiteSpace(true)
                            .build();

            return new HashSet<>(csvToBean.parse());
        }
    }

    public static <T> Consumer<T> withCounter(BiConsumer<Integer, T> consumer) {
        AtomicInteger counter = new AtomicInteger(0);
        return item -> consumer.accept(counter.getAndIncrement(), item);
    }

    private boolean validateSet(Set<ExcessRequest> excesses) {

        Validator validator =  validatorFactoryBean.getValidator();
        Map<String, Map<String, List<String>>> fileErrorList = new HashMap<>();

        Integer Row = 0;
        excesses.stream().forEach(withCounter((i, excess)->{

            Map<String, List<String>> rowErrorList = new HashMap<>();

            rowErrorList = validator.validate(excess).stream().map(fieldError->{
                return Pair.of(fieldError.getPropertyPath().toString(), fieldError.getMessage());
            }).collect(Collectors.groupingBy(Pair::getFirst, Collectors.mapping(Pair::getSecond, Collectors.toList())));

            if(!rowErrorList.isEmpty()) {
                fileErrorList.put("Row: " + i, rowErrorList);
            }
        }));

        System.out.println(Arrays.toString(List.of(fileErrorList).toArray()));

        return fileErrorList.isEmpty();
    }
}
