package com.santander.scib.excesses.service.domain.application.ports.output.message.publisher;


import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.event.ExcessCreatedEvent;

public interface ExcessCreatedMessagePublisher extends DomainEventPublisher<ExcessCreatedEvent> {

}
