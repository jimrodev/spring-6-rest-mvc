package com.santander.scib.excesses.service.adapters.api.exception;

import com.santander.scib.excesses.application.exception.ErrorDTO;
import com.santander.scib.excesses.application.exception.GlobalExceptionHandler;
import com.santander.scib.excesses.service.domain.core.exception.ExcessDomainException;
import com.santander.scib.excesses.service.domain.core.exception.ExcessNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Slf4j
@ControllerAdvice
public class ExcessGlobalExceptionHandler extends GlobalExceptionHandler {

    @ResponseBody
    @ExceptionHandler(value = {ExcessDomainException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorDTO handleException(ExcessDomainException excessDomainException) {
        log.error(excessDomainException.getMessage(), excessDomainException);
        return ErrorDTO.builder()
                .code(HttpStatus.BAD_REQUEST.getReasonPhrase())
                .message(excessDomainException.getMessage())
                .build();
    }

    @ResponseBody
    @ExceptionHandler(value = {ExcessNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorDTO handleException(ExcessNotFoundException excessNotFoundException) {
        log.error(excessNotFoundException.getMessage(), excessNotFoundException);
        return ErrorDTO.builder()
                .code(HttpStatus.NOT_FOUND.getReasonPhrase())
                .message(excessNotFoundException.getMessage())
                .build();
    }
}
