package com.santander.scib.excesses.service.adapters.messaging.mapper;

import com.santander.scib.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.excesses.domain.valueobject.ExcessType;
import com.santander.scib.excesses.domain.valueobject.MetricType;
import com.santander.scib.excesses.kafka.excess.avro.model.ExcessRequestAvroModel;
import com.santander.scib.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.core.entity.Excess;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import com.santander.scib.excesses.service.domain.core.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.core.event.PartitionEvent;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class ExcessMessagingDataMapper {
    public ExcessRequestAvroModel excessCreatedEventToExcessRequestAvroModel(ExcessCreatedEvent domainEvent) {
        Excess excess = domainEvent.getExcess();

        return ExcessRequestAvroModel.newBuilder()
                .setExcessId(excess.getId().getValue())
                .setLimitOrigin(excess.getLimitOrigin())
                .setLimitShortName(excess.getLimitShortName())
                .setMetricType(excess.getMetricType().toString())
                .setExcessMetric(excess.getExcessMetric().toString())
                .setPeriod(excess.getPeriod())
                .setLimitCurrency(excess.getLimitCurrency())
                .setLimitAmount(excess.getLimitAmount().toString())     // *
                .setUsed(excess.getUsed().toString())                   // *
                .setExcessReason(excess.getExcessReason())
                .setExcessBeginDate(excess.getExcessBeginDate())
                .setExcessBeginTimestamp(excess.getExcessBeginTimestamp())
                .setExcessEndDate(excess.getExcessEndDate())
                .setExcessEndTimestamp(excess.getExcessEndTimestamp())
                .setLimitInternalKey(excess.getLimitInternalKey())
                .setExcessType(excess.getExcessType().toString())
                .setExcessStatus(excess.getExcessStatus().toString())
                .build();
    }

    public ExcessRequest excessRequestAvroModelToExcessRequest(ExcessRequestAvroModel excessRequestAvroModel) {

        return ExcessRequest.builder()
                .excessId(excessRequestAvroModel.getExcessId())
                .limitOrigin(excessRequestAvroModel.getLimitOrigin())
                .limitShortName(excessRequestAvroModel.getLimitShortName())
                .metricType(MetricType.valueOf(excessRequestAvroModel.getMetricType()))
                .excessMetric(ExcessMetric.valueOf(excessRequestAvroModel.getExcessMetric()))
                .period(excessRequestAvroModel.getPeriod())
                .limitCurrency(excessRequestAvroModel.getLimitCurrency())
                .limitAmount(new BigDecimal(excessRequestAvroModel.getLimitAmount()))     // *
                .used(new BigDecimal(excessRequestAvroModel.getUsed()))                   // *
                .excessReason(excessRequestAvroModel.getExcessReason())
                .excessBeginDate(excessRequestAvroModel.getExcessBeginDate())
                .excessBeginTimestamp(excessRequestAvroModel.getExcessBeginTimestamp())
                .excessEndDate(excessRequestAvroModel.getExcessEndDate())
                .excessEndTimestamp(excessRequestAvroModel.getExcessEndTimestamp())
                .limitInternalKey(excessRequestAvroModel.getLimitInternalKey())
                .excessType(ExcessType.valueOf(excessRequestAvroModel.getExcessType()))
                .excessStatus(ExcessStatus.valueOf(excessRequestAvroModel.getExcessStatus()))
                .build();
    }

    public PartitionRequestAvroModel partitionProcessEventToPartitionRequestAvroModel(PartitionEvent domainEvent) {
        Partition partition = domainEvent.getPartition();

        return PartitionRequestAvroModel.newBuilder()
                .setPartitionId(partition.getId().getValue())
                .build();
    }

    public PartitionRequest partitionRequestAvroModelToPartitionRequest(PartitionRequestAvroModel partitionRequestAvroModel) {

        return PartitionRequest.builder()
                .partitionId(partitionRequestAvroModel.getPartitionId())
                .build();
    }
}