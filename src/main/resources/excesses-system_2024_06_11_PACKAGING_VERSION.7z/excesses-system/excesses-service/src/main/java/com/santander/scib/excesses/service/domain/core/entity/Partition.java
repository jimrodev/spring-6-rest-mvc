package com.santander.scib.excesses.service.domain.core.entity;

import com.santander.scib.excesses.domain.entity.BaseEntity;
import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.domain.valueobject.PartitionStatus;

public class Partition extends BaseEntity<PartitionId>{
    private PartitionStatus partitionStatus;

    private Partition(Builder builder) {
        super.setId(builder.partitionId);
        partitionStatus = builder.partitionStatus;
    }

    public PartitionStatus getPartitionStatus() {
        return partitionStatus;
    }
    public void initialize(){
        partitionStatus = PartitionStatus.PENDING;
    }

    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void process(){
        // HERE All FUNCTIONALITY OF PROCESS OPERATION
        validate();
    }

    public void complete(){
        // HERE All FUNCTIONALITY OF COMPLETE OPERATION
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private PartitionId partitionId;
        private PartitionStatus partitionStatus;

        private Builder() {
        }
        public Builder partitionId(PartitionId val) {
            partitionId = val;
            return this;
        }

        public Builder partitionStatus(PartitionStatus val) {
            partitionStatus = val;
            return this;
        }

        public Partition build() {
            return new Partition(this);
        }
    }
}
