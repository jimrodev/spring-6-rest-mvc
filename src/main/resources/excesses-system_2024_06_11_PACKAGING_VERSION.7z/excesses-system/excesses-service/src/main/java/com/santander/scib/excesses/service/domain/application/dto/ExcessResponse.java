package com.santander.scib.excesses.service.domain.application.dto;

import com.santander.scib.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.excesses.domain.valueobject.ExcessType;
import com.santander.scib.excesses.domain.valueobject.MetricType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;


// HE PUSTO LA MISMA SALIDA QUE LA ENTRADA PERO HABRÁ QUE VER QUE SE DEVUELVE EN CADA CASO
@Getter
@Builder
@AllArgsConstructor
public class ExcessResponse {
    @NotNull
    private String excessId;
    @NotNull
    private String limitOrigin;
    @NotNull
    private String limitShortName;
    @NotNull
    private MetricType metricType;
    @NotNull
    private ExcessMetric excessMetric;
    @NotNull
    private String period;
    @NotNull
    private String limitCurrency;
    @NotNull
    private BigDecimal limitAmount;
    @NotNull
    private BigDecimal used;
    @NotNull
    private String excessReason;
    @NotNull
    private String excessBeginDate;
    @NotNull
    private String excessBeginTimestamp;
    @NotNull
    private String excessEndDate;
    @Null
    private String excessEndTimestamp;
    @Null
    private String limitInternalKey;
    @Null
    private ExcessType excessType;
    @Null
    private ExcessStatus excessStatus;

    // VER FORMATO DE FECHAS
}