package com.santander.scib.excesses.service.adapters.dataaccess;

import com.santander.scib.excesses.service.adapters.dataaccess.mapper.ExcessDataAccessMapper;
import com.santander.scib.excesses.service.adapters.dataaccess.repository.ExcessJpaRepository;
import com.santander.scib.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.excesses.service.domain.core.entity.Excess;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
public class ExcessRepositoryImpl implements ExcessRepository {

    private final ExcessJpaRepository excessJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;

    public ExcessRepositoryImpl(ExcessJpaRepository customerJpaRepository,
                                ExcessDataAccessMapper customerDataAccessMapper) {
        this.excessJpaRepository = customerJpaRepository;
        this.excessDataAccessMapper = customerDataAccessMapper;
    }

    @Override
    public Excess save(Excess excess) {
        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessDataAccessMapper.excessToExcessEntity(excess)));
    }

    @Override
    public Excess update(Excess excess) {
        return excessDataAccessMapper.excessEntityToExcess(excessJpaRepository
                .save(excessDataAccessMapper.excessToExcessEntity(excess)));
    }
}
