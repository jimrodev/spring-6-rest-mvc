package com.santander.scib.excesses.service.domain.application.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "excess-service")
public class ExcessServiceConfigData {
    private String excessPublishTopicName;
    private String excessSubscribeTopicName;
    private String excessDailySnapshotTopicName;
}
