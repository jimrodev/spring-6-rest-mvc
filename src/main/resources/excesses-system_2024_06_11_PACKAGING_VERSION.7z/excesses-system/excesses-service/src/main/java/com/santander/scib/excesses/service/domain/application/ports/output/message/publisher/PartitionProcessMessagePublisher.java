package com.santander.scib.excesses.service.domain.application.ports.output.message.publisher;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.event.PartitionEvent;

public interface PartitionProcessMessagePublisher extends DomainEventPublisher<PartitionEvent> {
}
