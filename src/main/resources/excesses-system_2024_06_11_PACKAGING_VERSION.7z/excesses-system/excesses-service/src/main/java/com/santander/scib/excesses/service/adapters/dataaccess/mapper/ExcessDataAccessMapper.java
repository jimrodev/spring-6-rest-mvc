package com.santander.scib.excesses.service.adapters.dataaccess.mapper;

import com.santander.scib.excesses.domain.valueobject.ExcessId;
import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import com.santander.scib.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import com.santander.scib.excesses.service.domain.core.entity.Excess;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import org.springframework.stereotype.Component;

@Component
public class ExcessDataAccessMapper {

    public ExcessEntity excessToExcessEntity(Excess excess){
        return ExcessEntity.builder()
                .excessId(excess.getId().getValue())
                .limitOrigin(excess.getLimitOrigin())
                .limitShortName(excess.getLimitShortName())
                .metricType(excess.getMetricType())
                .excessMetric(excess.getExcessMetric())
                .period(excess.getPeriod())
                .limitCurrency(excess.getLimitCurrency())
                .limitAmount(excess.getLimitAmount())
                .used(excess.getUsed())
                .excessReason(excess.getExcessReason())
                .excessBeginDate(excess.getExcessBeginDate())
                .excessBeginTimestamp(excess.getExcessBeginTimestamp())
                .excessEndDate(excess.getExcessEndDate())
                .excessEndTimestamp(excess.getExcessEndTimestamp())
                .limitInternalKey(excess.getLimitInternalKey())
                .excessType(excess.getExcessType())
                .excessStatus(excess.getExcessStatus())
                .build();
    }

    public Excess excessEntityToExcess(ExcessEntity excessEntity){
        return Excess.builder()
                .excessId(new ExcessId(excessEntity.getExcessId()))
                .limitOrigin(excessEntity.getLimitOrigin())
                .limitShortName(excessEntity.getLimitShortName())
                .metricType(excessEntity.getMetricType())
                .excessMetric(excessEntity.getExcessMetric())
                .period(excessEntity.getPeriod())
                .limitCurrency(excessEntity.getLimitCurrency())
                .limitAmount(excessEntity.getLimitAmount())
                .used(excessEntity.getUsed())
                .excessReason(excessEntity.getExcessReason())
                .excessBeginDate(excessEntity.getExcessBeginDate())
                .excessBeginTimestamp(excessEntity.getExcessBeginTimestamp())
                .excessEndDate(excessEntity.getExcessEndDate())
                .excessEndTimestamp(excessEntity.getExcessEndTimestamp())
                .limitInternalKey(excessEntity.getLimitInternalKey())
                .excessType(excessEntity.getExcessType())
                .excessStatus(excessEntity.getExcessStatus())
                .build();
    }

    public PartitionEntity partitionToPartitionEntity(Partition partition) {
        return PartitionEntity.builder()
                .partitionId(partition.getId().getValue())
                .partitionStatus(partition.getPartitionStatus())
                .build();
    }

    public Partition partitionEntityToPartition(PartitionEntity partitionEntity) {
        return Partition.builder()
                .partitionId(new PartitionId(partitionEntity.getPartitionId()))
                .partitionStatus(partitionEntity.getPartitionStatus())
                .build();
    }
}
