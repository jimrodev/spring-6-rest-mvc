package com.santander.scib.excesses.service.domain.application.mapper;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.application.dto.PartitionResponse;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import org.springframework.stereotype.Component;

@Component
public class PartitionMapper {

    public Partition PartitionRequestToPartition(PartitionRequest partitionRequest) {

        return Partition.builder()
                .partitionId(new PartitionId(partitionRequest.getPartitionId()))
                .build();
    }

    public PartitionResponse PartitionToPartitionResponse(Partition partition) {

        return PartitionResponse.builder()
                .partitionId(partition.getId().getValue())
                .partitionStatus(partition.getPartitionStatus())
                .build();
    }
}
