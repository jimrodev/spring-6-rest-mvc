package com.santander.scib.excesses.service.domain.core;


import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import com.santander.scib.excesses.service.domain.core.event.PartitionEvent;

public interface PartitionDomainService {

    PartitionEvent process(Partition partition, DomainEventPublisher<PartitionEvent> partitionDomainEventPublisher);

}
