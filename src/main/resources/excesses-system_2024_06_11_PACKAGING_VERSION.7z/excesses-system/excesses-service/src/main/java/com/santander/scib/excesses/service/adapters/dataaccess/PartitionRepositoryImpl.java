package com.santander.scib.excesses.service.adapters.dataaccess;

import com.santander.scib.excesses.domain.valueobject.PartitionId;
import com.santander.scib.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import com.santander.scib.excesses.service.adapters.dataaccess.mapper.ExcessDataAccessMapper;
import com.santander.scib.excesses.service.adapters.dataaccess.repository.PartitionJpaRepository;
import com.santander.scib.excesses.service.domain.application.ports.output.repository.PartitionRepository;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class PartitionRepositoryImpl implements PartitionRepository {

    private final PartitionJpaRepository partitionJpaRepository;
    private final ExcessDataAccessMapper excessDataAccessMapper;

    public PartitionRepositoryImpl(PartitionJpaRepository partitionJpaRepository,
                                   ExcessDataAccessMapper excessDataAccessMapper) {
        this.partitionJpaRepository = partitionJpaRepository;
        this.excessDataAccessMapper = excessDataAccessMapper;
    }

    @Override
    public Partition save(Partition partition) {
        return excessDataAccessMapper.partitionEntityToPartition(partitionJpaRepository
                .save(excessDataAccessMapper.partitionToPartitionEntity(partition)));
    }

    @Override
    public Optional<Partition> findByPartitionId(PartitionId partitionId) {
        Optional<PartitionEntity> foundPartition = partitionJpaRepository
                                                    .findByPartitionId(partitionId.getValue());

        return foundPartition.map(excessDataAccessMapper::partitionEntityToPartition);
    }
}
