package com.santander.scib.excesses.service.domain.core;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.entity.Excess;
import com.santander.scib.excesses.service.domain.core.event.ExcessCreatedEvent;
import com.santander.scib.excesses.service.domain.core.event.ExcessResolvedEvent;
import com.santander.scib.excesses.service.domain.core.event.ExcessUpdatedEvent;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static com.santander.scib.excesses.domain.DomainConstants.UTC;

@Slf4j
public class ExcessDomainServiceImpl implements ExcessDomainService {

    @Override
    public ExcessCreatedEvent create(Excess excess,
                                     DomainEventPublisher<ExcessCreatedEvent> excessCreatedDomainEventPublisher) {
        excess.create();
        log.info("Excess with id: {} is created", excess.getId().getValue());
        return new ExcessCreatedEvent(excess,
                                    ZonedDateTime.now(ZoneId.of(UTC)),
                                    excessCreatedDomainEventPublisher);
    }

    @Override
    public ExcessUpdatedEvent update(Excess excess,
                                     DomainEventPublisher<ExcessUpdatedEvent> excessUpdatedDomainEventPublisher) {
        excess.update();
        log.info("Excess with id: {} is updated", excess.getId().getValue());
        return new ExcessUpdatedEvent(excess,
                                    ZonedDateTime.now(ZoneId.of(UTC)),
                                    excessUpdatedDomainEventPublisher);
    }

    @Override
    public ExcessResolvedEvent resolve(Excess excess,
                                       DomainEventPublisher<ExcessResolvedEvent> excessResolvedDomainEventPublisher) {
        excess.solve();
        log.info("Excess with id: {} is resolved", excess.getId().getValue());
        return new ExcessResolvedEvent(excess,
                ZonedDateTime.now(ZoneId.of(UTC)),
                excessResolvedDomainEventPublisher);
    }
}
