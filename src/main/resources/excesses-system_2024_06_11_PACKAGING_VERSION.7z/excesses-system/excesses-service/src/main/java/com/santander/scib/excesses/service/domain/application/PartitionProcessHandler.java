package com.santander.scib.excesses.service.domain.application;

import com.santander.scib.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.excesses.service.domain.application.dto.PartitionResponse;
import com.santander.scib.excesses.service.domain.application.mapper.PartitionMapper;
import com.santander.scib.excesses.service.domain.core.event.PartitionEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PartitionProcessHandler {

    private final PartitionProcessHelper partitionProcessHelper;
    private final PartitionMapper partitionMapper;

    public PartitionProcessHandler(PartitionProcessHelper partitionProcessHelper, PartitionMapper partitionMapper) {
        this.partitionProcessHelper = partitionProcessHelper;
        this.partitionMapper = partitionMapper;
    }

    PartitionResponse process(PartitionRequest partitionRequest){

        PartitionEvent partitionEvent = partitionProcessHelper.process(partitionRequest);
        log.info("Partition is processed with id: {}", partitionEvent.getPartition().getId().getValue());
        partitionEvent.fire();
        return partitionMapper.PartitionToPartitionResponse(partitionEvent.getPartition());
    }
}
