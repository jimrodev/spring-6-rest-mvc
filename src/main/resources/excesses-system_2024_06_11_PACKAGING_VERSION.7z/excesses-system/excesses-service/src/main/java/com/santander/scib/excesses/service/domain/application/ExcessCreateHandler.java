package com.santander.scib.excesses.service.domain.application;

import com.santander.scib.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.excesses.service.domain.application.mapper.ExcessMapper;
import com.santander.scib.excesses.service.domain.core.event.ExcessCreatedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class ExcessCreateHandler {
    private final ExcessCreateHelper excessCreateHelper;
    private final ExcessMapper excessMapper;

    public ExcessCreateHandler(ExcessCreateHelper excessCreateHelper,
                               ExcessMapper excessMapper) {
        this.excessCreateHelper = excessCreateHelper;
        this.excessMapper = excessMapper;
    }

    public ExcessResponse create(ExcessRequest excessRequest){
        ExcessCreatedEvent excessCreatedEvent = excessCreateHelper.persistExcess(excessRequest);
        log.info("Excess is created with id: {}", excessCreatedEvent.getExcess().getId().getValue());
        excessCreatedEvent.fire();
        return excessMapper.ExcessToExcessResponse(excessCreatedEvent.getExcess());
    }
}
