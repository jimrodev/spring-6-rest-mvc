package com.santander.scib.excesses.service.domain.core;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.entity.Partition;
import com.santander.scib.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.excesses.service.domain.core.event.PartitionProcessEvent;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import static com.santander.scib.excesses.domain.DomainConstants.UTC;

@Slf4j
public class PartitionDomainServiceImpl implements PartitionDomainService {
    @Override
    public PartitionEvent process(Partition partition, DomainEventPublisher<PartitionEvent> partitionDomainEventPublisher) {
        partition.initialize();
        partition.process();
        log.info("Partition with id: {} is processing", partition.getId().getValue());
        // ProcessEvent VS VoidEvent
        // Ahora estoy dejando el evento en el mismo tópico que dispara el procesamiento de la partición para
        // tener un producer
        // Cambiar a VOID para no generar nada o cambiar el tópico de destino para no generar un bucle
        return new PartitionProcessEvent(partition,
                     ZonedDateTime.now(ZoneId.of(UTC)),
                     partitionDomainEventPublisher);
//        return new PartitionVoidEvent(partition,
//                ZonedDateTime.now(ZoneId.of(UTC)));

    }
}
