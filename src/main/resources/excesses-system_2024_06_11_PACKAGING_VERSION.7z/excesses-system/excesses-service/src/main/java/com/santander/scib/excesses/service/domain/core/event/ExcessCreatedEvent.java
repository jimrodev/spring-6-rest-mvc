package com.santander.scib.excesses.service.domain.core.event;

import com.santander.scib.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.excesses.service.domain.core.entity.Excess;

import java.time.ZonedDateTime;

public class ExcessCreatedEvent extends ExcessEvent {

    private final DomainEventPublisher<ExcessCreatedEvent> excessCreatedDomainEventPublisher;

    public ExcessCreatedEvent(Excess excess,
                              ZonedDateTime createdAt,
                              DomainEventPublisher<ExcessCreatedEvent> excessCreatedDomainEventPublisher) {
        super(excess, createdAt);
        this.excessCreatedDomainEventPublisher = excessCreatedDomainEventPublisher;
    }

    @Override
    public void fire() {
        excessCreatedDomainEventPublisher.publish(this);
    }
}
