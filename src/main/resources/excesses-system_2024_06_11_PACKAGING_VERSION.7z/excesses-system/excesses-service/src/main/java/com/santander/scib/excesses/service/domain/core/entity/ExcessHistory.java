package com.santander.scib.excesses.service.domain.core.entity;

public class ExcessHistory {

}
