package com.santander.scib.excesses.file.watcher;

import com.santander.scib.excesses.file.watcher.config.FileWatcherProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.Executor;

@Slf4j
public abstract class FileWatcherService {

    private final WatchService watchService;
    private final Executor asyncTaskExecutor;
    private final FileWatcherProperties fileWatcherProperties;

    public FileWatcherService(WatchService watchService,
                              Executor asyncTaskExecutor,
                              FileWatcherProperties fileWatcherProperties) {
        this.watchService = watchService;
        this.asyncTaskExecutor = asyncTaskExecutor;
        this.fileWatcherProperties = fileWatcherProperties;
    }

    @PostConstruct
    private void init(){
        asyncTaskExecutor.execute(this::startMonitoring);
    }

    @Async
    public void startMonitoring() {
        log.info("Start file watcher");
        try {
            WatchKey key;
            while ((key = watchService.take()) != null) {
                for (WatchEvent<?> event : key.pollEvents()) {
                    log.debug("Event kind: {}; File affected: {}", event.kind(), event.context());

                    Path fullPath = ((Path)key.watchable()).resolve((Path)event.context());
                    processFile(fullPath, fileWatcherProperties);
                }
                key.reset();
            }
        } catch (InterruptedException e) {
            log.warn("interrupted exception for monitoring service");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    @PreDestroy
    public void stopMonitoring() {
        log.info("Stop file watcher");

        if (watchService != null) {
            try {
                watchService.close();
            } catch (IOException e) {
                log.error("exception while closing the monitoring service");
            }
        }
    }

    public abstract void processFile(Path fullPath, FileWatcherProperties fileWatcherProperties) throws IOException;
}


