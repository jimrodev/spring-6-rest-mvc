package com.santander.scib.excesses.domain.valueobject;

public enum SegmentActions {
    L, C
}
