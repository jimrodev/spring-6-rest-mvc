package com.santander.scib.excesses.domain;

public class DomainConstants {

    private DomainConstants() {
    }

    public static final String UTC = "UTC";
}
