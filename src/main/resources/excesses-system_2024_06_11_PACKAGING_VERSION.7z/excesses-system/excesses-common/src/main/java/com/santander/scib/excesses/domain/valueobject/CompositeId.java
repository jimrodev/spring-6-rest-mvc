package com.santander.scib.excesses.domain.valueobject;

import java.util.ArrayList;
import java.util.List;

public abstract class CompositeId <T>{
    private final List<T> keys = new ArrayList<>(2);

    protected CompositeId(T key1, T key2) {
        this.keys.set(0, key1);
        this.keys.set(1, key2);
    }

    public T getKey(Integer index){
        return this.keys.get(index);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CompositeId<?> that = (CompositeId<?>) o;

        return keys.equals(that.keys);
    }

    @Override
    public int hashCode() {
        return keys.hashCode();
    }
}

