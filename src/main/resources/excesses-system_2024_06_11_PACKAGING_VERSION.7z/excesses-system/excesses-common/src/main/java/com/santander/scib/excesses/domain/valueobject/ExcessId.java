package com.santander.scib.excesses.domain.valueobject;

public class ExcessId extends BaseId<String>{

    public ExcessId(String value) {
        super(value);
    }
}
