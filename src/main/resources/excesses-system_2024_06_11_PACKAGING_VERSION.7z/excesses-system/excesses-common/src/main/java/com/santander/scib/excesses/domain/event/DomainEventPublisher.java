package com.santander.scib.excesses.domain.event;

public interface DomainEventPublisher<T extends DomainEvent> {
    void publish(T domainEvent);
}
