package com.santander.scib.excesses.domain.valueobject;

import java.util.UUID;

public class InterchangeId extends BaseId<UUID>{{
}
    public InterchangeId(UUID value) {
        super(value);
    }
}