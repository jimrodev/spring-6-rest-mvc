package com.santander.scib.excesses.domain.valueobject;

public enum ExcessStatus {

    FILTERED(0), PENDING(1), ASSIGNED(2), RESOLVED(3), UNDER_REVIEW(4);

    private final Integer excessStatus;
    ExcessStatus(Integer excessStatus){
        this.excessStatus = excessStatus;
    }
    public Integer getExcessStatus(){
        return excessStatus;
    }
}
