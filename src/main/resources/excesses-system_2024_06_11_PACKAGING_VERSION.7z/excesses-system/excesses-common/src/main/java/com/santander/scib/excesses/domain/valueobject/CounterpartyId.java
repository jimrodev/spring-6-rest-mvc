package com.santander.scib.excesses.domain.valueobject;

public class CounterpartyId extends BaseId<String>{

    public CounterpartyId(String value) {
        super(value);
    }
}
