package com.santander.scib.excesses.domain.valueobject;

public class ExcessHistoryId extends CompositeId<String>{
    public ExcessHistoryId(String key1, String key2) {
        super(key1, key2);
    }
}
