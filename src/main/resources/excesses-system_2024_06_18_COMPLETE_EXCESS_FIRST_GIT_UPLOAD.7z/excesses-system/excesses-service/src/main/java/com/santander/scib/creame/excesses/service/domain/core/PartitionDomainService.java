package com.santander.scib.creame.excesses.service.domain.core;


import com.santander.scib.creame.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;

public interface PartitionDomainService {

    PartitionEvent process(Partition partition, DomainEventPublisher<PartitionEvent> partitionDomainEventPublisher);

}
