package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionProcessedEvent extends PartitionEvent {

    private final DomainEventPublisher<PartitionEvent> partitionEventPublisher;

    public PartitionProcessedEvent(Partition partition,
                                   ZonedDateTime createdAt,
                                   DomainEventPublisher<PartitionEvent> partitionEventPublisher) {
        super(partition, createdAt);
        this.partitionEventPublisher = partitionEventPublisher;
    }

    @Override
    public void fire() {
        partitionEventPublisher.publish(this);
    }
}
