package com.santander.scib.creame.excesses.service.domain.application.ports.input.service;

import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;
import jakarta.validation.Valid;

public interface ExcessApplicationService {

    ExcessResponse processExcess(@Valid ExcessRequest excessRequest);

    PartitionResponse processPartition(@Valid PartitionRequest partitionRequest);

}
