package com.santander.scib.creame.excesses.service.adapters.messaging.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import com.santander.scib.creame.excesses.kafka.excess.avro.model.ExcessDetailRecord;
import com.santander.scib.creame.excesses.kafka.excess.avro.model.ExcessRequestAvroModel;
import com.santander.scib.creame.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessDetailDto;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessCreatedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class ExcessMessagingDataMapper {
    private final ObjectMapper objectMapper;

    public ExcessMessagingDataMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public ExcessRequestAvroModel excessCreatedEventToExcessRequestAvroModel(ExcessCreatedEvent domainEvent) {
        Excess excess = domainEvent.getExcess();

        return ExcessRequestAvroModel.newBuilder()
                .setExcessId(excess.getId().getValue())
                .setMetricType(excess.getMetricType().toString())
                .setExcessMetric(excess.getExcessMetric().toString())
                .setExcessBeginDate(excess.getExcessBeginDate())
                .setExcessBeginTimestamp(excess.getExcessBeginTimestamp())
                .setExcessEndDate(excess.getExcessEndDate())
                .setExcessEndTimestamp(excess.getExcessEndTimestamp())
                .setLimitInternalKey(excess.getLimitInternalKey())
                .setExcessType(excess.getExcessType().toString())
                .setExcessStatus(excess.getExcessStatus().toString())
                .setExcessDetail(ExcessDetailRecord.newBuilder()
                        .setProcessDate(excess.getExcessDetail().getProcessDate())
                        .setProcessTimestamp(excess.getExcessDetail().getId().getKey(1)) // PROCESS TIMESTAMP
                        .setLimitOrigin(excess.getExcessDetail().getLimitOrigin())
                        .setLimitShortName(excess.getExcessDetail().getLimitShortName())
                        .setPeriod(excess.getExcessDetail().getPeriod())
                        .setLimitCurrency(excess.getExcessDetail().getLimitCurrency())
                        .setLimitAmount(excess.getExcessDetail().getLimitAmount().toString())
                        .setUsed(excess.getExcessDetail().getUsed().toString())
                        .setExcessReason(excess.getExcessDetail().getExcessReason())
                        .setMetadata(excess.getExcessDetail().getMetadata().toString())
                        .build())
                .build();
    }

    public ExcessRequest excessRequestAvroModelToExcessRequest(ExcessRequestAvroModel excessRequestAvroModel) throws JsonProcessingException {

        return ExcessRequest.builder()
                .excessId(excessRequestAvroModel.getExcessId())
                .metricType(MetricType.valueOf(excessRequestAvroModel.getMetricType()))
                .excessMetric(ExcessMetric.valueOf(excessRequestAvroModel.getExcessMetric()))
                .excessBeginDate(excessRequestAvroModel.getExcessBeginDate())
                .excessBeginTimestamp(excessRequestAvroModel.getExcessBeginTimestamp())
                .excessEndDate(excessRequestAvroModel.getExcessEndDate())
                .excessEndTimestamp(excessRequestAvroModel.getExcessEndTimestamp())
                .limitInternalKey(excessRequestAvroModel.getLimitInternalKey())
                .excessType(ExcessType.valueOf(excessRequestAvroModel.getExcessType()))
                .excessStatus(ExcessStatus.valueOf(excessRequestAvroModel.getExcessStatus()))
                .excessDetail(ExcessDetailDto.builder()
                        .processDate(excessRequestAvroModel.getExcessDetail().getProcessDate())
                        .processTimestamp(excessRequestAvroModel.getExcessDetail().getProcessTimestamp())
                        .limitOrigin(excessRequestAvroModel.getExcessDetail().getLimitOrigin())
                        .limitShortName(excessRequestAvroModel.getExcessDetail().getLimitShortName())
                        .period(excessRequestAvroModel.getExcessDetail().getPeriod())
                        .limitCurrency(excessRequestAvroModel.getExcessDetail().getLimitCurrency())
                        .limitAmount(new BigDecimal(excessRequestAvroModel.getExcessDetail().getLimitAmount().toString()))
                        .used(new BigDecimal(excessRequestAvroModel.getExcessDetail().getUsed().toString()))
                        .excessReason(excessRequestAvroModel.getExcessDetail().getExcessReason())
                        .metadata(objectMapper.readValue(excessRequestAvroModel.getExcessDetail().getMetadata(), new TypeReference<>() {}))
                        .build())
                .build();
    }

    public PartitionRequestAvroModel partitionProcessEventToPartitionRequestAvroModel(PartitionEvent domainEvent) {
        Partition partition = domainEvent.getPartition();

        return PartitionRequestAvroModel.newBuilder()
                .setPartitionId(partition.getId().getValue())
                .build();
    }

    public PartitionRequest partitionRequestAvroModelToPartitionRequest(PartitionRequestAvroModel partitionRequestAvroModel) {

        return PartitionRequest.builder()
                .partitionId(partitionRequestAvroModel.getPartitionId())
                .build();
    }
}