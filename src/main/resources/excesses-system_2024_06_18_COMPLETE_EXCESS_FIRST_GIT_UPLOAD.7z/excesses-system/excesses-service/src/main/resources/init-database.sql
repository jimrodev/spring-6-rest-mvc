DROP SCHEMA IF EXISTS "excesses" CASCADE;

CREATE SCHEMA "excesses";

DROP TABLE IF EXISTS "excesses".partitions;

CREATE TABLE "excesses".partitions
(
    partition_id VARCHAR NOT NULL,
    partition_status VARCHAR NOT NULL
);

DROP TABLE IF EXISTS "excesses".excesses;

CREATE TABLE "excesses".excesses
(
    excess_id VARCHAR NOT NULL,
    metric_type VARCHAR NOT NULL,
    excess_metric VARCHAR NOT NULL,
    excess_begin_date VARCHAR NOT NULL,
    excess_begin_timestamp VARCHAR NOT NULL,
    excess_end_date VARCHAR,
    excess_end_timestamp VARCHAR,
    limit_internal_Key VARCHAR NOT NULL,
    excess_type VARCHAR NOT NULL,
    excess_status VARCHAR NOT NULL,
    CONSTRAINT excess_pkey PRIMARY KEY (excess_id)
);

DROP TABLE IF EXISTS "excesses".excesses_history;

CREATE TABLE "excesses".excesses_history
(
    excess_id VARCHAR NOT NULL,
    process_timestamp VARCHAR NOT NULL,
    process_date VARCHAR NOT NULL,
    limit_origin VARCHAR NOT NULL,
    limit_short_name VARCHAR NOT NULL,
    period VARCHAR NOT NULL,
    limit_currency VARCHAR NOT NULL,
    limit_amount VARCHAR NOT NULL,
    used VARCHAR NOT NULL,
    excess_reason VARCHAR NOT NULL,
    metadata VARCHAR,
    CONSTRAINT excess_history_pkey PRIMARY KEY (excess_id, process_timestamp)
);