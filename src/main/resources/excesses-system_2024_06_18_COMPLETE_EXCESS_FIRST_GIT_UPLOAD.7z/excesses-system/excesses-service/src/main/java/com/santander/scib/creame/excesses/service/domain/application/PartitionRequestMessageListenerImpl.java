package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.PartitionRequestMessageListener;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class PartitionRequestMessageListenerImpl implements PartitionRequestMessageListener {
    private final PartitionProcessHandler partitionProcessHandler;

    public PartitionRequestMessageListenerImpl(PartitionProcessHandler partitionProcessHandler) {
        this.partitionProcessHandler = partitionProcessHandler;
    }

    @Override
    public void process(PartitionRequest partitionRequest) {

        partitionProcessHandler.process(partitionRequest);
    }
}
