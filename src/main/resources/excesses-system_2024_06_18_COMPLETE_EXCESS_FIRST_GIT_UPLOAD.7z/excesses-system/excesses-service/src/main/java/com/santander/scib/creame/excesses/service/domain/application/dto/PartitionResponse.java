package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class PartitionResponse {

    // QUE VALORES DEVOLVEMOS EN LA RESPUESTA ?
    private String partitionId;
    private PartitionStatus partitionStatus;
}
