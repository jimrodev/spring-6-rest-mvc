package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public abstract class PartitionEvent implements DomainEvent<Excess> {
    private final Partition partition;
    private final ZonedDateTime createdAt;

    public PartitionEvent(Partition partition, ZonedDateTime createdAt) {
        this.partition = partition;
        this.createdAt = createdAt;
    }

    public Partition  getPartition() {
        return partition;
    }

    public ZonedDateTime getCreatedAt() {
        return createdAt;
    }
}
