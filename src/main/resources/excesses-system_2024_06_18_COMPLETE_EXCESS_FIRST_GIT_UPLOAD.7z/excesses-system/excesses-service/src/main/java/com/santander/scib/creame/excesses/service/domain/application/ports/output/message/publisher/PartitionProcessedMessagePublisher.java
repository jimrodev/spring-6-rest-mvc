package com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher;

import com.santander.scib.creame.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;

public interface PartitionProcessedMessagePublisher extends DomainEventPublisher<PartitionEvent> {
}
