package com.santander.scib.creame.excesses.service.adapters.dataaccess.repository;

import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntityId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExcessDetailJpaRepository extends JpaRepository<ExcessDetailEntity, ExcessDetailEntityId> {
}
