package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.ExcessRequestMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class ExcessRequestMessageListenerImpl implements ExcessRequestMessageListener {
    private final ExcessCreateHandler excessCreateHandler;

    public ExcessRequestMessageListenerImpl(ExcessCreateHandler excessCreateHandler) {
        this.excessCreateHandler = excessCreateHandler;
    }

    @Override
    public void process(ExcessRequest excessRequest) {
        excessCreateHandler.create(excessRequest);
    }
}
