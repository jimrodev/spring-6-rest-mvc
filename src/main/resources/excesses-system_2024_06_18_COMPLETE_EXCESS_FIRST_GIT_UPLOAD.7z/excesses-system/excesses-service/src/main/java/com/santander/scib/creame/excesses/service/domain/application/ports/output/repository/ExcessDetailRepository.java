package com.santander.scib.creame.excesses.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;

public interface ExcessDetailRepository {

    ExcessDetail save(ExcessDetail excessDetail);
}
