package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.opencsv.bean.CsvBindByName;
import com.santander.scib.creame.excesses.application.converter.HashMapConverter;
import jakarta.persistence.Convert;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessDetailDto {
    @NotEmpty(message = "{not.empty}")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String processDate;
    @NotEmpty(message = "{not.empty}")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String processTimestamp;
    @CsvBindByName(column = "limit_origin")
    @NotEmpty(message = "{not.empty}")
    private String limitOrigin;
    @CsvBindByName(column = "limit_short_name")
    @NotEmpty(message = "{not.empty}")
    private String limitShortName;
    @CsvBindByName(column = "period")
    @NotEmpty(message = "{not.empty}")
    private String period;
    @CsvBindByName(column = "limit_currency")
    @NotEmpty(message = "{not.empty}")
    private String limitCurrency;
    @CsvBindByName(column = "limit_amount")
    @NotNull(message = "{not.null}")
    private BigDecimal limitAmount;
    @CsvBindByName(column = "used")
    @NotNull(message = "{not.null}")
    private BigDecimal used;
    @CsvBindByName(column = "excess_reason")
    @NotEmpty(message = "{not.empty}")
    private String excessReason;
    @CsvBindByName(column = "metadata")
    @NotNull(message = "{not.null}")
    @Convert(converter = HashMapConverter.class)
    private Map<String, Object> metadata;
}
