package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionVoidEvent extends PartitionEvent {

    public PartitionVoidEvent(Partition partition,
                              ZonedDateTime createdAt) {
        super(partition, createdAt);
    }
    @Override
    public void fire() {
    }
}
