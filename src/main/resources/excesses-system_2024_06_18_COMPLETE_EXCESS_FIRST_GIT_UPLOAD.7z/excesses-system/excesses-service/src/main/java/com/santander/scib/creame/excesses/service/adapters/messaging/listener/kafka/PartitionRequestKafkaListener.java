package com.santander.scib.creame.excesses.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.excesses.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.PartitionRequestMessageListener;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.ExcessMessagingDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class PartitionRequestKafkaListener implements KafkaConsumer<PartitionRequestAvroModel> {

    private final PartitionRequestMessageListener partitionRequestMessageListener;
    private final ExcessMessagingDataMapper excessMessagingDataMapper;

    public PartitionRequestKafkaListener(PartitionRequestMessageListener partitionRequestMessageListener,
                                         ExcessMessagingDataMapper excessMessagingDataMapper) {
        this.partitionRequestMessageListener = partitionRequestMessageListener;
        this.excessMessagingDataMapper = excessMessagingDataMapper;
    }

    @Override
    public void receive(List<PartitionRequestAvroModel> messages, List<Integer> partitions, List<Long> offsets) {
        // NOT NECESSARY NOW
    }

    @Override
    @KafkaListener(id = "${kafka-consumer-config.partition-consumer-group-id}", topics = "${excess-service.partition-request-topic-name}")
    public void receive(@Payload List<PartitionRequestAvroModel> messages,
                        @Header(KafkaHeaders.RECEIVED_KEY) List<String> keys,
                        @Header(KafkaHeaders.RECEIVED_PARTITION) List<Integer> partitions,
                        @Header(KafkaHeaders.OFFSET) List<Long> offsets) {
        log.info("{} number of messages received with keys:{}, partitions:{} and offsets: {}",
                messages.size(),
                keys.toString(),
                partitions.toString(),
                offsets.toString());

        messages.forEach(partitionRequestAvroModel -> {
            try {
                partitionRequestMessageListener.process(
                        excessMessagingDataMapper.partitionRequestAvroModelToPartitionRequest(partitionRequestAvroModel));
            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in PaymentResponseKafkaListener for partition id: {}",
                        partitionRequestAvroModel.getPartitionId());
            }
//            catch (PartitionNotFoundException e) {
//               //NO-OP for PartitionNotFoundException
//               log.error("No partition found for partition id: {}", partitionRequestAvroModel.getPartitionId());
//            }
        });
    }
}