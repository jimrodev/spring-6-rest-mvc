package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;

public interface PartitionRequestMessageListener {
    void process(PartitionRequest partitionRequest);
}
