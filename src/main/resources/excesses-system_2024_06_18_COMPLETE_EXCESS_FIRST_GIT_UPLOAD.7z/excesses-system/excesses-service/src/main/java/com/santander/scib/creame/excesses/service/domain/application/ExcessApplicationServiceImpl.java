package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.service.domain.application.ports.input.service.ExcessApplicationService;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Validated
@Service
public class ExcessApplicationServiceImpl implements ExcessApplicationService {
    private final ExcessCreateHandler excessCreateHandler;
    private final PartitionProcessHandler partitionProcessHandler;
    public ExcessApplicationServiceImpl(ExcessCreateHandler excessCreateHandler, PartitionProcessHandler partitionProcessHandler) {
        this.excessCreateHandler = excessCreateHandler;
        this.partitionProcessHandler = partitionProcessHandler;
    }

    @Override
    public ExcessResponse processExcess(ExcessRequest excessRequest) {

        // AHORA SOLO HAY UN HANDLER PARA LA CREACIÓN PORQUE ES LA ÚNICA FUNCIONALIDAD QUE CONOCEMOS
        // CREATE
        // UPDATE
        // RESOLVED
        // HAY QUE CREAR UN HANDLER PARA CADA OPERACIÓN DONDE VA TODA LA LOGICA DE DICHA OPERACIÓN
        // SOLID - RESPONSABILIDAD MINIMA
        return excessCreateHandler.create(excessRequest);
    }

    @Override
    public PartitionResponse processPartition(PartitionRequest partitionRequest) {

        return partitionProcessHandler.process(partitionRequest);
    }
}
