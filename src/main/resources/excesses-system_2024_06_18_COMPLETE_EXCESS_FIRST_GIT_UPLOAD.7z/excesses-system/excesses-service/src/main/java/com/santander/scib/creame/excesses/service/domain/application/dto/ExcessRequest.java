package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.opencsv.bean.CsvBindByName;

import com.santander.scib.creame.excesses.application.validation.ValueOfEnum;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessRequest {
    @CsvBindByName(column = "excess_id")
    @NotEmpty(message = "{not.empty}")
    @Size(max = 25, message = "{size.max}" + ": 25")
    private String excessId;

    @CsvBindByName(column = "metric_type")
    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = MetricType.class)
    private MetricType metricType;

    @CsvBindByName(column = "excess_metric")
    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = ExcessMetric.class)
    private ExcessMetric excessMetric;

    @CsvBindByName(column = "excess_begin_date")
    @NotEmpty(message = "{not.empty}")
    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessBeginDate;

    @CsvBindByName(column = "excess_begin_timestamp")
    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessBeginTimestamp;

    @CsvBindByName(column = "excess_end_date")
    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessEndDate;

    @CsvBindByName(column = "excess_end_timestamp")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessEndTimestamp;

    @CsvBindByName(column = "limit_internal_key")
    @NotEmpty(message = "{not.empty}")
    private String limitInternalKey;

    private ExcessType excessType;

    private ExcessStatus excessStatus;

    @NotNull(message = "{not.empty}")
    private ExcessDetailDto excessDetail;
}
