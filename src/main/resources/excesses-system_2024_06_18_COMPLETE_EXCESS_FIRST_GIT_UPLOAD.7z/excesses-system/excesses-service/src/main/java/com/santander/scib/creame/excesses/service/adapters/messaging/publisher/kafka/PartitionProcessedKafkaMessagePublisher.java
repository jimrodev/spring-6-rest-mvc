package com.santander.scib.creame.excesses.service.adapters.messaging.publisher.kafka;

import com.santander.scib.creame.excesses.kafka.KafkaMessageHelper;
import com.santander.scib.creame.excesses.kafka.KafkaProducer;
import com.santander.scib.creame.excesses.kafka.excess.avro.model.PartitionRequestAvroModel;
import com.santander.scib.creame.excesses.service.domain.application.config.ExcessServiceConfigData;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher.PartitionProcessedMessagePublisher;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.ExcessMessagingDataMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PartitionProcessedKafkaMessagePublisher implements PartitionProcessedMessagePublisher {

    private final ExcessMessagingDataMapper excessMessagingDataMapper;
    private final ExcessServiceConfigData excessServiceConfigData;
    private final KafkaProducer<String, PartitionRequestAvroModel> kafkaProducer; // CREAR MENSAJE DE RESPUESTA CON ESTADO
    private final KafkaMessageHelper excessKafkaMessageHelper;

    public PartitionProcessedKafkaMessagePublisher(ExcessMessagingDataMapper excessMessagingDataMapper,
                                                   ExcessServiceConfigData excessesServiceConfigData,
                                                   KafkaProducer<String, PartitionRequestAvroModel> kafkaProducer,
                                                   KafkaMessageHelper kafkaMessageHelper) {
        this.excessMessagingDataMapper = excessMessagingDataMapper;
        this.excessServiceConfigData = excessesServiceConfigData;
        this.kafkaProducer = kafkaProducer;
        this.excessKafkaMessageHelper = kafkaMessageHelper;
    }

    @Override
    public void publish(PartitionEvent domainEvent) {
        String partitionId = domainEvent.getPartition().getId().getValue().toString();
        log.info("Received PartitionProcessedEvent for partition id: {}", partitionId);

        try {
            PartitionRequestAvroModel partitionRequestAvroModel = excessMessagingDataMapper
                    .partitionProcessEventToPartitionRequestAvroModel(domainEvent);

            kafkaProducer.send(excessServiceConfigData.getPartitionPublishTopicName(),
                    partitionId,
                    partitionRequestAvroModel,
                    excessKafkaMessageHelper
                            .getKafkaCallback(excessServiceConfigData.getPartitionPublishTopicName(),
                                    partitionRequestAvroModel,
                                    partitionId,
                                    "PartitionRequestAvroModel"));

            log.info("PartitionRequestAvroModel sent to Kafka for partition id: {}", partitionRequestAvroModel.getPartitionId());
        } catch (Exception e) {
           log.error("Error while sending PartitionRequestAvroModel message" +
                   " to kafka with partition id: {}, error: {}", partitionId, e.getMessage());
        }
    }
}
