package com.santander.scib.creame.excesses.service.domain.core;

import com.santander.scib.creame.excesses.domain.event.DomainEventPublisher;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessUpdatedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessCreatedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessResolvedEvent;

public interface ExcessDomainService {

    // VER MAS ADELANTE LAS DISTINTAS OPERACIONES FUNCIONALES
    ExcessCreatedEvent create(Excess excess, DomainEventPublisher<ExcessCreatedEvent> excessCreatedDomainEventPublisher);
    ExcessUpdatedEvent update(Excess excess, DomainEventPublisher<ExcessUpdatedEvent> excessUpdatedDomainEventPublisher);
    ExcessResolvedEvent resolve(Excess excess, DomainEventPublisher<ExcessResolvedEvent> excessResolvedDomainEventPublisher);

}
