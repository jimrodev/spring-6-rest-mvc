package com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;

public interface ExcessRequestMessageListener {
    void process(ExcessRequest excessRequest);
}
