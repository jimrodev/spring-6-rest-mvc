package com.santander.scib.creame.excesses.service.adapters.dataaccess.entity;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import jakarta.persistence.*;
import lombok.*;

import java.util.Objects;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "excesses")
@Entity
public class ExcessEntity {

    @Id
    private String excessId;
    @Enumerated(EnumType.STRING)
    private MetricType metricType;
    @Enumerated(EnumType.STRING)
    private ExcessMetric excessMetric;
    private String excessBeginDate;
    private String excessBeginTimestamp;
    private String excessEndDate;
    private String excessEndTimestamp;
    private String limitInternalKey;
    @Enumerated(EnumType.STRING)
    private ExcessType excessType;
    @Enumerated(EnumType.STRING)
    private ExcessStatus excessStatus;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExcessEntity that = (ExcessEntity) o;
        return excessId.equals(that.excessId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(excessId);
    }
}
