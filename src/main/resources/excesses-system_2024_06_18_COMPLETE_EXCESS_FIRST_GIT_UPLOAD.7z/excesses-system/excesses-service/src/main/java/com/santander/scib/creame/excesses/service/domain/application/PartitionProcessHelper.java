package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.receive.ExcessesSnapshotReceive;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher.PartitionProcessedMessagePublisher;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.PartitionRepository;
import com.santander.scib.creame.excesses.service.domain.core.PartitionDomainService;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.mapper.PartitionMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;

@Slf4j
@Component
public class PartitionProcessHelper {

    private final PartitionDomainService partitionDomainService;
    private final PartitionRepository partitionRepository;
    private final PartitionMapper partitionMapper;
    private final PartitionProcessedMessagePublisher partitionProcessMessagePublisher;
    private final ExcessesSnapshotReceive excessesSnapshotReceive;

    private final ExcessCreateHandler excessCreateHandler;

    public PartitionProcessHelper(PartitionDomainService partitionDomainService,
                                  PartitionRepository partitionRepository,
                                  PartitionMapper partitionMapper,
                                  PartitionProcessedMessagePublisher partitionProcessMessagePublisher,
                                  ExcessesSnapshotReceive excessesSnapshotReceive,
                                  ExcessCreateHandler excessCreateHandler) {
        this.partitionDomainService = partitionDomainService;
        this.partitionRepository = partitionRepository;
        this.partitionMapper = partitionMapper;
        this.partitionProcessMessagePublisher = partitionProcessMessagePublisher;
        this.excessesSnapshotReceive = excessesSnapshotReceive;
        this.excessCreateHandler = excessCreateHandler;
    }

    @Transactional
    public PartitionEvent process(PartitionRequest partitionRequest){
        Optional<Partition> foundPartition = partitionRepository.findByPartitionId(new PartitionId(partitionRequest.getPartitionId()));
        Partition partition = foundPartition.orElseGet(() -> partitionMapper.PartitionRequestToPartition(partitionRequest));

        // Cómo gestionamos la recepción de particiones ?
        // MÉTODO VALIDATE
        // - Validamos que la partición que recibimos no se ha procesado ya
        // - Validamos que la partición que recibimos es anterior a la última procesada
        // - Que hacemos si recibimos una partición que ya está en vuelo

        // HACEMOS ESTE PROCESO TRANSACCIÓNAL,
        // - DESDE QUE SE RECIBE EL FICHERO HASTA QUE SE PROCESA TODOS LOS EXCESOS
        // CUIDADO AQUÍ CON LA ANOTACIÓN @Transactional en el método persistExcess de ExcessCreateHelper
        // AOP

        // COGER TODAS LAS EXCEPCIONES DE TIPO DOMAIN Y GENERAR UNA ALERTA QUE SERÁ PROCESADA POR EL MÓDULO DE ALERTAS
        PartitionEvent partitionEvent = partitionDomainService.process(partition,
                partitionProcessMessagePublisher);

        partitionRepository.save(partition);

        // PROCESAR EL FICHERO (Imput receive port -> s3 adapter )
        Set<ExcessRequest> excesses = excessesSnapshotReceive.processFile(partition.getId().getValue());
        // revisar !!!! cuando vayamos al outbox ya que podemos hacer @Transactional todo el proceso con un métood nuevo
        excesses.forEach(excessCreateHandler::create);

        return partitionEvent;
    }
}
