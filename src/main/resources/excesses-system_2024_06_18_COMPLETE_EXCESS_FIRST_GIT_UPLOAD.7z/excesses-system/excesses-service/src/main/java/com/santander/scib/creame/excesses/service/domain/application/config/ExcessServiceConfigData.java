package com.santander.scib.creame.excesses.service.domain.application.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "excess-service")
public class ExcessServiceConfigData {
    private String excessRequestTopicName;
    private String partitionRequestTopicName;
    private String filterRequestTopicName;
    private String filterResponseTopicName;
    private String workflowRequestTopicName;
    private String workflowResponseTopicName;
    private String partitionPublishTopicName;
}
