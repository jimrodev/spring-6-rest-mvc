package com.santander.scib.creame.excesses.domain.valueobject;

import java.util.UUID;

public class InterchangeId extends BaseId<UUID>{{
}
    public InterchangeId(UUID value) {
        super(value);
    }
}