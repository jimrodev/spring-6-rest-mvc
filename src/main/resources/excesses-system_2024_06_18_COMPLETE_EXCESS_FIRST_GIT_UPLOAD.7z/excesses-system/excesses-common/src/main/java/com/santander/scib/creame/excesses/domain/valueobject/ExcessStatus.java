package com.santander.scib.creame.excesses.domain.valueobject;

public enum ExcessStatus {

    PENDING(0), FILTERED(1), ASSIGNED(2), RESOLVED(3), FAILED(4), UNDER_REVIEW(5);

    private final Integer excessStatus;
    ExcessStatus(Integer excessStatus){
        this.excessStatus = excessStatus;
    }
    public Integer getExcessStatus(){
        return excessStatus;
    }
}
