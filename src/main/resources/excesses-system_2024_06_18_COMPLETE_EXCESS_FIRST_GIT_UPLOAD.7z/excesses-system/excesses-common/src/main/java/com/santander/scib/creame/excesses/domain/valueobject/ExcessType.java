package com.santander.scib.creame.excesses.domain.valueobject;

public enum ExcessType {
    PENDING(0), REAL(1), NOT_REAL(2);

    private final Integer excessType;
    ExcessType(Integer excessType){
        this.excessType = excessType;
    }
    public Integer getExcessType(){
        return excessType;
    }
}
