package com.santander.scib.creame.excesses.aws.s3.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.core.client.config.ClientOverrideConfiguration;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.utils.StringUtils;

import java.net.URI;

@Configuration
@EnableConfigurationProperties(AwsProperties.class)
public class S3ClientConfig {

    private final AwsProperties awsProperties;

    public S3ClientConfig(AwsProperties awsProperties) {
        this.awsProperties = awsProperties;
    }

    @Bean("AwsCredentials")
    public AwsCredentialsProvider awsCredentialsProvider() {

        if (StringUtils.isBlank(awsProperties.getAccessKeyId())) {
            // Return default provider
            return DefaultCredentialsProvider.create();
        }
        else {
            // Return custom credentials provider
            return () -> {
                AwsCredentials creds = AwsBasicCredentials.create(awsProperties.getAccessKeyId(), awsProperties.getSecretAccessKey());
                return creds;
            };
        }
    }

    @Bean("S3AsyncClient")
    public S3AsyncClient s3AsyncClient(@Qualifier("AwsCredentials") AwsCredentialsProvider awsCredentials) {
        return S3AsyncClient.builder()
                .credentialsProvider(awsCredentials)
                .region(Region.of(awsProperties.getS3().getRegion()))
                .build();
    }

    @Bean("S3Client")
    public S3Client s3Client(@Qualifier("AwsCredentials") AwsCredentialsProvider awsCredentials) {
        return S3Client.builder()
//              .credentialsProvider(awsCredentials)
//              .region(Region.of(awsProperties.getS3().getRegion()))
                .overrideConfiguration(ClientOverrideConfiguration.builder().build())
                .credentialsProvider(awsCredentials)
                .endpointOverride(URI.create(awsProperties.getS3().getServiceEndpoint()))
                .region(Region.of(awsProperties.getS3().getRegion()))
                .forcePathStyle(true)
                .build();
    }

}
