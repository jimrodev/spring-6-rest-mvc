package com.santander.scib.creame.excesses.aws.s3.config;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties("aws")
@Primary
public class AwsProperties {
    private String accessKeyId;
    private String secretAccessKey;
    private String accountNo;

    private S3Properties s3;

    @Data
    public static class S3Properties {
        private String bucket;
        private String region;
        private String serviceEndpoint;
    }
}