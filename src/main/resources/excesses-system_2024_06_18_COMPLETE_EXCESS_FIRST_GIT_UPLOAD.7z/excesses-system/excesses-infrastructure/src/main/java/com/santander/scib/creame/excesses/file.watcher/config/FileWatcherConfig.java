package com.santander.scib.creame.excesses.file.watcher.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import java.io.IOException;
import java.nio.file.*;
@Slf4j
@EnableAsync
@Configuration
@EnableConfigurationProperties(FileWatcherProperties.class)
public class FileWatcherConfig {

    private final FileWatcherProperties properties;

    public FileWatcherConfig(FileWatcherProperties properties)  {
        this.properties = properties;
    }

    @Bean
    public WatchService registerWatcher() throws IOException {
        if (!Files.isDirectory(Paths.get(properties.path()))) {
            throw new RuntimeException("incorrect monitoring folder: " + properties.path());
        }
        log.debug("Monitoring folder for excess daily snapshot: {}", properties.path());

        WatchService watchService = FileSystems.getDefault().newWatchService();
        Path path = Paths.get(properties.path());
        path.register(watchService,
                StandardWatchEventKinds.ENTRY_CREATE);
        // StandardWatchEventKinds.ENTRY_DELETE,
        // StandardWatchEventKinds.ENTRY_MODIFY);

        return watchService;
    }
}